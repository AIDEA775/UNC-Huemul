<?php
class cn_extra extends toba_cn
{
    protected $s__datos = null;

    function get_lista() {
	$sql = "select * from fq_extra() where obsoleto = false";
	return toba::db()->consultar($sql);
    }
    
    function get() {
	if(isset($this->_memoria['index'])) {
	    $sql = "select * from fq_extra(".$this->_memoria['index'].")";
	    $n = toba::db()->consultar($sql);
	    return $n[0];
	}
	return array();
    }
    
    function eliminar() {
	if(isset($this->_memoria['index'])) {
	  $sql = "select * from fd_extra(".$this->_memoria['index'].")";
	  toba::db()->consultar($sql);
	}
    }


    function set($datos) {
	$this->s__datos = $datos;
    }
    
    function guardar() {
	if($this->s__datos) {
	    $id = $this->s__datos['id_extra']!=''?$this->s__datos['id_extra']:'null';
	    $desc = $this->s__datos['descripcion']!=''?"'".$this->s__datos['descripcion']."'":'null';
	    $clave = $this->s__datos['codigo']!=''?"'".$this->s__datos['codigo']."'":'null';
	    $pu = $this->s__datos['precio_unitario']!=''?$this->s__datos['precio_unitario']:'null';
	    $cant = $this->s__datos['cantidad']!=''?$this->s__datos['cantidad']:'null';
	    $cero_chk = $this->s__datos['cero_chk']!=''?$this->s__datos['cero_chk']:'null';
	    $sql = "select * from fs_extra(".$id.", ".$desc.", ".$clave.", ".$pu.", ".$cant.",".$cero_chk.", false)";
	    $r = toba::db()->consultar($sql);
	    $this->_memoria['index']=$r[0]['fs_extra'];
	}
    }

    function set_index($datos=false) {
	if($datos) {
	  $this->_memoria['index'] = $datos['id_extra'];
	} else {
	  unset($this->_memoria['index']);
	}
    }
}

?>
