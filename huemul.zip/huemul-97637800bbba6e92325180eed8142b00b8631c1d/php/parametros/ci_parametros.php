<?php
class ci_parametros extends toba_ci {
	
	protected $s__data;

	//-----------------------------------------------------------------------------------
	//---- Eventos ----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__procesar()
	{
		if(isset($this->s__data)) {
			foreach($this->s__data as $k=>$d) {
				$this->s__data[$k] = $d?toba::db()->quote($d):'null';
			}

			$sql = "select fs_parametros_generales({$this->s__data['id_parametros_generales']}, {$this->s__data['precio_x_racion']}, {$this->s__data['racion_x_persona']}, false)";
		}	toba::db()->consultar($sql);
	}

	//-----------------------------------------------------------------------------------
	//---- formulario -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__formulario(toba_ei_formulario $form)
	{
		$sql = "select * from fq_parametros_generales() limit 1";
		$data = toba::db()->consultar($sql);
		$form->set_datos($data[0]);
	}

	function evt__formulario__modificacion($datos)
	{
		$this->s__data= $datos;
	}

}
?>
