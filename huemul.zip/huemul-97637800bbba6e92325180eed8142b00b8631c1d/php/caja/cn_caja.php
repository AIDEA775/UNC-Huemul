<?php
require_once('printipp/BasicIPP.php');
include_once('lib/funciones.php');
class cn_caja extends toba_cn
{
    protected $ci;
    public $s__sede;
    
    function set_ci($ci) {
    	$this->ci = $ci;
    }
    
    function buscar_codigo($codigo) {
      //$codigo = toba::db()->quote($codigo);
      //$sql = "select * from f_buscar($codigo)";
      //$datos = toba::db()->consultar($sql);
      //return $datos;

        $siva=true;
        $s__sede =toba::proyecto()->get_parametro('sede_trabajo');
        $sql_tipo_sede_trabajo="select tipo_sede from sedes where sede='$s__sede'";
$datos_tipo_sede_trabajo=toba::db()->consultar($sql_tipo_sede_trabajo);
        $tipo_sede_trabajo=($datos_tipo_sede_trabajo[0]['tipo_sede']);
        if (strlen($codigo)<=11){
            $sql2 ="select * from persona where cuip='$codigo' or otro='$codigo'";
            $datos2 = toba::db()->consultar($sql2);
            $id_persona=($datos2[0]['id_persona']);
            $sql3 ="select codigo from cliente where id_persona=$id_persona";
            $datos3 = toba::db()->consultar($sql3);   
            $codigo=($datos3[0]['codigo']);
        }
        $sql4 ="select id_cliente, id_persona, id_tipo_cliente, sede, fecha_desde, fecha_hasta from cliente where codigo='$codigo'";
        $datos4 = toba::db()->consultar($sql4);
        $id_tipo_cliente=($datos4[0]['id_tipo_cliente']);
        $sede_clien=($datos4[0]['sede']);
        $fecha_desde=($datos4[0]['fecha_desde']);
        $fecha_hasta=($datos4[0]['fecha_hasta']);        
        $sql5 ="select pase from tipo_cliente where id_tipo_cliente=$id_tipo_cliente";
        $datos5 = toba::db()->consultar($sql5);
        $pase_clien=($datos5[0]['pase']);
        $dia_hoy= date('Y-m-d');
        $mensa='';
        //if ($fecha_hasta <=$dia_hoy and $fecha_hasta<>NULL){
        //    $mensa='SU CREDENCIAL ESTA VENCIDA';
        //    return $mensa;
        //    $siva=false;
       // }

        if($pase_clien=='R' and $sede_clien<>$s__sede)
        {
            $mensa='RESTRINGIDO - SOLO PUEDE CARGAR CREDITO EN SU SEDE';
        }
        if($tipo_sede_trabajo=='cerrada' and $sede_clien<>$s__sede){
            $mensa='SEDE CERRADA - SOLO PUEDE CARGAR CREDITO EN SU SEDE';
        }
        if($siva==false) {
        } else {
        $codigo = toba::db()->quote($codigo);
        $sql = "select * from f_buscar($codigo)";
        $datos = toba::db()->consultar($sql);
        $datos[0]['mensa']=$mensa;    
        return $datos;
        }    
    }

    function applicar_formato_texto($txt, $att=array(), $app=array()) {
    	if(is_array($txt)) {
    		foreach($txt as $k => $v) {
    			$txt[$k] = $this->applicar_formato_texto($v, $att, $app);
    		}
    		return $txt;
    	} else {
    		if($app) {
    			$app['valor'] = $this->ci->xml_texto($txt, $att);
    			return $app;
    		}
    		return $this->ci->xml_texto($txt, $att);
    	}
    }
    
    function guardar($datos, $extras, $efvo) {
    /*$txt = array();
    $txt[] = '*************************';
    $txt[] = '  Comedor Universitario  ';
    $txt[] = '*************************';*/
    $s__sede =toba::proyecto()->get_parametro('sede_trabajo');
    $cl = array(array('Fecha: ',date('d/m/Y H:i:s')));
    $vta = array();
	$totextra = 0;
	$iv = array();
	foreach($extras as $e) {
	  $sql = "select * from fq_extra(".$e['id_extra'].")";
//echo $sql."<hr/>";
	  $r = toba::db()->consultar($sql);
	  $r = $r[0];
	  $iv[$e['id_extra']]['c'] = $e['cantidad'];
	  $iv[$e['id_extra']]['t'] = $e['cantidad']*$r['precio_unitario'];
	  $iv[$e['id_extra']]['p'] = $r['precio_unitario'];
	  $iv[$e['id_extra']]['d'] = $r['descripcion'];
	  foreach($r as $k=>$v) {
	    $r[$k] = is_null($v)?'null':($k=='descripcion'?"'".$v."'":$v);
	  }
	  $totextra += $e['cantidad']*$r['precio_unitario'];
	  $sql = "select * from fs_extra(".$e['id_extra']."::integer, ".$r['descripcion']."::varchar, '".$r['codigo']."'::varchar, ".$r['precio_unitario']."::real, ".($r['cantidad']-$e['cantidad'])."::integer, ".($r['cero_chk']?'true':'false')."::boolean, false)";
//echo $sql."<hr/>";
	  toba::db()->consultar($sql);
//aca termina el otro foreach
	}
	$tosaldo = ($totextra-$efvo['efectivo'])>0?$totextra-$efvo['efectivo']:0;
	if($datos['id_cliente']) {
	    $sql = "select * from fq_cliente(".$datos['id_cliente'].")";
//echo $sql."<hr/>";
	    $r = toba::db()->consultar($sql);
	    $r = $r[0];
	    foreach($r as $k=>$v) {
	      $r[$k] = is_null($v)?'null':($k=='renovado' || $k=='fecha_desde' || $k=='fecha_hasta'?"'".$v."'":$v);
	    }
	    $sql = "select * from fs_cliente(".$datos['id_cliente'].", '".$r['codigo']."', ".$r['id_persona'].",  ".$r['id_evento'].",  ".$r['id_tipo_cliente'].",  ".$r['beca'].",  ".$r['renovado'].",  ".$r['fecha_desde'].",  ".$r['fecha_hasta'].",  ".($r['saldo']+$datos['sumar']-$tosaldo).",  ".$r['raciones'].", false)";
//echo $sql."<hr/>";
	    toba::db()->consultar($sql);
	    $sql = "select * from fq_persona({$r['id_persona']})";
	    $p = toba::db()->consultar($sql);
	    $p = $p[0];
	    $cl[] = array('Cliente:',$p['nombre'].' '.$p['apellido']);
	    $cl[] = array('Saldo Actual:', '$'.($r['saldo']+$datos['sumar']-$tosaldo));
//aca termina el if
	}

	//$sql = "select * from fs_venta(null::integer, 
//".($datos['id_cliente']?$datos['id_cliente']:'null')."::integer, 
//now()::timestamp without time zone, 
//".($datos['sumar']+$totextra-$tosaldo)."::real, ".$tosaldo."::real, 
//'".toba::usuario()->get_id()."', false)";
	$sql = "select * from fs_venta(null::integer, ".($datos['id_cliente']?$datos['id_cliente']:'null')."::integer, now()::timestamp without time zone, ".($datos['sumar']+$totextra-$tosaldo)."::real, ".$tosaldo."::real,'".toba::usuario()->get_id()."', false, '$s__sede')";
	$r = toba::db()->consultar($sql);
	$r = $r[0]['fs_venta'];
	foreach($iv as $k=>$i) {
	  $sql = "select * from fs_item_venta(null::integer, ".$r."::integer, ".$k."::integer, ".$i['c']."::integer, ".$i['t']."::real, false)";
	  toba::db()->consultar($sql);
	  $vta[] = array($i['c'],$i['d'],'$'.$i['p'],'$'.$i['t']);
	}

	try {
		$xml = '<?xml version="1.0" encoding="ISO-8859-1"?><raiz>';
		$img = toba::proyecto()->get_www('img/escudo_unc_bn.jpg');
		$this->ci->xml_set_dim_pagina('80mm', '160mm');
		$this->ci->xml_set_margenes(array('izq'=>'0.1cm', 'der'=>'0.1cm'));
		$this->ci->xml_set_incluir_pie(false);
		$this->ci->xml_set_incluir_cabecera(false);
		$xml .= $this->ci->xml_get_tag_inicio();
		$this->ci->xml_set_tabla_cols(array(array('column-width'=>'4cm'), array()));
		$xml .= $this->ci->xml_tabla(
			array(
				array(
					array('border-bottom'=>'medium solid black', 'number-rows-spanned'=>'2', 'valor'=>$this->ci->xml_imagen($img['path'])),
					array('border'=>'none', 'padding-bottom'=>'0mm', 'valor'=>$this->ci->xml_texto('Comedor', array('font-size'=>'10pt', 'font-weight'=>'bold', 'margin-top'=>'7mm', 'margin-bottom'=>'0mm')))
				),
				array(array('padding-top'=>'0mm', 'border-bottom'=>'medium solid black', 'valor'=>$this->ci->xml_texto('Universitario', array('font-size'=>'10pt', 'font-weight'=>'bold', 'margin-top'=>'0mm'))))
			), 
			false
		);
		$this->ci->xml_set_tabla_cols();
		$xml .= $this->ci->xml_texto('Datos', array('border-bottom'=>'thin solid black', 'font-size'=>'6pt'));
		$xml .= $this->ci->xml_tabla($this->applicar_formato_texto(utf8_mdecode($cl), array('font-size'=>'6pt'), array('border-top-style'=>'none')), false);
		if($vta) {
			$this->ci->xml_set_tabla_cols(array(array('column-width'=>'0.7cm'), array('column-width'=>'3.7cm'), array('column-width'=>'1.3cm'), array('column-width'=>'1.3cm')));
			$xml .= $this->ci->xml_texto('Ventas', array('border-bottom'=>'thin solid black', 'font-size'=>'6pt', 'margin-bottom'=>'2mm'));
			//$this->ci->xml_set_tabla_cols(array(array('titulo'=>'Cant'), array('titulo'=>'Prod'), array('titulo'=>'Pr. Unit'), array('titulo'=>'Total')));
			$vta = $this->applicar_formato_texto($vta, array('font-size'=>'6pt'), array('border'=>'thin solid black'));
			$tmp = $this->applicar_formato_texto(array('Cant.', 'Descripcion', 'Precio Unit.', 'Total'), array('font-size'=>'6pt', 'font-weight'=>'bold'), array('border'=>'thin solid black'));
			array_unshift($vta, $tmp);
			$xml .= $this->ci->xml_tabla(utf8_mdecode($vta), false);
		}
		$this->ci->xml_set_tabla_cols();
		$xml .= $this->ci->xml_texto('Totales', array('border-bottom'=>'thin solid black', 'font-size'=>'6pt'));
		$xml .= $this->ci->xml_tabla(
			$this->applicar_formato_texto(
				array(
					array('Total venta:', '$'.$totextra),
					array('Pagado Efvo.:', '$'.$efvo['efectivo']),
					array('Vuelto:', '$'.($efvo['efectivo']-$totextra > 0?$efvo['efectivo']-$totextra:0)),
					array('Pagado Saldo:', '$'.$tosaldo),
					array('Sumar a Saldo:', '$'.($datos['sumar']-$tosaldo > 0?$datos['sumar']-$tosaldo:0))
				), 
				array('font-size'=>'6pt'), 
				array('border-top-style'=>'none')
			)		
		);
		
		$xml .= $this->ci->xml_texto('No v�lido como Ticket.', array('font-weight'=>'bold', 'font-size'=>'6pt', 'text-align'=>'center', 'padding-bottom'=>'5mm'));
		$xml .= $this->ci->xml_get_tag_fin();
		$xml .= '</raiz>';
		//$tmp = tempnam(toba::proyecto()->get_path_temp(), 'ticket_');
		//file_put_contents($tmp, $xml);
		$xsl = toba::nucleo()->toba_dir().'/exportaciones/pdf.xsl';
		//$comando = '/fop/fop -xml '.$tmp.' -xsl '.$xsl.' -ps '.$tmp.'.ps';
		//shell_exec($comando);
		//ei_arbol($_SERVER['REMOTE_ADDR']);
		$ipp = new BasicIPP(); 
 		$ipp->setLog('','logger',0);
	    	//$ipp->setHost($_SERVER['REMOTE_ADDR']);						//ORIGINAL	
	    	//$ipp->setHost('172.16.3.31');								//MODIFICADO 2
                $myIP = toba::proyecto()->get_parametro('ip_cliente');					//MODIFICADO 3
		//ei_arbol($myIP);  //172.16.3.31
	


	    	$ipp->setHost($myIP);									//MODIFICADO 2
		//$impip=$_SERVER['REMOTE_ADDR'];							//MODIFICADO 1
    		//$ipp->setHost($impip);								//MODIFICADO 1


		//$ipp->setPrinterUri('ipp://'.$_SERVER['REMOTE_ADDR'].':631/printers/epsontmt88v'); 	//ORIGINAL
		//$ipp->setPrinterUri('ipp://'.$impip.':631/printers/epsontmt88v');			//MODIFICADO 1
		//$ipp->setPrinterUri('ipp://172.16.3.31:631/printers/epsontmt88v');			//MODIFICADO 2
		$ipp->setPrinterUri('ipp://'.$myIP.':631/printers/epsontmt88v');			//MODIFICADO 3
		//$ipp->setData($tmp.'.ps');
		
		/*** parte nueva */
    	$cl[] = array('Sumado a Saldo:', '$'.($datos['sumar']-$tosaldo > 0?$datos['sumar']-$tosaldo:0));
    	$acl = array();
    	foreach($cl as $c) {
    		$acl[] = implode(' ', $c);
    	}
    	$txt =  
"COMEDOR - UNC {$acl[0]}
{$acl[1]}

{$acl[3]}  {$acl[2]}

No v�lido como Ticket.";
    	
    	$ipp->setData($txt);
    	/*** fin parte nueva */
		
    	$ipp->printJob();  
	//ESTA LINEA TBN DEBE ESTAR HABILITADA AL MOMENTO DE IMPRIMIR
		//unlink($tmp);
		//unlink($tmp.'.ps');
	} catch(Exception $e) {
		toba::notificacion()->agregar($e->getMessage());
	}
    }

}

?>
