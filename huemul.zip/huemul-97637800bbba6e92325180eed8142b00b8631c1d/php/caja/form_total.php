<?php
class form_total extends toba_ei_formulario
{

	function extender_objeto_js()
	{
		echo "
		//---- Validacion de EFs -----------------------------------
		{$this->objeto_js}.ef('efectivo').input().onkeypress = function(e) {
			var KeyID;
			if(window.event) {
			  KeyID = event.keyCode;
			} else if (e.charCode == e.keyCode) {
			  KeyID = event.keyCode;
			} else {
			  KeyID = e.charCode!=0?e.charCode:e.keyCode;
			}    
			var numtest = /\d|\./;
			var esctest = /8|46|39|37|35|36/;
			if(KeyID == 13)  {
			  {$this->objeto_js}.controlador.set_focus();
			  return false;
			} else if(!esctest.test(KeyID) && !numtest.test(String.fromCharCode(KeyID))) {
			  return false;
			} 
		};

		";
	}

}
?>