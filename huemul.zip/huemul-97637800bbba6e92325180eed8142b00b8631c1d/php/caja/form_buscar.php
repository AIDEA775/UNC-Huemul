<?php
class form_buscar extends toba_ei_formulario
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		
		{$this->objeto_js}.ef('busqueda').input().onkeypress = function(e) {
		      var KeyID = (window.event) ? event.keyCode : e.keyCode;
		      if(KeyID == 13) { //13: Enter
			{$this->objeto_js}.controlador.ajax('buscar_codigo', this.value, {$this->objeto_js}.controlador, {$this->objeto_js}.controlador.set_respuesta);
			this.value = '';
			return false;
		      }
		}

		";
	}

}
?>