<?php
class form_ml_extra extends toba_ei_formulario_ml
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Eventos ---------------------------------------------
		var btn = document.getElementById('{$this->objeto_js}_agregar').parentNode;
		btn.parentNode.removeChild(btn);

		{$this->objeto_js}.evt__eliminar = function(fila)
		{
		  this.eliminar_fila(fila);
		  this.controlador.dep('total').ef('total').set_estado(Number(this.total('total')).toFixed(2));
		  this.controlador.set_focus();
		  return false;
		}
		
		{$this->objeto_js}.set_respuesta = function(datos) {
		  var filas = this.filas();
		  var nuevo = true;
		  for(var f in filas) {
		      f=filas[f];
		      if(this.ef('id_extra').ir_a_fila(f).get_estado() == datos.id_extra) {
				 nuevo = false; 
				 var cant = Number(this.ef('cantidad').ir_a_fila(f).get_estado());
				 if(datos.cantidad!=null && cant >= datos.cantidad) {
				    notificacion.mostrar_ventana_modal('Error', 'S�lo puede vender hasta un m�ximo de '+datos.cantidad+' unidades.');
				 } else {
				    cant += 1;
				 }
				 var precio = this.ef('precio_unitario').ir_a_fila(f).get_estado();
				 this.ef('cantidad').ir_a_fila(f).set_estado(cant);
				 this.ef('total').ir_a_fila(f).set_estado(Number(cant*precio).toFixed(2));
				 break;
		      }
		  }
		  
		  if(nuevo) {
		    var f = this.crear_fila();
		    this.ef('id_extra').ir_a_fila(f).ocultar();
		    this.ef('id_extra').ir_a_fila(f).set_estado(datos.id_extra);
		    this.ef('cant_disp').ir_a_fila(f).ocultar();
		    this.ef('cant_disp').ir_a_fila(f).set_estado(datos.cantidad);
		    this.ef('descripcion').ir_a_fila(f).set_estado(datos.descripcion);
		    this.ef('precio_unitario').ir_a_fila(f).set_estado(datos.precio_unitario);
		    this.ef('cantidad').ir_a_fila(f).set_estado(1);
		    this.ef('cantidad').ir_a_fila(f).input().onkeypress = function(e) {
				var KeyID;
				if(window.event) {
			  		KeyID = event.keyCode;
				} else if (e.charCode == e.keyCode) {
			  		KeyID = event.keyCode;
				} else {
			  		KeyID = e.charCode!=0?e.charCode:e.keyCode;
				}    
				var numtest = /\d|\./;
				var esctest = /8|46|39|37|35|36/;
				if(KeyID == 13)  {
				  	{$this->objeto_js}.controlador.set_focus();
				  	return false;
				} else if(!esctest.test(KeyID) && !numtest.test(String.fromCharCode(KeyID))) {
				  	return false;
				} 
		    };
		    this.ef('cantidad').ir_a_fila(f).input().onkeyup = function(e) {
			  if({$this->objeto_js}.ef('cant_disp').get_estado()!='' && Number({$this->objeto_js}.ef('cantidad').get_estado()) > Number({$this->objeto_js}.ef('cant_disp').get_estado())) {
				notificacion.mostrar_ventana_modal('Error', 'S�lo puede vender hasta un m�ximo de '+{$this->objeto_js}.ef('cant_disp').get_estado()+' unidades.');
				{$this->objeto_js}.ef('cantidad').set_estado({$this->objeto_js}.ef('cant_disp').get_estado());
				{$this->objeto_js}.controlador.set_focus();
			  }
			  {$this->objeto_js}.ef('total').ir_a_fila(f).set_estado(Number({$this->objeto_js}.ef('precio_unitario').ir_a_fila(f).get_estado()*this.value).toFixed(2));
			  {$this->objeto_js}.controlador.dep('total').ef('total').set_estado(Number({$this->objeto_js}.total('total')).toFixed(2));
		    };
		    this.ef('total').ir_a_fila(f).set_estado(datos.precio_unitario);
		  }
		  this.controlador.dep('total').ef('total').set_estado(Number(this.total('total')).toFixed(2));
		  this.controlador.set_focus();
		}
		";
	}

}
?>