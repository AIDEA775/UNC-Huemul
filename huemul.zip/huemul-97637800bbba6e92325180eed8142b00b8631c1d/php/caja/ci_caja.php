<?php
include_once('lib/funciones.php');
class ci_caja extends toba_ci
{
	protected $s__formulario;
	protected $s__extras;
	protected $s__total;
	public $s__sede;
	
	function ini() {
		$this->cn()->set_ci($this);
	}
	//-----------------------------------------------------------------------------------
	//---- Eventos ----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__cancelar()
	{
	}

	function evt__aceptar()
	{
	  $s__sede =toba::proyecto()->get_parametro('sede_trabajo');
	  $this->cn()->guardar($this->s__formulario, $this->s__extras, $this->s__total);
	}

	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Eventos ---------------------------------------------

		{$this->objeto_js}.set_focus = function()
		{
		  this.dep('busqueda').ef('busqueda').input().focus();
		}
		
		{$this->objeto_js}.set_respuesta = function(datos) {
		  if(datos.elem) {
     		          if(datos.mensa){
			notificacion.mostrar_ventana_modal('Error', datos.mensa);
                      }            
		    this.dep(datos.elem).set_respuesta(datos);
		      }else{notificacion.mostrar_ventana_modal('Error', 'TIENE  CREDENCIAL VENCIDA');}	
		}

		{$this->objeto_js}.evt__aceptar = function()
		{

		  var efv = Number(this.dep('total').ef('efectivo').get_estado());
		  var usar_saldo = this.dep('formulario').ef('id_cliente').tiene_estado();

		  if(!usar_saldo && !(efv>0)) {
		    notificacion.mostrar_ventana_modal('Error', 'No se ha seleccionado un cliente, ni tampoco se ha ingresado un monto, si el cliente paga en efectivo.');
		    return false;
		  }

		  var tot = Number(this.dep('total').ef('total').get_estado());
		  if(efv > 0) {
		    if((efv-tot) < 0) {
		      if(usar_saldo) {
			usar_saldo = confirm('�Usar saldo del cliente para pagar $'+(tot-efv).toFixed(2)+' faltantes?');
			tot = (tot-efv).toFixed(2);
		      } 
		      if(!usar_saldo) {
			notificacion.mostrar_ventana_modal('Error', 'Cantidad de efectivo insuficiente. Faltan pagar $'+(tot-efv).toFixed(2)+'.');
			return false;
		      }
		    } else {
		      usar_saldo = false;
		      if((efv-tot) > 0) {
			alert('Vuelto: $'+(efv-tot).toFixed(2)+'.');
		      }
		    }
		  }
		  var calc = Number(this.dep('formulario').ef('total').get_estado()) - tot;
		  if(calc < 0 && usar_saldo) {
		    notificacion.mostrar_ventana_modal('Error', 'El cliente no tiene suficiente saldo en su cuenta. <br/>Necesita acreditar, por lo menos, $'+(calc*-1)+' adicionales.');
		    return false;
		  }
		}
		";
	}

	//-----------------------------------------------------------------------------------
	//---- extras -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__extras__modificacion($datos)
	{
	    $this->s__extras = utf8_mencode($datos);
	}


	function ajax__buscar_codigo($codigo, toba_ajax_respuesta $respuesta) {
		$datos = utf8_mdecode($this->cn()->buscar_codigo($codigo));
		if($datos) {
		  $datos=$datos[0];
		  switch($datos['tipo_codigo']) {
		      case "1":
			$datos['elem']='formulario';
			break;
		      case "2":
			$datos['elem']='extras';
			break;
		      default:
			$datos['elem']='error';
		  }
		}
		$respuesta->set($datos);
	}
	//-----------------------------------------------------------------------------------
	//---- formulario -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__formulario__modificacion($datos)
	{
	    $this->s__formulario = utf8_mencode($datos);
	}

	function evt__total__modificacion($datos)
	{
	    $this->s__total = utf8_mencode($datos);
	}

}
?>
