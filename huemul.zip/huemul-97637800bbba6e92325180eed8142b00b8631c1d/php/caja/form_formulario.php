<?php
class form_formulario extends toba_ei_formulario
{
	function generar_layout()
	{
		$this->generar_html_ef('id_cliente');
		$this->generar_html_ef('id_persona');
		$this->generar_html_ef('nombre');
		$this->generar_html_ef('apellido');
		$this->generar_html_ef('cuip');
		$this->generar_html_ef('saldo');
		$this->generar_html_ef('sumar');
		$this->generar_html_ef('total');
	}

	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		{$this->objeto_js}.ef('id_cliente').ocultar();

		//---- Validacion de EFs -----------------------------------
		{$this->objeto_js}.ef('sumar').input().onkeypress = function(e) {
			var KeyID;
			if(window.event) {
			  KeyID = event.keyCode;
			} else if (e.charCode == e.keyCode) {
			  KeyID = event.keyCode;
			} else {
			  KeyID = e.charCode!=0?e.charCode:e.keyCode;
			}    
			var numtest = /\d|\./;
			var esctest = /8|46|39|37|35|36/;
			if(KeyID == 13)  {
			  {$this->objeto_js}.controlador.set_focus();
			  return false;
			} else if(!esctest.test(KeyID) && !numtest.test(String.fromCharCode(KeyID))) {
			  return false;
			} 
		};
		{$this->objeto_js}.ef('sumar').input().onkeyup = function(e) {
			{$this->objeto_js}.ef('total').set_estado((Number({$this->objeto_js}.ef('saldo').get_estado())+Number(this.value)).toFixed(2));
		};		



		{$this->objeto_js}.set_respuesta = function(datos) {
		  if(datos.tipo_beca && datos.tipo_beca == 'C') {
		  	notificacion.mostrar_ventana_modal('Error', 'El tipo de cliente \"'+datos.tipo_cliente+'\" no puede cargar dinero en la tarjeta');
		  	return;
		  }
		  if(datos.fecha_expiracion) {
		  	var d = datos.fecha_expiracion.split('/');
		  	if(d.length < 2) {
		  		d = datos.fecha_expiracion.split('-').reverse();
		  	}
		  	var i = new Date(parseInt(d[2],10), parseInt(d[1],10)-1, parseInt(d[0],10));
		  	var j = new Date();
		  	var j = new Date(j.getFullYear(), j.getMonth(), j.getDate());
		  	if(j.getTime() > i.getTime()) {
		  		notificacion.mostrar_ventana_modal('Error', 'La credencial del usuario ha vencido el '+datos.fecha_expiracion);
		  		return;
		  	}
		  	if(j.getTime() == i.getTime()) {
		  		notificacion.mostrar_ventana_modal('Advertencia', 'Hoy es el �ltimo d�a v�lido de la credencial. Debe pasar por administraci�n para renovarla.');
		  	} else {
		  	  	var one_day=1000*60*60*24;
		  		var diff = Math.ceil((i.getTime() - j.getTime())/one_day); 
				if(diff <= 7) {
					notificacion.mostrar_ventana_modal('Advertencia', 'Quedan '+diff+' d�as de validez de la credencial. Debe pasar por administraci�n para renovarla.');
				}		  	
		  	}
		  	
		  }
		  if(!this.ef('id_cliente').tiene_estado() || confirm('�Seguro que desea cambiar de cliente?')) {
		    this.ef('id_cliente').set_estado(datos.id_cliente);
		    this.ef('id_persona').set_estado(datos.id_persona);
		    this.ef('nombre').set_estado(datos.nombre);
		    this.ef('apellido').set_estado(datos.apellido);
		    this.ef('cuip').set_estado(datos.cuip);
		    this.ef('saldo').set_estado(datos.saldo?datos.saldo:0);
		    this.ef('total').set_estado(datos.saldo?datos.saldo:0);
		  }
		  this.controlador.set_focus();
		}

		";
	}

}
?>