<?php
class cn_asistencia extends toba_cn
{

      function get_tipo_cliente() {
	$sql = "select * from ff_tipo_cliente()";
	return toba::db()->consultar($sql);
      }

      function get_asistencia($datos) {
		$sql = "select * from f_asistencia(".($datos['tipo_cliente']?$datos['tipo_cliente']:'null').", ".$datos['mes'].", ".$datos['anio'].", ".($datos['buscar']?toba::db()->quote($datos['buscar']):'null').")";
/*		if($datos['buscar']) {
			$datos['buscar'] = toba::db()->quote($datos['buscar']);
			$sql .= "where nombre ~* {$datos['buscar']} or apellido ~* {$datos['buscar']} or cuip::varchar ~* {$datos['buscar']} or otro::varchar ~* {$datos['buscar']}";
		}*/
		return toba::db()->consultar($sql);
      }
      
      function importar($datos) {
      	$cods = preg_split('/\W+/', file_get_contents($datos['archivo']['tmp_name']));

	$sede = toba::proyecto()->get_parametro('sede_trabajo');
      	foreach($cods as $cod) {
      		if($cod) {
      			$cod = toba::db()->quote($cod);
			$sql = "select * from f_paso_molinete($cod, ".($datos['sync']=='1'?'true':'false').", '{$datos['fecha']}'::timestamp, '$sede')";

      			//$sql = "select * from f_paso_molinete($cod, ".($datos['sync']=='1'?'true':'false').", '{$datos['fecha']}'::timestamp)";
			toba::db()->consultar($sql);
      		}	
      	}
      }
}

?>
