<?php
class pant_historial extends toba_ei_pantalla
{
	function generar_layout()
	{
	}

}

?>