<?php
include_once('lib/funciones.php');
class ci_asistencia extends toba_ci
{
	private $s__data;
	//-----------------------------------------------------------------------------------
	//---- formulario -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__formulario(toba_ei_formulario $form)
	{
	    $d = toba::memoria()->get_dato('asistencia');
	    if(isset($d)) {
	      $form->set_datos($d);
	    }
	}

	function evt__formulario__modificacion($datos)
	{
	     toba::memoria()->set_dato('asistencia',$datos);
	}

	//-----------------------------------------------------------------------------------
	//---- cuadro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__cuadro(toba_ei_cuadro $cuadro)
	{
	    $d = toba::memoria()->get_dato('asistencia');
	    if(isset($d)) {
	      	$datos = utf8_mdecode($this->cn()->get_asistencia(utf8_mencode($d)));
	      	foreach($datos as $k=>$fila) {
		foreach($fila as $j=>$col) {
		  if(substr($j,0,1) == 'f') {
		    if($col == 't') {
		      $datos[$k][$j] = 'aplicar.jpg';
		    } elseif($col == 'f') {
		      $datos[$k][$j] = 'nulo.jpg';
		    } else {
		      $datos[$k][$j] = 'feriado.jpg';
		    }
		  }
		}
	      }
	      $cuadro->set_datos($datos);
	    }
	}

	function get_tipo_cliente() {
		return utf8_mdecode($this->cn()->get_tipo_cliente());
	}

	function vista_xml($inicial=false, $xmlns=null) {
		$this->xml_set_orientacion('landscape');
		return parent::vista_xml($inicial, $xmlns);
	}
	//-----------------------------------------------------------------------------------
	//---- importar ---------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__importar(toba_ei_formulario $form)
	{
	}

	function evt__importar__modificacion($datos)
	{
		if($datos['archivo'] && $datos['fecha']) {
			$this->cn()->importar($datos);
		}
	}

}
?>