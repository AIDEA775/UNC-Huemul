<?php
class cn_historial extends toba_cn
{
	
	function get_lista($filtro) {
		$cond = '';
		if($filtro) {
			$filtro = $filtro['buscar'];
			$not = false;
			switch($filtro['condicion']) {
				case "comienza_con":
					$filtro['valor']='^'.$filtro['valor'];
					break;
				case "termina_con":
					$filtro['valor']=$filtro['valor'].'$';
					break;
				case "es_igual_a":
					$filtro['valor']='^'.$filtro['valor'].'$';
					break;
				case "es_distinto_de":
					$filtro['valor']='^'.$filtro['valor'].'$';
				case "no_contiene":
					$not=true;
					break;
			}
				
			$filtro = toba::db()->quote(strtolower($filtro['valor']));
			$c = ($not?'!':'')."~ $filtro";
			$cond = " and
					(
					lower(e.nombre) $c or
					lower(e.apellido) $c or
					lower(e.cuip::varchar) $c or
					lower(e.otro) $c
					) 
				";
		}
		$sql = "select 	e.*,
				c.id_cliente 
			from 	fq_persona() e 
			inner join 
				fq_cliente() c 
			on c.id_persona = e.id_persona
			where	c.obsoleto = false".$cond;
		return toba::db()->consultar($sql);
	}
	
	function set_index($datos) {
		unset($this->_memoria['index']);
		if($datos) {
			$this->_memoria['index'] = $datos['id_cliente'];
		}
	}
	
	function get() {
		if(isset($this->_memoria['index'])) {
			$sql = "select  p.*,
				tc.descripcion as tipo_cliente,
			    c.saldo, 
			    c.raciones 
		    from    fq_persona() p 
		    inner join 
			    fq_cliente(".$this->_memoria['index'].") c 
		    on 	    c.id_persona = p.id_persona
		    inner join
		    	fq_tipo_cliente() tc
		    on	tc.id_tipo_cliente = c.id_tipo_cliente 
		    limit 1";
			$n = toba::db()->consultar($sql);
			return $n[0];
		}
		return array();
	}
	
	function get_historial() {
		if(isset($this->_memoria['index'])) {
			$sql = "select * from f_historial(".$this->_memoria['index'].")"; 
			return toba::db()->consultar($sql);
		}
	}
}

?>