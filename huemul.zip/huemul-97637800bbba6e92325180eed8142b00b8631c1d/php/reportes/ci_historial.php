<?php
include_once('lib/ci_comun.php');
include_once('lib/funciones.php');
class ci_historial extends ci_comun 
{

	function conf__fechas(toba_ei_cuadro $cuadro) {
		$cuadro->set_datos($this->cn()->get_historial());
	}
	
	function conf__formulario(toba_ei_formulario $form) {
		$form->set_datos($this->cn()->get());
	}
} 
?>