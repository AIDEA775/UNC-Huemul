<?php
class cuadro extends toba_ei_cuadro
{		

	function vista_excel($salida) {
		if($this->datos_cargados()) {
			foreach($this->_columnas as $k=>$v) {
				$this->_columnas[$k]['formateo'] = 'NULO';
			}
			foreach($this->datos as $n=>$row) {
				foreach ($row as $col=>$val) {
					switch($val) {
						case "nulo.jpg":
							$this->datos[$n][$col] = 'No';
							break;
						case "feriado.jpg":
							$this->datos[$n][$col] = '';
							break;
						case "aplicar.jpg":
							$this->datos[$n][$col] = 'Si';
							break;
					}
				}
			}
		}
		parent::vista_excel($salida);
	}
	
/*	
protected function excel_cuadro(&$filas, &$totales, &$nodo)
{
		$formateo = new $this->_clase_formateo('excel');
		//-- Valores de la tabla
		$datos = array();		
		$estilos = array();
        foreach($filas as $f) {
			$clave_fila = $this->get_clave_fila($f);
			$fila = array();
 			//---> Creo las CELDAS de una FILA <----
 			foreach (array_keys($this->_columnas) as $clave) {
				$valor = "";
                if(isset($this->_columnas[$clave]["clave"])){
					if(isset($this->datos[$f][$clave])){
						$valor_real = $this->datos[$f][$clave];
					}else{
						$valor_real = '';
					}
	                //Hay que formatear?
	                $estilo = array();
	                /*if(isset($this->_columnas[$clave]["formateo"])){
	                    $funcion = "formato_" . $this->_columnas[$clave]["formateo"];
	                    //Formateo el valor
	                    list($valor, $estilo) = $formateo->$funcion($valor_real);
	                    if (! isset($estilo)) {
	                    	$estilo = array();
	                    }
	                } else {*/
//	                	$valor = $valor_real;	
	                //}
					/*switch($valor_real) {
                                case "nulo.jpg":
                                        $valor = 'No';
                                        break;
                                case "feriado.jpg":
                                        $valor = '';
                                        break;
                                case "aplicar.jpg":
                                        $valor = 'Si';
                                        break;
                                default:
                                        $valor = $valor_real;
                        }
	                $estilos[$clave]['estilo'] = $this->excel_get_estilo($this->_columnas[$clave]['estilo']);
	                $estilos[$clave]['estilo'] = array_merge($estilo, $estilos[$clave]['estilo']);
	                $estilos[$clave]['ancho'] = 'auto';
	                if (isset($this->_columnas[$clave]['grupo']) && $this->_columnas[$clave]['grupo'] != '') {
	                	$estilos[$clave]['grupo'] = $this->_columnas[$clave]['grupo'];
	                }
	            }
	            $fila[$clave] = $valor;
            }
            $datos[] = $fila;
        }
		$titulos = $this->excel_get_titulos();

		//-- Para la tabla simple se sacan los totales como parte de la tabla
		$col_totales = array();
		if (isset($totales)) {
			$this->_excel_total_generado = true;
			$col_totales = array_keys($totales);
		}
  		error_log("algo: ".print_r($datos,true));
        //-- Genera la tabla
       $coordenadas = $this->salida->tabla($datos, $titulos, $estilos, $col_totales);
       $nodo['excel_rango'] = $coordenadas;
       $nodo['excel_rango_hoja'] = $this->salida->get_hoja_nombre();
}*/

protected function xml_cuadro(&$filas, &$totales, &$nodo)
	{
		$this->salida .='<'.$this->xml_ns.'datos>';
		$formateo = new $this->_clase_formateo('xml');
		//-- Valores de la tabla
		$datos = array();		
        foreach($filas as $f) {
        	$this->salida .='<'.$this->xml_ns.'fila>';
			$clave_fila = $this->get_clave_fila($f);
			$fila = array();
 			//---> Creo las CELDAS de una FILA <----
 			foreach (array_keys($this->_columnas) as $a) {
				$valor = "";
                if(isset($this->_columnas[$a]["clave"])){
					if(isset($this->datos[$f][$this->_columnas[$a]["clave"]])){
						$valor_real = $this->datos[$f][$this->_columnas[$a]["clave"]];
					}else{
						$valor_real = '';
					}
	                //Hay que formatear?
			$p = toba::proyecto()->get_www('img/');
			switch($valor_real) {
                                case "nulo.jpg":
                                case "feriado.jpg":
                                case "aplicar.jpg":
                                        $valor = $this->xml_imagen($p['path'].$valor_real);
                                        break;
                                default:
                                        $valor = $valor_real;
                        }

/*	                if(isset($this->_columnas[$a]["formateo"])){
	                    $funcion = "formato_" . $this->_columnas[$a]["formateo"];
	                    //Formateo el valor
	                    $valor = $formateo->$funcion($valor_real);
	                } else {
	                	$valor = $valor_real;	
	                }*/
	            }
	            $this->salida .= '<'.$this->xml_ns.'dato clave="'.$this->_columnas[$a]["clave"].'">'.$valor.'</'.$this->xml_ns.'dato>';
            }
            $this->salida .='</'.$this->xml_ns.'fila>';
        }
		list($titulos, $estilos) = $this->xml_get_titulos();
        
        //-- Para la tabla simple se sacan los totales como parte de la tabla
		if (isset($totales) || isset($nodo['acumulador'])) {
			/* Como el xml no admite continuar una tabla luego de construirla (xml_cuadro)
			   Se opta por generar aquí los totales de niveles > 0
			   'rompiendo' la separación establecida por el proceso general en pos de una mejor visualización
			*/
			if (! isset($totales)) {
				$totales = $nodo['acumulador'];
				$nodo['xml_acumulador_generado'] = 1; //Esto evita que se muestre la tabla con totales ya que se va a mostrar en esta misma tabla
			} else {
				$this->_xml_total_generado = true;
			}
			$temp = null;
			$this->xml_get_fila_totales($totales, $temp, true);
		}
		$this->salida .='</'.$this->xml_ns.'datos>';
	}

protected function extender_objeto_js() {
	echo "
		{$this->objeto_js}.evt__pdf = function() {
			window.open(vinculador.crear_autovinculo('vista_xslfo', null, null), '_new');	
			return false;
		};
		
		{$this->objeto_js}.evt__excel = function() {
			{$this->objeto_js}.exportar_excel();
			return false;
		};
	";
}

}
?>
