<?php
class ci_historial_cajero extends toba_ci
{
	private $s__filtro;
	//-----------------------------------------------------------------------------------
	//---- cuadro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__cuadro(toba_ei_cuadro $cuadro)
	{
		if($this->s__filtro) $cuadro->set_datos($this->get_historial($this->s__filtro));
	}

	//-----------------------------------------------------------------------------------
	//---- filtro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__filtro(toba_ei_formulario $form)
	{
		$form->set_datos($this->s__filtro);
	}

	
	
	function evt__filtro__filtrar($datos)
	{
		$this->s__filtro = $datos;
	}

	function evt__filtro__cancelar()
	{
		$this->s__filtro = array();
	}
	
	function get_cajeros() {
		$sql = "
			select 	distinct usuario
			from	venta
			where 	usuario is not null
		";
		
		return toba::db()->consultar($sql);
	}

	function get_historial($filtro) {
		$fecha_desde = toba::db()->quote($filtro['fecha_desde']);
		$fecha_hasta = toba::db()->quote($filtro['fecha_hasta']);
		$usuario = toba::db()->quote($filtro['usuario']);
		
		$sql = "
			select 	fecha,
					apellido||', '||nombre as cliente,
					cuip,
					otro,
					ingreso as monto
			from	venta v
			inner join
					cliente c
			on		c.id_cliente = v.id_cliente
			inner join
					persona p
			on		p.id_persona = c.id_persona
			where	usuario = $usuario
					and fecha::date between $fecha_desde and $fecha_hasta
			order by fecha
		";
		
		return toba::db()->consultar($sql);
	}
	
	
}

?>