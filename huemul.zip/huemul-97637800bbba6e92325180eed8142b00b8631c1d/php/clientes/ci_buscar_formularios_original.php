<?php
class ci_buscar_formularios extends toba_ci
{
	protected $s__filtro = null;
	protected $s__datos_cuadro=array();
	protected $s__eliminar=array();
	protected $s__tienevalor = null;
	//-----------------------------------------------------------------------------------
	//---- cuadro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function ini() {
//$this->s__filtro = array('cargado'=>array('condicion' => 'es_igual_a', 'valor'=>'0'), 'anio'=>array('condicion' => 'contiene', 'valor'=>date('Y')));
                 if(isset($this->s__filtro))  {
                   $this->set_pantalla('pant_inicial');
                  }else{
         $this->s__filtro = array('cargado'=>array('condicion' => 'es_igual_a', 'valor'=>'0'), 'anio'=>array('condicion' => 'contiene', 'valor'=>date('Y')));
                   $this->set_pantalla('pant_filtro');
                 }
        }
	
	function mkInsensitive($texto) {
		$respuesta = '';
		for($i = 0; $i < strlen($texto); $i++) {
			$char = $texto[$i];
			$respuesta .= strtolower($char)==strtoupper($char)?$char:'['.strtolower($char).strtoupper($char).']';
		}
		return $respuesta;
	}
	
	function get_current_year() {
		return date('Y');
	}
	
	function get_filtro() {
		$filtro = '*.xml';
		if(isset($this->s__filtro['nombre']))  {
			$valor = $this->mkInsensitive(str_replace(array(' ', '_'), '*',trim($this->s__filtro['nombre']['valor'])));
			$filtro = '*'.$valor.$filtro;
			$this->s__tienevalor='SI';
		}
		if(isset($this->s__filtro['anio']))  {
			$valor = str_replace(array(' ', '_'), '*',trim($this->s__filtro['anio']['valor']));
			$filtro = $valor.$filtro;
			$this->s__tienevalor='SI';
		}
		return $filtro;
	}
	
	function filtro_a_preg($texto) {
		$respuesta = true;
		if($this->s__filtro) {
			if(isset($this->s__filtro['nombre']))  {
				$valor = str_replace(array(' ', '_'), '.*',trim($this->s__filtro['nombre']['valor']));
				switch($this->s__filtro['nombre']['condicion']) {
					case 'contiene':
						$respuesta= preg_match('/.*'.$valor.'.*/i', $texto);
						break;
					case 'no_contiene':
						$respuesta= !preg_match('/.*'.$valor.'.*/i', $texto);
						break;
					case 'comienza_con':
						$respuesta= preg_match('/^'.$valor.'.*/i', $texto);
						break;
					case 'termina_con':
						$respuesta= preg_match('/.*'.$valor.'$/i', $texto);
						break;
					case 'es_igual_a':
						$respuesta= $this->s__filtro['nombre']['valor'] == $texto;
						break;
					case 'es_distindo_de':
						$respuesta= $this->s__filtro['nombre']['valor'] != $texto;
						break;
				}
			}
			if($respuesta && isset($this->s__filtro['anio'])) {
				list($anio, $mes, $dia) = explode('-',substr($texto, 0, 10));
				$valor = str_replace(array(' ', '_'), '.*',trim($this->s__filtro['anio']['valor']));
				switch($this->s__filtro['anio']['condicion']) {
					case 'entre':
						$respuesta = $anio >= $valor['desde'] && $anio <= $valor['hasta'];
						break;
					case 'es_igual_a':
						$respuesta = $anio == $valor;
						break;
					case 'es_distindo_de':
						$respuesta= $anio != $valor;
						break;
					case 'es_mayor_que':
						$respuesta = $anio > $valor;
						break;
					case 'es_menor_que':
						$respuesta = $anio < $valor;
						break;
					case 'es_mayor_igual_que':
						$respuesta = $anio >= $valor;
						break;
					case 'es_menor_igual_que':
						$respuesta = $anio <= $valor;
						break;						
					
				}
			}
		}
		
		return $respuesta;
	}
	
	function conf__cuadro(toba_ei_cuadro $cuadro)
	{
	
		$sql = "select 	e.formulario,
			c.id_cliente 
		from 	fq_persona() e 
		inner join 
			fq_cliente() c 
		on c.id_persona = e.id_persona
		where	c.obsoleto = false";
		$rows = toba::db()->consultar($sql);
		$fchk=array();
		foreach($rows as $row) {
			if($row['formulario']) {
				$fchk[]=utf8_decode($row['formulario']);
			}
		}
		
		$f = toba::proyecto()->get_www('formulario/no-cargados/forms');
		$dir = $f['path'];
		$forms = array();
		if (is_dir($dir)) {
		    /*if ($dh = opendir($dir)) {
		        while (($file = readdir($dh)) !== false) {
		        	$cargado = in_array($file, $fchk)?'1':'0';
		        	if(substr($file, -4) == '.xml' && $this->filtro_a_preg(substr($file, 0, -4)) && (!isset($this->s__filtro['cargado']) || $this->s__filtro['cargado']['valor'] === $cargado)) {
		        		list($anio, $mes, $dia) = explode('-',substr($file, 0, 10)); 
		        		$forms[] = array('archivo'=>$file, 'fecha'=>$dia.'/'.$mes.'/'.$anio, 'nombre'=>str_replace('_', ' ', substr(utf8_decode($file), 10, -4)), 'cargado'=>$cargado);
		        	}
		        }
		        closedir($dh);
		    }*/
			foreach(glob($dir.'/'.$this->get_filtro()) as $file) {
				$file = basename($file);
				$cargado = in_array($file, $fchk)?'1':'0';
				if(!isset($this->s__filtro['cargado']) || $this->s__filtro['cargado']['valor'] === $cargado) {
					list($anio, $mes, $dia) = explode('-',substr($file, 0, 10));
					$forms[] = array('archivo'=>$file, 'fecha'=>$dia.'/'.$mes.'/'.$anio, 'nombre'=>str_replace('_', ' ', substr(utf8_decode($file), 10, -4)), 'cargado'=>$cargado);
				}
			}
		}
		if($this->s__tienevalor == null){
		} else{
			$this->s__datos_cuadro = $forms;
			$cuadro->set_datos($forms);
		}
	}
	
	function evt__cuadro__seleccion($datos) {
		echo "
		<script>
				window.opener.popup_callback('ef_form_141000308_buscar_formularioformulario', '{$datos['archivo']}', '{$datos['archivo']}');
				window.close();
		</script>
		";
	}

	//-----------------------------------------------------------------------------------
	//---- filtro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function conf__filtro(toba_ei_filtro $filtro)
	{
		if($this->s__filtro) {
			$filtro->set_datos($this->s__filtro);
		}
	}

	function evt__filtro__filtrar($datos)
	{
		$this->s__filtro = $datos;
	}

	function evt__filtro__cancelar()
	{
		$this->s__filtro = null;
		$this->s__tienevalor=null;
	}

       function evt__volver()
        {
          $this->s__filtro=null;
          $this->s__tienevalor=null;
          $this->set_pantalla('pant_filtro');
        }

	//-----------------------------------------------------------------------------------
	//---- Eventos ----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__eliminar()
	{
		if($this->s__eliminar) {
			$f = toba::proyecto()->get_www('formulario/no-cargados/');
			$dir = $f['path'];
			foreach($this->s__eliminar as $elim) {
				$xml = simplexml_load_file($dir.'forms/'.$elim['archivo']);
				if($xml->seccion[0]->row[0]['id'] == 'foto') {
					$fotofile = basename((string)$xml->seccion[0]->row[0]);
					unlink($dir.'img/'.$fotofile);
				}
				unlink($dir.'forms/'.$elim['archivo']);
			}
		}
	}

	function conf_evt__cuadro__eliminar(toba_evento_usuario $evento, $fila)
	{
		if($this->s__datos_cuadro && $this->s__datos_cuadro[$fila]['cargado']=='1') {
			$evento->anular();
		}
	}

	function evt__cuadro__eliminar($datos)
	{
		$this->s__eliminar = $datos;
	}

	/*function extender_objeto_js() {
		echo "{$this->objeto_js}.evt__cuadro__seleccion = function (fila) {
			alert('f: '+fila);
		}";
	}*/
}
?>
