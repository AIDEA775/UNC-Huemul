<?php
include_once('lib/funciones.php');
include_once('lib/wscredencialRest.php');

class cn_clientes extends toba_cn
{
	//private static $ws;
	//private static $wsdl = "http://credencialws.psi.unc.edu.ar:8082/Credencial/?wsdl";
	//private static $wsdl = "http://172.16.248.208:8082/Credencial/?wsdl";
	//private static $id_servicio = 1;
	//protected $formato = array('formato'=>'PDF', 'zoom'=>4.2);
	private static $wsdl = "https://asiruws.unc.edu.ar/soap/Credencial?wsdl";
	protected $s__datos_agregados;
	protected $s__array_agregados;
	protected $us_cred = 'toba';
	protected $pw_cred = 'tobacr3d3nc1al';
        public $s__sede;

	function get_lista($filtro) {
        $s__sede =toba::proyecto()->get_parametro('sede_trabajo');
		$cond = '';
		if($filtro) {
			$filtro = $filtro['buscar'];
			$not = false;
			switch($filtro['condicion']) {
				case "comienza_con":
					$filtro['valor']='^'.$filtro['valor'];
					break;
				case "termina_con":
					$filtro['valor']=$filtro['valor'].'$';
					break;
				case "es_igual_a":
					$filtro['valor']='^'.$filtro['valor'].'$';
					break;
				case "es_distinto_de":
					$filtro['valor']='^'.$filtro['valor'].'$';
				case "no_contiene":
					$not=true;
					break;
			}
			
			$filtro = toba::db()->quote(strtolower($filtro['valor']));
			$c = ($not?'!':'')."~ $filtro";
			$cond = " and
				(
				lower(e.nombre) $c or
				lower(e.apellido) $c or
				lower(e.cuip::varchar) $c or
				lower(e.otro) $c
				) 
			";
		}
		$sql = "select 	e.*,
			c.id_cliente 
		from 	fq_persona() e 
		inner join 
			fq_cliente() c 
		on c.id_persona = e.id_persona
		where	c.sede='$s__sede' and c.obsoleto = false".$cond;
		return toba::db()->consultar($sql);
	}

	function get_persona($cuip) {
		$sql = "select *
		    from (select  p.*, 
				  c.id_tipo_cliente, 
				  c.id_cliente, 
				  c.saldo, 
				  c.codigo, 
				  c.beca, 
				  c.renovado,
				  c.fecha_desde, 
				  c.fecha_hasta,
				  c.raciones,
				  c.sede
			  from    fq_persona() p 
			  left join 
				  fq_cliente() c 
			  on 	    c.id_persona = p.id_persona
			  where p.cuip::varchar = '$cuip' or
			  		(p.otro::varchar = '$cuip' and 
			  		p.cuip is null) 
			  ) a 
		    limit 1";
		$r = toba::db()->consultar($sql);
		return isset($r[0])?$r[0]:$r;
	}

	function get() {
        $s__sede =toba::proyecto()->get_parametro('sede_trabajo');
		if(isset($this->_memoria['index'])) {
			$sql = "select  p.*,
			    c.id_tipo_cliente, 
			    c.id_cliente, 
			    c.saldo, 
			    c.codigo, 
			    c.beca, 
			    c.renovado,
			    c.fecha_desde, 
			    c.fecha_hasta, 
			    c.raciones,
			    c.sede
		    from    fq_persona() p 
		    inner join 
			    fq_cliente(".$this->_memoria['index'].") c 
		    on 	    c.id_persona = p.id_persona
		    where c.sede='$s__sede' 
		    limit 1";
			$n = toba::db()->consultar($sql);
			return $n[0];
		}
		return array();
	}

	function get_tipo_cliente($id=false) {
		$sql = "select * from ff_tipo_cliente()";
		if($id) {
			$sql .= ' where data = '.$id;
		}
		return toba::db()->consultar($sql);
	}

	function get_datos_tipo_cliente($id) {
		$sql = "select * from fq_tipo_cliente($id)";
		$result = toba::db()->consultar($sql);
		return ($result)?$result[0]:array();
	}

	function get_sedes() {
        	$s__sede =toba::proyecto()->get_parametro('sede_trabajo');
		$sql = "select * from sedes where sede='$s__sede'";
		return toba::db()->consultar($sql);
	}

	function get_agregados() {
		if(isset($this->_memoria['index'])) {
			$sql = "select  p.*,
				    a.id_agregado, 
				    a.orden 
			    from    fq_persona() p 
			    inner join 
				    fq_agregado(null::int,".$this->_memoria['index'].", null::int, null::int, false) a 
			    on 	    a.id_persona = p.id_persona
			    where   a.obsoleto=false";
			$this->s__array_agregados = toba::db()->consultar($sql);
			return $this->s__array_agregados;
		}
		return array();
	}

	function validar($code) {
		if($code) {
			try {
				return wscredencial::validar($code)->usuario;
			}catch(Exception $e) {
				toba::notificacion()->error($e->getMessage());
			}
		}
	}
	
	function eliminar() {
		if(isset($this->_memoria['index'])) {
			try {
				$sql = "select * from fq_cliente(".$this->_memoria['index'].")";
				$r = toba::db()->consultar($sql);
				$r=$r[0];
				
				wscredencial::eliminar($r['codigo']);
				
				$sql = "select * from fd_cliente(".$this->_memoria['index'].")";
				toba::db()->consultar($sql);
				toba::notificacion()->info("Usuario Eliminado.");
			}catch(Exception $e) {
				toba::notificacion()->error($e->getMessage()." ".$e->getTraceAsString());
			}
		}
	}

	function regenerar() {
		if(isset($this->_memoria['index'])) {
			try {
				$sql = "select * from fq_cliente(".$this->_memoria['index'].")";
				$r = toba::db()->consultar($sql);
				$r = $r[0];
				$fecha_expiracion = new DateTime();
				$fecha_expiracion->add(new DateInterval('P1Y'));
				
				
				$resp = wscredencial::regenerar($r['codigo']);
				
				$u = $resp->usuario;
				//$r['codigo'] = "'".$u->codigo."'";
				$r['codigo'] =toba::db()->quote($resp['usuario']['codigo']);
				$beca = $r['beca']?$r['beca']:'null';
				$reno = $r['renovado']?"'".$r['renovado']."'":'null';
				$fd = $u->fechaDesde?"'".$u->fechaDesde."'":'null';
				$fh = $u->fechaHasta?"'".$u->fechaHasta."'":'null';
				$saldo = $r['saldo']?$r['saldo']:'null';
				$rac = $r['raciones']?$r['raciones']:'null';
				$sql = "select * from fs_cliente(".$r['id_cliente'].", ".$r['codigo'].", ".$r['id_persona'].", null, ".$r['id_tipo_cliente'].", ".$beca.", ".$reno.", ".$fd.", ".$fh.", ".$saldo.", ".$rac.", false)";
				toba::db()->consultar($sql);
				toba::notificacion()->info("Regeneraci&oacute;n exitosa.");
				//return $resp->reporte;
				return $resp['reporte'];
			}catch(Exception $e) {
				toba::notificacion()->error($e->getMessage());
			}
		}
	}
	
	function renovar() {
		if(isset($this->_memoria['index'])) {
			try {
				$sql = "select * from fq_cliente(".$this->_memoria['index'].")";
				$r = toba::db()->consultar($sql);
				$r = $r[0];
				
				$resp = wscredencial::renovar($r['codigo']);

				$u = $resp->usuario;
				$beca = $r['beca']?$r['beca']:'null';
				$reno = "'".date('Y-m-d')."'";
				$fd = $r['fecha_desde']?"'".$r['fecha_desde']."'":'null';
				//toba::logger()->error(print_r($u,true));
				$fh = $u->fechaExpiracion?"'{$u->fechaExpiracion}'":'null';
				$saldo = $r['saldo']?$r['saldo']:'null';
				$rac = $r['raciones']?$r['raciones']:'null';
				$sql = "select * from fs_cliente(".$r['id_cliente']."::integer, '".$r['codigo']."'::varchar, ".$r['id_persona'].", null, ".$r['id_tipo_cliente'].", ".$beca.", ".$reno."::date, ".$fd."::date, ".$fh."::date, ".$saldo.", ".$rac.", false)";
				toba::db()->consultar($sql);
				toba::notificacion()->info("Renovaci&oacute;n exitosa.");
				//return $m->get_array();
			}catch(Exception $e) {
				toba::notificacion()->error($e->getMessage());
			}
		}
	}

	function set($datos) {
		$this->s__datos = $datos;
	}


	function set_agregados($datos) {
		$this->s__datos_agregados = $datos;
	}
	
	function guardar() {
		if($this->s__datos) {
			$g = $this->get();
			$getCred = false;
			$b64='';
			foreach($g as $k=>$v){
				if(in_array($k,array('foto', 'nombre', 'apellido', 'cuip', 'otro', 'id_tipo_cliente'))) {
					if(($k!='foto' && $this->s__datos[$k] != $v) || ($k=='foto' && $this->s__datos[$k] != $v && !strstr($this->s__datos[$k],$v))) {
						$getCred=true;
						break;
					}	elseif ($k=='foto' && $this->s__datos[$k] != $v) {
						$this->s__datos[$k] = $v;
					}
				} 
			}
			
			if($this->s__datos['generar_credencial']=='true' && (!$g || $getCred)) {
				$params = wscredencial::getParametros();
				$params=$params[0];
				
				$tc = $this->get_tipo_cliente($this->s__datos['id_tipo_cliente']);
			    
				$fecha_expiracion = new DateTime();
				$fecha_expiracion->add(new DateInterval('P1Y'));
				
			    if(isset($this->s__datos['foto'])) {
		    		$d = file_get_contents($this->s__datos['foto']);
		    		if($d) {
		    			$b64 = base64_encode($d);
		    		}
			    } 
			    $cod_us = isset($this->s__datos['cuip'])?$this->s__datos['cuip']:$this->s__datos['otro'];
      			    $usuario = array(
                                                'nombre'=>$this->s__datos['nombre'],
                                                'apellido'=>$this->s__datos['apellido'],
                                                'codigo_usuario'=>$cod_us,
                                                'codigo'=>$this->s__datos['codigo'],
                                                'foto'=>$b64?$b64:$this->s__datos['foto'],
                                                'fecha_expiracion'=>$fecha_expiracion->format('Y-m-d'),
                                                'parametros_usuario'=>array(
                                                                array(
                                                                        'id_parametros'=>$params['id_parametros'],
                                                                        'valor'=>$tc[0]['label']
                                                                )
                                                )
                                );
                                $z = wscredencial::guardar($usuario);
                                $foto = ($z['usuario']['foto'])!=''?toba::db()->quote($z['usuario']['foto']):'null';
                                $cod = toba::db()->quote($z['usuario']['codigo']);
                    	}else {
                                $foto = ($this->s__datos['foto'])!=''?toba::db()->quote($this->s__datos['foto']):'null';
                                $cod = toba::db()->quote($this->s__datos['codigo']);
                        }
                        if(!(toba::db()->quote($z['usuario']['codigo']))) {
                                toba::notificacion()->error('No se pudo obtener un código para el usuario. Operación caelada.');
                                return false;
                        }


 			$id = $this->s__datos['id_persona']!=''?toba::db()->quote($this->s__datos['id_persona']):'null';
                        $cuip = $this->s__datos['cuip']!=''?toba::db()->quote($this->s__datos['cuip']):'null';
                        $otro = $this->s__datos['otro']!=''?toba::db()->quote($this->s__datos['otro']):'null';
                        $nom = $this->s__datos['nombre']!=''?toba::db()->quote($this->s__datos['nombre']):'null';
                        $ape = $this->s__datos['apellido']!=''?toba::db()->quote($this->s__datos['apellido']):'null';
                        $mail = $this->s__datos['mail']!=''?toba::db()->quote($this->s__datos['mail']):'null';
                        $form = $this->s__datos['formulario']!=''?toba::db()->quote($this->s__datos['formulario']):'null';

 			$sql = "select * from fs_persona(".$id.", ".$nom.", ".$ape.", ".$cuip.", ".$otro.", ".$mail.", ".$foto.", ".$form.", false)";
                        $r = toba::db()->consultar($sql);
                        $id_persona=$r[0]['fs_persona'];

                        $idc = $this->s__datos['id_cliente']!=''?toba::db()->quote($this->s__datos['id_cliente']):'null';
                        $idtc = $this->s__datos['id_tipo_cliente']!=''?toba::db()->quote($this->s__datos['id_tipo_cliente']):'null';
                        $beca = $this->s__datos['beca']!=''?toba::db()->quote($this->s__datos['beca']):'null';
                        $reno = $this->s__datos['renovado']!=''?toba::db()->quote($this->s__datos['renovado']):"'".date("d/m/Y")."'";
                        $fd = ($z['usuario']['fecha_emision'])!=''?toba::db()->quote($z['usuario']['fecha_emision']):'null';
                        $fh = ($z['usuario']['fecha_expiracion'])!=''?toba::db()->quote($z['usuario']['fecha_expiracion']):'null';
                        $saldo = $this->s__datos['saldo']!=''?toba::db()->quote($this->s__datos['saldo']):'null';
                        $rac = $this->s__datos['raciones']!=''?toba::db()->quote($this->s__datos['raciones']):'null';

                        $sede = $this->s__datos['sede']!=''?toba::db()->quote($this->s__datos['sede']):'null';

$sql = "select * from fs_cliente(".$idc.", ".$cod.", ".$id_persona.", null, ".$idtc.", ".$beca.", ".$reno.", ".$fd.", ".$fh.", ".$saldo.", ".$rac.",".$sede.", false)";

		    $r = toba::db()->consultar($sql);
		    $this->_memoria['index']=$r[0]['fs_cliente'];
		    if($idtc) {
		    	$tipo_cliente = $this->get_datos_tipo_cliente($idtc);
		    	if($tipo_cliente['max_personas_agregar'] != 0 && isset($this->s__datos_agregados)) {
		    		foreach($this->s__datos_agregados as $k=>$dag) {
		    			if(isset($dag['nombre']) && $dag['nombre'] != '' && $dag['apex_ei_analisis_fila'] != 'B') {
  						$id = $dag['id_persona']!=''?toba::db()->quote($dag['id_persona']):'null';
                                                $cuip = $dag['cuip']!=''?toba::db()->quote($dag['cuip']):'null';
                                                $otro = $dag['otro']!=''?toba::db()->quote($dag['otro']):'null';
                                                $nom = $dag['nombre']!=''?toba::db()->quote($dag['nombre']):'null';
                                                $ape = $dag['apellido']!=''?toba::db()->quote($dag['apellido']):'null';
                                                $mail = $dag['mail']!=''?toba::db()->quote($dag['mail']):'null';
                                                if(isset($dag['foto']) && $dag['foto']) {
                                        $foto = 'img/'.$dag['apellido'].'_'.$dag['cuip'].'.'.substr($dag['foto']['name'], strrpos($dag['foto']['name'], '.'));
                                                        $img = toba::proyecto()->get_www_temp($dag['foto']['name']);
                                                        move_uploaded_file($foto, $img['path']);
                                                        if(!file_exists($foto)) {
                                                                $foto = 'null';
                                                        }
                                                } else {
                                                        $foto = 'null';
                                                }

             					$sql = "select * from fs_persona(".$id.", ".$nom.", ".$ape.", ".$cuip.", ".$otro.", ".$mail.", ".$foto.", false)";
                                                $ida = $dag['id_agregado']!=''?toba::db()->quote($dag['id_agregado']):'null';
                                                $orden = $dag['orden']!=''?toba::db()->quote($dag['orden']):'null';
                                                $r = toba::db()->consultar($sql);

                                               $sql = 'select * from fs_agregado('.$ida.', '.$this->_memoria['index'].', '.$r[0]['fs_persona'].', '.$orden.', false)';
                                                $r = toba::db()->consultar($sql);
                                        } elseif ($dag['apex_ei_analisis_fila'] == 'B' && array_key_exists($k, $this->s__array_agregados)) {
                                                $sql = "select * from fd_agregado(".$this->s__array_agregados[$k]['id_agregado'].")";
                                                $r = toba::db()->consultar($sql);
                                        }

		    		}
		    	}
		    }
			 return $z['reporte'];
		}
	}

	function set_index($datos=false) {
		unset($this->_memoria['index']);
		unset($this->s__datos);
		unset($this->s__datos_agregados);
		if($datos) {
	  		$this->_memoria['index'] = $datos['id_cliente'];
		} 
	}

	
}

?>
