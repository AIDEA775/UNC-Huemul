<?php
class cn_tipo_clientes extends toba_cn
{
    function get_lista() {
	$sql = "select * from fq_tipo_cliente() where obsoleto=false";
	return toba::db()->consultar($sql);
    }

    function get() {
	if(isset($this->_memoria['index'])) {
	    $sql = "select * from fq_tipo_cliente(".$this->_memoria['index'].")";
	    $n = toba::db()->consultar($sql);
	    $n = $n[0];
	    list($n['renovacion'], $n['intervalo']) = explode(' ', $n['renovacion']);
	    return $n;
	}
	return array();
    }
    
    function eliminar() {
	if(isset($this->_memoria['index'])) {
	  $sql = "select * from fd_tipo_cliente(".$this->_memoria['index'].")";
	  toba::db()->consultar($sql);
	}
    }


    function set($datos) {
	$this->s__datos = $datos;
    }
    
    function guardar() {
	if($this->s__datos) {
	    $id = $this->s__datos['id_tipo_cliente']!=''?$this->s__datos['id_tipo_cliente']:'null';
	    $desc = $this->s__datos['descripcion']!=''?"'".$this->s__datos['descripcion']."'":'null';
	    $tb = $this->s__datos['tipo_beca']!=''?"'".$this->s__datos['tipo_beca']."'":'null';
	    $tm = $this->s__datos['tipo_monto']!=''?"'".$this->s__datos['tipo_monto']."'":'null';
	    $beca = $this->s__datos['beca']!=''?$this->s__datos['beca']:'null';
	    $td = $this->s__datos['tipo_duracion']!=''?"'".$this->s__datos['tipo_duracion']."'":'null';
	    $tr = $this->s__datos['tipo_renovacion']!=''?"'".$this->s__datos['tipo_renovacion']."'":'null';
	    $reno = $this->s__datos['renovacion']!=''?"'".$this->s__datos['renovacion'].(($td=="'R'" && $tr=="'C'")?' '.$this->s__datos['intervalo']:'')."'":'null';
	    $max = $this->s__datos['max_personas_agregar']!=''?$this->s__datos['max_personas_agregar']:'null';
	    if($this->s__datos['pase']!='')
			  $pa = "'".$this->s__datos['pase']."'";
			else
			  $pa = 'null';
	    $sql = "select * from fs_tipo_cliente(".$id.", ".$desc.", ".$tb.", ".$tm.", ".$beca.", ".$td.", ".$tr.", ".$reno.", ".$max.",".$pa.", false)";
	    $r = toba::db()->consultar($sql);
	    $this->_memoria['index']=$r[0]['fs_tipo_cliente'];
	}
    }

    function set_index($datos=false) {
	if($datos) {
	  $this->_memoria['index'] = $datos['id_tipo_cliente'];
	} else {
	  unset($this->_memoria['index']);
	}
    }
}

?>
