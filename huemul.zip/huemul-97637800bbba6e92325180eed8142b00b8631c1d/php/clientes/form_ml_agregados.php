<?php
class form_ml_agregados extends toba_ei_formulario_ml
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Validacion de EFs -----------------------------------
		
		{$this->objeto_js}.evt__nombre__validar = function(fila)
		{
		    if(this.ef('nombre').ir_a_fila(fila).get_estado()=='') {
			for(var i in this.efs()) {
			    if((i=='apellido' || i=='cuip') && this.ef(i).ir_a_fila(fila).get_estado()!='') {
				return false;
			    }
			}
		    }
		    return true;
		}
		
		{$this->objeto_js}.evt__apellido__validar = function(fila)
		{
		    if(this.ef('apellido').ir_a_fila(fila).get_estado()=='') {
			for(var i in this.efs()) {
			    if((i=='nombre' || i=='cuip') && this.ef(i).ir_a_fila(fila).get_estado()!='') {
				return false;
			    }
			}
		    }
		    return true;
		}
		
		{$this->objeto_js}.evt__cuip__validar = function(fila)
		{
		    if(this.ef('otro').ir_a_fila(fila).tiene_estado()) {
			return true;
		    } else {
			return es_cuit(this.ef('cuip').ir_a_fila(fila).get_estado());
		    }
		}

		{$this->objeto_js}.evt__otro__validar = function(fila)
		{
		    if(this.ef('otro').ir_a_fila(fila).tiene_estado()) {
			return true;
		    } else {
			return es_cuit(this.ef('cuip').ir_a_fila(fila).get_estado());
		    }
		}

		{$this->objeto_js}.evt__cuip__procesar = function(es_inicial, fila)
		{
		  if(es_cuit(this.ef('cuip').ir_a_fila(fila).get_estado())) {
		      var datos = {'cuip': this.ef('cuip').ir_a_fila(fila).get_estado(), 'fila': fila};
		      this.controlador.ajax('get_persona', datos, this, this.set_persona);
		  }
		}

		{$this->objeto_js}.evt__otro__procesar = function(es_inicial, fila)
		{
		  if(this.ef('otro').ir_a_fila(fila).get_estado()) {
		      var datos = {'cuip': this.ef('otro').ir_a_fila(fila).get_estado(), 'fila': fila};
		      this.controlador.ajax('get_persona', datos, this, this.set_persona);
		  }
		}

		{$this->objeto_js}.evt__foto__procesar = function(es_inicial, fila)
		{
		  if(es_inicial) {
		      var img=document.getElementById('img_'+fila);
		      if(this.ef('foto').ir_a_fila(fila).tiene_estado()) {
			img.src = this.ef('foto').ir_a_fila(fila).get_estado();
		      } else {
			img.src = null;
		      }
		  }
		}

		function eliminarFotoML(fila) {
		  {$this->objeto_js}.ef('foto').ir_a_fila(fila).set_estado(null);
		}

		{$this->objeto_js}.set_persona = function(datos)
		{
		  if(datos.persona!=null) {
		      if(datos.persona.id_cliente != null) {
			this.ef('cuip').ir_a_fila(datos.fila).resetear_estado();
			notificacion.mostrar_ventana_modal('Error de Usuario', 'El cuip '+datos.cuip+' ya pertenece al cliente '+datos.persona.nombre+' '+datos.persona.apellido+'.');
		      } else  {
			this.ef('id_persona').ir_a_fila(datos.fila).set_estado(datos.persona.id_persona?datos.persona.id_persona:'');
			this.ef('nombre').ir_a_fila(datos.fila).set_estado(datos.persona.nombre?datos.persona.nombre:'');
			this.ef('apellido').ir_a_fila(datos.fila).set_estado(datos.persona.apellido?datos.persona.apellido:'');
			this.ef('mail').ir_a_fila(datos.fila).set_estado(datos.persona.mail?datos.persona.mail:'');
			/*this.ef('foto').ir_a_fila(datos.fila).set_estado(datos.persona.foto);
			if(this.ef('foto').ir_a_fila(datos.fila).tiene_estado()) {
			  var img=document.getElementById('img_'+datos.fila);
			  img.src = this.ef('foto').ir_a_fila(datos.fila).get_estado();
			}*/
		      }
		  }
		}
		";
	}


	function generar_layout()
	{
	  echo "<div id='aggmsg' style='color: red'></div>";
	  parent::generar_layout();
	}

	protected function generar_layout_fila($clave_fila)
	{
		foreach ($this->_lista_ef_post as $ef){
			//--- Multiplexacion de filas
			if($ef != 'foto') {
				$this->_elemento_formulario[$ef]->ir_a_fila($clave_fila);
				$id_form = $this->_elemento_formulario[$ef]->get_id_form();					
				echo "<td class='{$this->estilo_celda_actual}' id='cont_$id_form'>\n";		
				echo "<div id='nodo_$id_form'>\n";			
				$this->generar_input_ef($ef);
				echo "</div>";		
				echo "</td>\n";		
			} elseif($ef == 'foto') {
				$this->_elemento_formulario['foto']->ir_a_fila($clave_fila);
				$id_form = $this->_elemento_formulario['foto']->get_id_form();
				echo "<td class='{$this->estilo_celda_actual}' id='cont_$id_form'>\n";		
				echo "<img id='img_".$clave_fila."'/>";
				echo "<div id='nodo_$id_form'>\n";			
				$this->generar_input_ef('foto');
				echo " <a href='#' onclick='eliminarFotoML($clave_fila)'>Eliminar</a>";
				echo "</div>";
				echo "</td>\n";		
			}
		}
	}

	protected function generar_formulario_encabezado()
	{
		//¿Algún EF tiene etiqueta?
		$alguno_tiene_etiqueta = false;
		foreach ($this->_lista_ef_post as $ef) {
			if ($this->_elemento_formulario[$ef]->get_etiqueta() != '') {
        		$alguno_tiene_etiqueta = true;
        		break;
			}
		}
		if ($alguno_tiene_etiqueta) {
			echo "<thead id='cabecera_{$this->objeto_js}'>\n";		
			//------ TITULOS -----	
			echo "<tr>\n";
			$primera = true;
			foreach ($this->_lista_ef_post	as	$ef){
				if($ef != 'foto_carga' && $ef != 'imagen') {
				    $id_form = $this->_elemento_formulario[$ef]->get_id_form_orig();	
				    $extra = '';
				    if ($primera) {
					    $extra = 'colspan="'.($this->_colspan + 1).'"';
				    }
				    echo "<th $extra id='nodo_$id_form' class='ei-ml-columna'>\n";
				    if ($this->_elemento_formulario[$ef]->get_toggle()) {
					    $this->_hay_toggle = true;
					    $id_form_toggle = 'toggle_'.$id_form;
					    echo "<input id='$id_form_toggle' type='checkbox' class='ef-checkbox' onclick='{$this->objeto_js}.toggle_checkbox(\"$ef\")' />";
				    }
				    $this->generar_etiqueta_columna($ef);
				    echo "</th>\n";
				    $primera = false;
				}
			}
			if ($this->_info_formulario['filas_ordenar'] && $this->_ordenar_en_linea) {
				echo "<th class='ei-ml-columna'>&nbsp;\n";
				echo "</th>\n";
			}		
	        //-- Eventos sobre fila
			if($this->cant_eventos_sobre_fila() > 0){
				foreach ($this->get_eventos_sobre_fila() as $evento) {
					echo "<th class='ei-ml-columna ei-ml-columna-extra'>&nbsp;\n";
					if (toba_editor::modo_prueba()) {
						echo toba_editor::get_vinculo_evento($this->_id, $this->_info['clase_editor_item'], $evento->get_id())."\n";
					}
		            echo "</th>\n";
				}
			}		
			if ($this->_info_formulario['filas_agregar'] && $this->_borrar_en_linea) {
				echo "<th class='ei-ml-columna'>&nbsp;\n";
				echo "</th>\n";				
			}
			echo "</tr>\n";
			echo "</thead>\n";
		}
	}
}
?>
