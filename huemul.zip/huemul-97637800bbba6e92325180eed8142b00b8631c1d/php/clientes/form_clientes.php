<?php
class form_clientes extends toba_ei_formulario
{

	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		
		/**
		 * M�todo que se invoca al cambiar el valor del ef en el cliente
		 * Se dispara inicialmente al graficar la pantalla, enviando en true el primer par�metro
		 */
		var g_tc=null
		{$this->objeto_js}.ef('id_cliente').ocultar();
		
		{$this->objeto_js}.evt__id_tipo_cliente__procesar = function(es_inicial)
		{
		    if(this.ef('id_cliente').get_estado()=='') {
				this.controlador.ocultar_boton('eliminar');
				this.controlador.ocultar_boton('regenerar');
		    } else {
		    	this.controlador.dep('buscar_formulario').ocultar();
		    	this.controlador.dep('credencial').ocultar();
		    }
		
		    var tc = this.ef('id_tipo_cliente').get_estado();
		    if(g_tc == null || g_tc != tc) {
				g_tc = tc;
				for(var id in this.efs()) {
			    	switch(id) {
					case 'renovado':
					case 'fecha_desde':
					case 'fecha_hasta':
				    	this.ef(id).ocultar();
				    	break;
			    	}
				}
				this.controlador.dep('agregados').ocultar();
				this.controlador.ocultar_boton('renovar');
				if(tc != 'nopar')
			    	this.controlador.ajax('set_tipo_cliente', tc, this, this.set_efs);
		    }
		}
		
		{$this->objeto_js}.set_efs = function(datos) {
		    if(datos['tipo_duracion'] == 'R') {
			this.ef('renovado').mostrar();
			this.controlador.mostrar_boton('renovar');
		    } else if (datos['tipo_duracion'] == 'F') {
			this.ef('fecha_desde').mostrar();
			this.ef('fecha_hasta').mostrar();
		    }
		    if(datos['max_personas_agregar'] != 0 && datos['max_personas_agregar'] != null) {
				this.controlador.dep('agregados').mostrar();
				var aggmsg = document.getElementById('aggmsg');
				if(datos['max_personas_agregar'] > 0) {
				  aggmsg.innerHTML = (datos['max_personas_agregar']>1)?'S&oacute;lo se tendr&aacute;n en cuenta las '+datos['max_personas_agregar']+' primeras personas.':'S&oacute;lo se tendr&aacute; en cuenta la primera persona.';
				} else {
				  aggmsg.style.color='red';
				  aggmsg.innerHTML = '';
				}
		    }
		}
		
		{$this->objeto_js}.evt__cuip__procesar = function(es_inicial)
		{
		  if(es_cuit(this.ef('cuip').get_estado())) {
		      var cuip = {'cuip':this.ef('cuip').get_estado()};
		      this.controlador.ajax('get_persona', cuip, this, this.set_persona);
		  }
		}
		
		{$this->objeto_js}.evt__otro__procesar = function(es_inicial)
		{
		  if(this.ef('otro').tiene_estado() && !es_cuit(this.ef('cuip').get_estado())) {
		      var cuip = {'cuip':this.ef('otro').get_estado()};
		      this.controlador.ajax('get_persona', cuip, this, this.set_persona);
		  }
		}
		
		{$this->objeto_js}.set_persona = function(datos)
		{
		  if(datos.persona!=null) {
		      if(datos.persona.id_cliente != null && this.ef('id_cliente').get_estado()=='') {
			this.controlador.ocultar_boton('guardar');
			this.controlador.ocultar_boton('eliminar');
			notificacion.mostrar_ventana_modal('Error de Usuario', 'El cuip '+datos.cuip+' ya pertenece al cliente '+datos.persona.nombre+' '+datos.persona.apellido+'.');
		      } else if (this.ef('id_cliente').get_estado()=='') {
			datos.persona.id_persona && this.ef('id_persona').set_estado(datos.persona.id_persona);
			datos.persona.nombre && this.ef('nombre').set_estado(datos.persona.nombre);
			datos.persona.apellido && this.ef('apellido').set_estado(datos.persona.apellido);
			datos.persona.mail && this.ef('mail').set_estado(datos.persona.mail);
			datos.persona.foto && this.ef('foto').set_estado(datos.persona.foto);
			if(this.ef('foto').tiene_estado()) {
			  var img = document.getElementById('final');
			  img.src = this.ef('foto').get_estado();
			}
		      }
		  }
		}
		
		{$this->objeto_js}.evt__cuip__validar = function()
		{
		  var val = this.ef('otro').tiene_estado() || this.ef('cuip').tiene_estado() || this.controlador.dep('buscar_formulario').ef('formulario').tiene_estado() || this.controlador.dep('credencial').ef('credencial').tiene_estado();
		  return val;
		}
		
		{$this->objeto_js}.evt__otro__validar = function()
		{
		  var val = this.ef('otro').tiene_estado() || this.ef('cuip').tiene_estado() || this.controlador.dep('buscar_formulario').ef('formulario').tiene_estado() || this.controlador.dep('credencial').ef('credencial').tiene_estado();
		  return val;
		}

		{$this->objeto_js}.evt__nombre__validar = function()
		{
		  var val = this.ef('nombre').tiene_estado() || this.controlador.dep('buscar_formulario').ef('formulario').tiene_estado() || this.controlador.dep('credencial').ef('credencial').tiene_estado();
		  return val;
		}
		
		{$this->objeto_js}.evt__apellido__validar = function()
		{
		  var val = this.ef('apellido').tiene_estado() || this.controlador.dep('buscar_formulario').ef('formulario').tiene_estado() || this.controlador.dep('credencial').ef('credencial').tiene_estado();
		  return val;
		}
		
		{$this->objeto_js}.evt__id_tipo_cliente__validar = function()
		{
			var val = this.ef('id_tipo_cliente').tiene_estado() || this.controlador.dep('buscar_formulario').ef('formulario').tiene_estado() || this.controlador.dep('credencial').ef('credencial').tiene_estado();
		  	return val;
		}
		
		
		//---- Procesamiento de EFs --------------------------------
		
		{$this->objeto_js}.evt__foto__procesar = function(es_inicial)
		{
		  if(es_inicial) {
		      var img = document.getElementById('final');
		//		      var el = document.getElementById(this.ef('foto')._id_form+'_desicion');
		      if(this.ef('foto').tiene_estado()) {
				img.src = this.ef('foto').get_estado();
		      } else {
				img.src = 'img/nofoto.jpg';
		      }
		      this.foto_cargada = true;
		  }
		}
		
		function eliminarFoto() {
		  {$this->objeto_js}.ef('foto').set_estado(null);
		}

		";
	}


	/** 
	 * Permite modificar la forma en que se grafica el formulario, por defecto un ef sobre el otro
	 */
	
	function generar_layout()
	{
		$a = toba::proyecto()->get_www('formulario/');
		echo "<link rel='stylesheet' href='{$a['url']}css/imgareaselect-animated.css' type='text/css'/>";
	    echo '<div style="width: 100%; position:relative; height: 330px">';
	    $this->generar_html_ef('id_persona');
	    $this->generar_html_ef('cuip');
	    $this->generar_html_ef('otro');
	    $this->generar_html_ef('nombre');
	    $this->generar_html_ef('apellido');
	    $this->generar_html_ef('mail');
	    $this->generar_html_ef('id_cliente');
	    $this->generar_html_ef('id_tipo_cliente');
	    echo $this->get_html_ef_modif('codigo');
	    $this->generar_html_ef('beca');
	    $this->generar_html_ef('renovado');
	    $this->generar_html_ef('fecha_desde');
	    $this->generar_html_ef('fecha_hasta');
	    $this->generar_html_ef('saldo');
	    $this->generar_html_ef('raciones');
	    $this->generar_html_ef('sede');
	    echo $this->get_html_ef_modif('formulario', 2);
	   // echo '<div style="position:absolute; right: 20px; top: 20px; width: 200px; height: 200px"><img id="img" style="height: 200px; width: 200px"/>';
	    /*echo toba_js::incluir('http://ajax.googleapis.com/ajax/libs/prototype/1.6.1.0/prototype.js');
	    echo toba_js::incluir('http://ajax.googleapis.com/ajax/libs/scriptaculous/1.8.2/scriptaculous.js');
	    echo toba_js::incluir($a['url'].'js/cropper.js');
	    echo toba_js::incluir($a['url'].'js/webtoolkit.aim.js');*/
	    
	    echo toba_js::incluir($a['url'].'js/jquery-1.4.3.min.js');
	    echo toba_js::incluir($a['url'].'js/jquery-ui-1.8.13.custom.min.js');
	    echo toba_js::incluir($a['url'].'js/jquery.imgareaselect.min.js');
	    echo toba_js::incluir($a['url'].'js/webtoolkit.aim.js');
	    echo toba_js::incluir($a['url'].'js/webcam.js');
	    echo toba_js::abrir();
	    echo "
	    webcam.set_swf_url( '{$a['url']}libs/webcam.swf' );
		webcam.set_api_url( '{$a['url']}php/test.php' );
		webcam.set_quality( 90 ); // JPEG quality (1 - 100)
		webcam.set_shutter_sound( true, '{$a['url']}libs/shutter.mp3' ); // play shutter click sound
		
		webcam.set_hook( 'onComplete', 'my_completion_handler' );
		var crop = {};
		var cropperInstance;
		function take_snapshot() {
			// take snapshot and upload to server
			//document.getElementById('upload_results').innerHTML = '<h1>Uploading...</h1>';
			webcam.snap();
		}
		
		function my_completion_handler(msg) {
			// extract URL out of PHP output
			if (msg.match(/(http\:\/\/\S+)/)) {
				var image_url = RegExp.$1;
				// show JPEG image in page
				crop.img = image_url;
				document.getElementById('testImage').src = image.url;
				// reset camera for another shot
				webcam.reset();
				imagenCargada();
			}
			else alert('PHP Error: ' + msg);
		}

		function startCrop() {
			if($('#testImage').data('imgAreaSelect')) {
			  $('#testImage').imgAreaSelect({instance: true}).update();
			} else {
				$('#testImage').imgAreaSelect({
					onSelectEnd: onEndCrop,
					aspectRatio: '4:4',
					x1: 0,
					y1: 0,
					x2: 30,
					y2: 40,
					parent: '#crpDiv'
				});
			}
		}

		function onEndCrop( img, selection) {
			crop.x = selection.x1;
			crop.y = selection.y1;
			crop.w = selection.width;
			crop.h = selection.height;
			crop.img = img.src;
		}
		
		// basic example
		function doCrop() {
		    $('#crpDiv')[0].style.display = 'none';
		    $('#finDiv')[0].style.display = '';
		    $.ajax({
		    	url: '{$a['url']}php/crop.php', 
				data: crop,
				success: function(data){
			    //alert(transport.responseText);
			    document.getElementById('final').src = data;
			    {$this->objeto_js}.ef('foto').set_estado(data);
				}
		      }
		    );
		}

		function upload() {
		  var frm = document.getElementById('frm1');
		  frm.submit();
		}

		function imagenCargada(count) {
		  if(!count || count==0) {
		    $('#selDiv')[0].style.display = 'none';
		    $('#crpDiv')[0].style.display = '';
		    count==0;
		  }
		  var i = document.getElementById('testImage');

		  if(i.style.width || i.style.height) {
		    i.style.width= null;
		    i.style.height= null;
		  }

		  if(count > 100) {
		    if(confirm('No se pudo iniciar cropper. ¿Intentar nuevamente?')) {
		      imagenCargada();
		    }
		    return;
		  }

		  count++;

		  if(!i.complete && i.clientWidth == 0) {
		    setTimeout('imagenCargada('+count+')', 100);
		  } else {
		    var w = 320;
		    var h = 240;
		    crop.ratio = i.clientWidth>i.clientHeight?w/i.clientWidth:h/i.clientHeight;
		    var cw = (i.clientWidth*crop.ratio)+'px';
		    var ch = (i.clientHeight*crop.ratio)+'px';
		    i.style.width= cw;
		    i.style.height= ch;
		    startCrop();
		  }
		}

		function chImg() {
		  $('#fotoInp')[0].value = '';
		  $('#finDiv')[0].style.display = 'none';
		  $('#crpDiv')[0].style.display = 'none';
		  $('#selDiv')[0].style.display = '';
		}
		
		";
	    echo toba_js::cerrar();
	    
	    echo "
	    <style>
	  .imgcnt {
	    border: 1px solid black;
	    padding: 5px;
	    top: 0px;
	    position: absolute;
	    right: 20px;
	    height: 320px;
	    width: 320px;
	    text-align: center;
	  }
	</style>
	<div id='selDiv' class='imgcnt'  style='display:none;'>
	  <button onclick=\"$('#snap')[0].style.display='none';$('#up')[0].style.display='';\">Subir Imagen</button> <button onclick=\"$('#up')[0].style.display='none';$('#snap')[0].style.display='';\">Tomar Foto</button>

	  <hr/>
	  <!-- Next, write the movie to the page at 320x240 -->
	  <div id='snap'  style='display: none'>
	  <script language='JavaScript'>
		  document.write( webcam.get_html(320, 240) );
	  </script>
	  
	  <!-- Some buttons for controlling things -->
	  <hr/>
	  <form>
		  <input type='button' value='Configurar...' onClick='webcam.configure()'>
		  &nbsp;&nbsp;
		  <input type='button' value='Tomar Fotografía' onClick='take_snapshot()'>
	  </form>
	  
	  </div>
	  <div id='up'>
	  <form id='frm1' enctype='multipart/form-data' action='{$a['url']}php/upload.php' method='POST' target='ifr1'/>
	    Subir <input id='fotoInp' name='foto' type='file' onchange='upload()'/>
	  </form>
	  <iframe id='ifr1' name='ifr1' style='display:none'></iframe>
	  </div>
	</div>
	<div id='crpDiv' class='imgcnt' style='display:none;'>
	  <button onclick='chImg()'>Cambiar Imagen</button> <button onclick='doCrop()'>Cortar</button>
	  <hr/>
	  <img id='testImage'/>
	</div>
	<div id='finDiv' class='imgcnt'>
	  <button onclick='chImg()'>Cambiar Imagen</button>
	  <hr/>
	  <img id='final' style='height: 240px; width: 240px; border: 1px solid black'/></br>
	  ".$this->get_input_ef('foto')."	  
	</div>
	";
	    
/*	    echo '<div id="cont_foto">';
	    echo 
		if() {
	    	echo ' <a href="#" onclick="eliminarFoto()">Eliminar</a>';
	    }
	    echo $this->get_input_ef('foto_cargar');
	    echo '</div>';
	    echo '<div id="cont_foto_carga" style="display:none">';
	    echo $this->get_input_ef('foto_carga');
	    echo '</div>';

	    echo '</div>';*/
	    echo '</div>';
	}
	
	protected function get_html_ef_modif($ef, $modo=1, $ancho_etiqueta=null, $con_etiqueta=true)
	{
		$props = parse_ini_file(toba::proyecto()->get_path().'/propiedades.ini',true);
		$props = $props[$props['ambiente']];
		$salida = '';
		if (! in_array($ef, $this->_lista_ef_post)) {
			//Si el ef no se encuentra en la lista posibles, es probable que se alla quitado con una restriccion o una desactivacion manual
			return;
		}
		$clase = 'ei-form-fila';
		$estilo_nodo = "";
		$id_ef = $this->_elemento_formulario[$ef]->get_id_form();
		if (! $this->_elemento_formulario[$ef]->esta_expandido()) {
			$clase .= ' ei-form-fila-oculta';
			$estilo_nodo = "display:none";
		}
		if (isset($this->_info_formulario['resaltar_efs_con_estado']) 
				&& $this->_info_formulario['resaltar_efs_con_estado'] && $this->_elemento_formulario[$ef]->seleccionado()) {
			$clase .= ' ei-form-fila-filtrada';
		}
		$es_fieldset = ($this->_elemento_formulario[$ef] instanceof toba_ef_fieldset);
		if (! $es_fieldset) {							//Si es fieldset no puedo sacar el <div> porque el navegador cierra visualmente inmediatamente el ef.
			$salida .= "<div class='$clase' style='$estilo_nodo' id='nodo_$id_ef'>\n";
		}
		if ($this->_elemento_formulario[$ef]->tiene_etiqueta() && $con_etiqueta) {
			$salida .= $this->get_etiqueta_ef($ef, $ancho_etiqueta);
			//--- El margin-left de 0 y el heigth de 1% es para evitar el 'bug de los 3px'  del IE
			$ancho = isset($ancho_etiqueta) ? $ancho_etiqueta : $this->_ancho_etiqueta;
			$salida .= "<div id='cont_$id_ef' style='margin-left:$ancho;_margin-left:0;_height:1%;'>\n";
			switch($modo) {
				case 1:
					$salida .= $this->get_input_ef($ef);
					$salida .= toba_recurso::imagen_toba('objetos/editar.gif', true, null, null, 'Editar', null, "onclick=\"{$this->objeto_js}.ef('$ef').set_solo_lectura(false)\"");
					break;
				case 2:
					$salida .= "<div style='display: none'>".$this->get_input_ef($ef)."</div>";
					if($this->_elemento_formulario[$ef]->tiene_estado()) {
						$salida .= "<a target='_new' href='formulario/ver_form.php?f=".urlencode($this->_elemento_formulario[$ef]->get_estado())."&cargado=".($this->_elemento_formulario['id_persona']->tiene_estado()?'S':'N');
						if($this->_elemento_formulario['foto']->tiene_estado()) {
							$salida .='&foto='.urlencode($this->_elemento_formulario['foto']->get_estado()); 
						}
						$salida .= "'>Ver Formulario</a>";
					}
			}
			$salida .= "</div>";
			if (isset($this->_info_formulario['expandir_descripcion']) && $this->_info_formulario['expandir_descripcion']) {
				$salida .= '<span class="ei-form-fila-desc">'.$this->_elemento_formulario[$ef]->get_descripcion().'</span>';
			}

		} else {		
			switch($modo) {
				case 1:
					$salida .= $this->get_input_ef($ef);
					$salida .= toba_recurso::imagen_toba('objetos/editar.gif', true, null, null, 'Editar', null, "onclick=\"{$this->objeto_js}.ef('$ef').set_solo_lectura(false)\"");
					break;
				case 2:
					$salida .= "<div style='display: none'>".$this->get_input_ef($ef)."</div>";
					if($this->_elemento_formulario[$ef]->tiene_estado()) {
						$salida .= "<a target='_new' href='formulario/ver_form.php?f=".urlencode($this->_elemento_formulario[$ef]->get_estado());
						if($this->_elemento_formulario['foto']->tiene_estado()) {
							$salida .='&foto='.urlencode($this->_elemento_formulario['foto']->get_estado()); 
						}
						$salida .= "'>Ver Formulario</a>";
					}
					break;
			}
		}
		if (! $es_fieldset) {
			$salida .= "</div>\n";
		}
		return $salida;		
	}

}
?>
