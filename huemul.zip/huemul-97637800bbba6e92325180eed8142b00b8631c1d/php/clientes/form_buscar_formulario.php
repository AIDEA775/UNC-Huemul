<?php
class form_buscar_formulario extends toba_ei_formulario
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		
		/*{$this->objeto_js}.evt__formulario__procesar = function(es_inicial)
		{
			if(!es_inicial) {
				this.controlador.dep('formulario')._evento.validar = this.ef('formulario').get_estado() == '';
			}
		}*/
		
		/*{$this->objeto_js}.evt__modificacion = function()
		{
			this.controlador.dep('formulario')._evento.validar = true;
		}*/
		";
	}

}

?>