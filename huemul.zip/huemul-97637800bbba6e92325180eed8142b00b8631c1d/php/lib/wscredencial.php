<?php
/**

=== wscredencial ===

Clase PHP para conectarse a WebServices de Credenciales.

Es requerimiento tener instalado el módulo soap de php.

Antes de empezar a utilizar esta clase, se debe setear la propiedad $id_servicio con el valor correspondiente.

== Como utilizar ==

Desde su archivo php incluir la clase:

include_once('/path/a/wscredencial.php');

Y luego llamar a la función deseada rodeada por try / catch:

try {
  wscredencial::validar($codigoDeLaTarjeta);
} catch(Exception $e) {
  //hacer algo
}

== Formato de Respuesta ==

Todas las funciones devuelven un objeto con la siguiente firma:

* respuesta:
 + estado: Estado de la transacción. Si no es igual a 0, significa que hubo un error.
 + mensaje: Mensaje de la transacción. Si estado != 0, aquí está el mensaje de error.
 + usuario: Es un objeto con los datos del usuario.
  - nombre: Nombre del usuario.
  - apellido: Apellido del usuario.
  - codigoUsuario: Identificador del usuario (dni, cuil, etc).
  - codigo: Código de barra de la credencial.
  - fechaEmision: Fecha de emision de credencial.
  - fechaExpiracion: Fecha de expiración de credencial.
 + reporte: Array con reportes codificados en base64
 + batch: Array de usuario (se llena sólo cuando se llama a la funcion "batch")

*/
class WSCredencialException extends Exception {
	private $resp;
	
	function __construct($resp) {
		parent::__construct($resp->mensaje);
		$this->resp = $resp;
	}
	
	public function getResp() {
		return $this->resp;
	}
}

class wscredencial 
{
	private static $ws;
	//private static $wsdl = "http://credencialws.psi.unc.edu.ar:8082/Credencial/?wsdl";
	private static $wsdl = null;
	
	private static $id_servicio = 1;//Número que identifica al servicio
	protected static $formato = array('formato'=>'PDF', 'zoom'=>4.2);

	
	/**
	  Asegura que la credencial sea válida.
	  
	  Devuelve los datos del usuario
	*/
	static function validar($codigo) {
		if(isset($codigo)) {
			$resp = self::ws()->check(array("arg0"=>$codigo))->return;

			if($resp->estado != 0) {
				throw new WSCredencialException($resp);
			}
			return $resp;
		}
	}
	
	/**
	  Elimina una credencial.
	  
	  No devuelve datos.
	*/
	static function eliminar($codigo) {
		if(isset($codigo)) {
			$resp = self::ws()->delete(array("arg0"=>$codigo))->return;

			if($resp->estado < 0) {
				throw new WSCredencialException($resp);
			}
			return $resp;
		}
	}

	/**
	  Regenera la credencial. Utilizar esta opción cuando el usuario perdió la credencial.
	  
	  Devuelve datos del usuario con nuevo código de credencial.
	  
	  Devuelve PDF con la nueva credencial.
	*/
	static function regenerar($codigo) {
		if(isset($codigo)) {
			$resp = self::ws()->remake(array("arg0"=>$codigo, "arg1"=>self::$formato))->return;
			
			if($resp->estado != 0) {
				throw new WSCredencialException($resp);
			}
			return $resp;
		}
	}
	
	/**
	  Renueva la credencial. Utilizar esta opción cuando el usuario tiene su credencial vencida.
	  
	  Devuelve datos del usuario con nueva fecha de vencimiento.
	  
	  No devuelve PDF. La credencial es la misma.
	*/
	
	static function renovar($codigo) {
		if(isset($codigo)) {
			$resp = self::ws()->renew(array("arg0"=>$codigo))->return;
			if($resp->estado != 0) {
				throw new WSCredencialException($resp);
			}
			return $resp;
		}
	}
	
	/**
	  Crea / Actualiza una credencial.
	
	  $usuario debe ser un array con el siguiente formato:
		array(
		  'nombre'=>Nombre de la persona,
		  'apellido'=>Apellido de la persona,
		  'codigoUsuario'=>Identificador de la persona (dni, cuit, etc),
		  'codigo'=>Código actual de la credencial.. si este parámetro es null, se crea una credencial nueva,
		  'foto'=>La foto pasada como texto codificado en base64,
		  'fechaExpiracion'=>Fecha de expiración en formato 'YYYY-MM-DD'
		)
		
	  Devuelve datos del usuario.
	  
	  Devuelve PDF con la nueva credencial.
	*/

	static function guardar($usuario) {
		if(isset($usuario)) {
			$payload = array(
				'arg0'=>wscredencial::$id_servicio,
				'arg1'=>$usuario,
				'arg2'=>self::$formato
			);
			$resp = self::ws()->save($payload)->return;
			if($resp->estado != 0) {
				throw new WSCredencialException($resp);
			} 
			return $resp;
		}
	}

	
	static function getParametros() {
		return self::ws()->getParametros(array('arg0'=>self::$id_servicio))->return;
	}
	/**
	  Crea / Actualiza credenciales por lote
	
	  $usuarios debe ser un array, donde cada elemento del mismo debe ser de tipo "usuario", definido en el comentario de la función "guardar"
	
	  Devuelve array con datos de todos los usuarios
	  
	  Devuelve PDF con varias credenciales por página
	*/
	
	static function batch($usuarios) {
		if(isset($usuarios)) {
			$payload = array(
				'arg0'=>wscredencial::$id_servicio,
				'arg1'=>$usuarios
			);
			$resp = self::ws()->batch($payload)->return;
			if($resp->estado != 0) {
				throw new WSCredencialException($resp);
			} 
			return $resp;
		}
	}
	
	protected static function ws() {
		if(!self::$ws) {
			$path = realpath(dirname(__FILE__).'/../../propiedades.ini');
			$props = parse_ini_file($path,true);
			$props = $props[$props['ambiente']];
			self::$ws = new SoapClient($props['credencialws_wsdl'], array(
				"trace"=>1,
				"exceptions"=>1,
				/*"soap_version"=>SOAP_1_1,
				'stream_context' => stream_context_create(array('http' => array('header' => 'Content-Type: text/xml'))),
				"classmap"=>array("parametrosDO"=>"ParametrosDO")*/
			));
		}
		return self::$ws;
	}
	
}

?>
