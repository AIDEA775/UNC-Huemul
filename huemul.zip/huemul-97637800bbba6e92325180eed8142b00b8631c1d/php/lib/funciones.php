<?php
	function utf8_mencode($data) {
		if(is_array($data)) {
			$dt = array();
			foreach($data as $k => $d) {
				$dt[utf8_encode($k)]=utf8_mencode($d);
			}
			return $dt;
		} elseif(is_string($data)) {
			return utf8_encode($data);
		}
		return $data;
	}

	function utf8_mdecode($data) {
		if(is_array($data)) {
			$dt = array();
			foreach($data as $k => $d) {
				$dt[utf8_decode($k)]=utf8_mdecode($d);
			}
			return $dt;
		} elseif(is_string($data)) {
			return utf8_decode($data);
		}
		return $data;
	}
?>
