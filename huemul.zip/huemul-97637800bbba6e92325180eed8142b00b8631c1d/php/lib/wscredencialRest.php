<?php
/**

=== wscredencial ===

Clase PHP para conectarse a WebServices de Credenciales.

Antes de empezar a utilizar esta clase, se debe setear la propiedad $id_servicio con el valor correspondiente.

== Como utilizar ==

Desde su archivo php incluir la clase:

include_once('/path/a/wscredencialRest.php');

Y luego llamar a la función deseada rodeada por try / catch:

try {
  wscredencial::validar($codigoDeLaTarjeta);
} catch(Exception $e) {
  //hacer algo
}

== Formato de Respuesta ==

Todas las funciones devuelven un objeto con la siguiente firma:

* respuesta:
 + estado: Estado de la transacción. Si no es igual a 0, significa que hubo un error.
 + mensaje: Mensaje de la transacción. Si estado != 0, aquí está el mensaje de error.
 + usuario: Es un objeto con los datos del usuario.
  - nombre: Nombre del usuario.
  - apellido: Apellido del usuario.
  - codigoUsuario: Identificador del usuario (dni, cuil, etc).
  - codigo: Código de barra de la credencial.
  - fechaEmision: Fecha de emision de credencial.
  - fechaExpiracion: Fecha de expiración de credencial.
 + reporte: Array con reportes codificados en base64
 + batch: Array de usuario (se llena sólo cuando se llama a la funcion "batch")

*/

class wscredencial
{

	private static $ws;
	private static $url = "https://asiruws.unc.edu.ar/rest";
	
	private static $id_servicio = 1;//Número que identifica al servicio
	//private static $id_servicio = 7;//Número que identifica al servicioSe supone que este es para Manuel Belgrano

	protected static $formato = array('formato'=>'PDF', 'zoom'=>4.2);


	/**
	  Asegura que la credencial sea válida.

	  Devuelve los datos del usuario
	*/
	static function validar($codigo) {
		if(isset($codigo)) {
			$resp = wscredencial::get('/'.$codigo);

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
	  Elimina una credencial.

	  No devuelve datos.
	*/
	static function eliminar($codigo) {
		if(isset($codigo)) {
			$resp = wscredencial::delete('/'.$codigo);

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
	  Regenera la credencial. Utilizar esta opción cuando el usuario perdió la credencial.

	  Devuelve datos del usuario con nuevo código de credencial.

	  Devuelve PDF con la nueva credencial.
	*/
	static function regenerar($codigo) {
		if(isset($codigo)) {
			$resp = wscredencial::put('/'.$codigo, array('formato'=>wscredencial::$formato));
			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
	  Renueva la credencial. Utilizar esta opción cuando el usuario tiene su credencial vencida.

	  Devuelve datos del usuario con nueva fecha de vencimiento.

	  No devuelve PDF. La credencial es la misma.
	*/

	static function renovar($codigo) {
		if(isset($codigo)) {
			$resp = wscredencial::put('/'.$codigo.'/renew');

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
	  Crea / Actualiza una credencial.

	  $usuario debe ser un array con el siguiente formato:
		array(
		  'nombre'=>Nombre de la persona,
		  'apellido'=>Apellido de la persona,
		  'codigo_usuario'=>Identificador de la persona (dni, cuit, etc),
		  'codigo'=>Código actual de la credencial.. si este parámetro es null, se crea una credencial nueva,
		  'foto'=>La foto pasada como texto codificado en base64,
		  'fecha_expiracion'=>Fecha de expiración en formato 'YYYY-MM-DD',
		  'parametros_usuario'=>array(
		  	array('id_parametros'=>Id del parámetro,	'valor'=>Valor del parámetro),
		  	...
		  )
		)

	  Devuelve datos del usuario.

	  Devuelve PDF con la nueva credencial.
	*/

	static function guardar($usuario) {
		if(isset($usuario)) {
			$resp = wscredencial::post('/', array('idServicio'=>wscredencial::$id_servicio, 'credencial'=>$usuario, 'formato'=>wscredencial::$formato));

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
	  Crea / Actualiza credenciales por lote

	  $usuarios debe ser un array, donde cada elemento del mismo debe ser de tipo "usuario", definido en el comentario de la función "guardar"

	  Devuelve array con datos de todos los usuarios

	  Devuelve PDF con varias credenciales por página
	*/

	static function batch($usuarios) {
		if(isset($usuarios)) {
			$resp = wscredencial::post('/batch', array('idServicio'=>wscredencial::$id_servicio, 'creds'=>$usuarios));

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			return $resp['data'];
		}
	}

	/**
		Obtiene los parámetros especificados para el servicio.

		Devuelve un array con el id del parametro y valor por defecto.
	*/

	static function getParametros() {
		if(isset(wscredencial::$id_servicio)) {
			$resp = wscredencial::get('/parametros/'.wscredencial::$id_servicio);

			if($resp['code'] > 400) {
				throw new Exception($resp['data']);
			}
			
			return $resp['data'];
		}
	}

	protected static function post($path, $data) {
		return wscredencial::request($path, array(CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query($data)));
	}

	protected static function delete($path) {
		return wscredencial::request($path, array(CURLOPT_CUSTOMREQUEST=>'DELETE'));
	}

	protected static function put($path, $data) {
		return wscredencial::request($path, array(CURLOPT_CUSTOMREQUEST=>'PUT', CURLOPT_POSTFIELDS=>http_build_query($data)));
	}

	protected static function get($path) {
		return wscredencial::request($path);
	}

	protected static function request($path, $options=array()) {
		$ch = curl_init();
		$defaults = array(
			CURLOPT_URL => wscredencial::$url.$path,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_VERBOSE => true
		);
		$params = array();
		foreach($defaults as $k=>$v) {
			$params[$k] = $v;
		}
		foreach($options as $k=>$v) {
			$params[$k] = $v;
		}
		curl_setopt_array($ch, $params);

		$data = curl_exec($ch);

		$info = curl_getinfo($ch);
		if(strpos($info['content_type'], 'application/json') !== false) {
			$data = json_decode($data,true);
		}

		curl_close($ch);

		return array('code'=>$info['http_code'], 'data'=>$data);
	}

}

?>
