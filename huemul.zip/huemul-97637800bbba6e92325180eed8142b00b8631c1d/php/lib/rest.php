<?php 
class rest {
	const GET = 0;
	const POST = 1;
	const PUT = 2;
	const DELETE = 3;
	protected $maxRedirects = 32;
	
	protected $url;
	protected $redirects=0;
	
	function __construct($url, $port=false) {
		$this->url = parse_url($url);
		if($port) $this->url['port'] = $port;
		if(!isset($this->url['port']) || !$this->url['port']) $this->url['port'] = 80; 
		if(!isset($this->url['path'])) $this->url['path']='';
		if(substr($this->url['path'], -1) != '/') $this->url['path'] .= '/'; 
	}
	
	function request($path, $method=rest::GET, $data=false) {
		$path = substr($path,0,1)=='/'?substr($path, 1):$path;
		$sock = fsockopen($this->url['host'], $this->url['port'], $errno, $error);
		if(!$sock) throw new Exception($error);
		$d = '';
		$h = array('Host: '.$this->url['host']);
		if($data && is_array($data)) {
			$d = http_build_query($data, 'op_');
		}
		switch($method) {
			case rest::GET:
				array_unshift($h, 'GET '.$this->url['path'].$path.($d?'?'.$d:'').' HTTP/1.0');
				$d='';
				break;
			case rest::POST:
				array_unshift($h, 'POST '.$this->url['path'].$path.' HTTP/1.0');
				$h[] = 'Content-Length: '.strlen($d);
				$h[] = 'Content-Type: application/x-www-form-urlencoded';
				break;
			case rest::PUT:
				array_unshift($h, 'PUT '.$this->url['path'].$path.' HTTP/1.0');
				$h[] = 'Content-Length: '.strlen($d);
				$h[] = 'Content-Type: application/x-www-form-urlencoded';
				break;
			case rest::DELETE:
				array_unshift($h, 'DELETE '.$this->url['path'].$path.($d?'?'.$d:'').' HTTP/1.0');
				$d='';
				break;
		}
		fwrite($sock, implode("\r\n", $h)."\r\n\r\n".$d);
		$resp = '';
		while(($m = fgets($sock))!== false) {
			$resp .= $m;
		}
		fclose($sock);
		list($hs, $body) = explode("\r\n\r\n", $resp);
		
		preg_match("/HTTP\/\d\.\d (\d\d\d).*/", $hs, $m);
		if($m[1][0] > 3) {
			throw new Exception($body);
		}
		
		$hs = explode("\r\n", $hs);
		$headers = array();
		foreach($hs as $k=>$h) {	
			$t = explode(':', $h);
			if(count($t)>1) {
				$headers[trim($t[0])] = trim($t[1]);
			}
		}
		if(isset($headers['Location'])) {
			if($this->redirects > $this->maxRedirects) {
				$this->redirects = 0;
				throw new Exception("Too many redirects.");
			}
			return $this->request($headers['Location'], $method);
			
		}  
		$this->redirects = 0;
		if($body) {
			return json_decode($body, true);
		}
		return array();
	}
}
?>