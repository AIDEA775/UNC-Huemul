<?php
include_once('ci_comun.php');
include_once('lib/funciones.php');
include_once('lib/wscredencialRest.php');
class ci_cliente extends ci_comun 
{
	protected $s__form_path;
	//private static $alfresco_url = null;
	//private static $alfresco_usr = null;
	//private static $alfresco_pwd = null;
	public $s__sede;
	
	function ini() {
		$props = parse_ini_file(toba::proyecto()->get_path().'/propiedades.ini',true);
		$props = $props[$props['ambiente']];
		//self::$alfresco_url=$props['alfresco_url'];
		//self::$alfresco_usr=$props['alfresco_usr'];
		//self::$alfresco_pwd=$props['alfresco_pwd'];
		$s__sede=toba::proyecto()->get_parametro('sede_trabajo');
		/*$a = toba::proyecto()->get_www('formulario/');
		$cb = array(
			/*'prototype'); 
			'scriptaculous',
			'jquery-1.4.3.min',
			'jquery-ui-1.8.13.custom.min',
			'jquery.imgareaselect.min',
			'webtoolkit.aim'
		);
		toba_js::agregar_consumos_basicos($cb);*/
	}
	/*function conf() {
		$this->dep('formulario')->ef('id_cliente')->mostrar(false);
		
	}*/

	function conf__seleccion() {
		$this->s__form_path=null;
	}
	
	function get_nombre_archivo($archivo, $algo) 
	{
		echo "nombre archivo ",$archivo, $algo;
		exit;
		return $algo[$archivo];
	}
	
	function conf__agregados(toba_ei_formulario $form)
	{
		$form->set_datos(utf8_mdecode($this->cn()->get_agregados()));
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 * @param array $datos Estado del componente al momento de ejecutar el evento. El formato es el mismo que en la carga de la configuraci�n
	 */
	function evt__agregados__modificacion($datos)
	{
		$this->cn()->set_agregados(utf8_mencode($datos));
	}

	function get_tipo_cliente() {
		return utf8_mdecode($this->cn()->get_tipo_cliente());
	}

	function get_sedes() {
		return $this->cn()->get_sedes();
	}

	function ajax__set_tipo_cliente($tc, toba_ajax_respuesta $respuesta) {
		$datos = utf8_mdecode($this->cn()->get_datos_tipo_cliente(utf8_mencode($tc)));
		$respuesta->set($datos);
	}

	function ajax__get_persona($datos, toba_ajax_respuesta $respuesta) {
		$datos['persona'] = utf8_mdecode($this->cn()->get_persona(utf8_mencode($datos['cuip'])));
		$respuesta->set($datos);
	}
	
	function evt__regenerar() {
		$r = $this->cn()->regenerar();
     	if($r) {
	     	$this->open_file($r);
     	}
	}
	
	function evt__renovar() {
		$this->cn()->renovar();
	}
	
        //-----------------------------------------------------------------------------------
        //---- JAVASCRIPT -------------------------------------------------------------------
        //-----------------------------------------------------------------------------------


        function extender_objeto_js()
        {
                echo "
                //---- Eventos ---------------------------------------------

                {$this->objeto_js}.evt__renovar = function()
                {
/*		    var d = new Date();
		    var dia = d.getDate()<10?'0'+d.getDate():d.getDate();
		    var mes = d.getMonth()+1;
		    mes = mes<10?'0'+mes:mes;
		    this.dep('formulario').ef('renovado').set_estado(dia+'/'+mes+'/'+d.getFullYear());
		    return false;*/
                }
/*
                {$this->objeto_js}.evt__regenerar = function()
                {
		    var cuip = this.dep('formulario').ef('cuip').tiene_estado()?this.dep('formulario').ef('cuip').get_estado():this.dep('formulario').ef('otro').get_estado();
		    var rand = Math.random()+'';
		    this.dep('formulario').ef('codigo').set_estado(cuip+rand.substr(3,6));
		    return false;
                }*/
                ";
        }

     function evt__guardar() {
     	$r = $this->cn()->guardar();
     	if($r) {
	     	$this->open_file($r);
     	}
     }

    function open_file($rs) {
    	$files = array();
    	$base = tempnam("/tmp", 'comedor');
    	if(!is_array($rs)) {
    		$rs = array($rs);
    	}
    	foreach($rs as $k=>$r) {
    		$n = $base.'_'.$k;
    		file_put_contents($n, base64_decode($r));
    		$files[] = "'".urlencode($n)."'";
    	}
    	echo toba_js::abrir();
    	echo "
    			var results = [".implode(', ',$files)."];
    			function orderedOpen(n) {
    					if(results.length > n) {
    						var w = window.open('open_file.php?f='+results[n], '_new');
    						w.onunload = function() {
    							setTimeout('orderedOpen('+(n+1)+')', 1000);
    						};
    					}
    			}
    			orderedOpen(0);
    	";
    	echo toba_js::cerrar();
    }
     
	function conf__formulario(toba_ei_formulario $form)
	{
		$datos = utf8_mdecode($this->cn()->get());
	
		if(!isset($datos['formulario']) && $this->s__form_path) {
			$datos['formulario'] = $this->s__form_path;
		}
		if(isset($datos['foto']) && substr($datos['foto'],0,4) != 'http') {
			//$fu = self::getFotoUrl();
			//$datos['foto'] = $fu['url'].$datos['foto']."?alf_ticket=".$fu['ticket'];
			$lugar='https:'."//asiruws.unc.edu.ar/foto/";
                        //ei_arbol($lugar);
                        //$datos['foto'] = $fu['url'].$datos['foto']."?alf_tick$
                        $datos['foto'] = $lugar.$datos['foto'];

		}
		$form->set_datos($datos);
	}

	function evt__formulario__modificacion($datos)
	{
		if(strpos($datos['foto'], 'asiruws.unc.edu.ar')!==false) {
			$datos['foto'] = basename(parse_url($datos['foto'], PHP_URL_PATH));
		}
		$this->cn()->set(utf8_mencode($datos));
	}
	
	static function getFotoUrl() {
		$o = json_decode(file_get_contents(self::$alfresco_url."/login?u=".self::$alfresco_usr."&pw=".self::$alfresco_pwd."&format=json"));
		return array('url'=>self::$alfresco_url."/node/content/workspace/SpacesStore/", 'ticket'=>$o?$o->data->ticket:'');
	}
	
	//-----------------------------------------------------------------------------------
	//---- buscar_formulario ------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__buscar_formulario__modificacion($datos)
	{
		$f = toba::proyecto()->get_www('formulario/no-cargados/forms/'.$datos['formulario']);
		$form = array();
		if(is_file($f['path'])) {
			$xml = simplexml_load_file($f['path']);
			$tmp = $xml->xpath("//row[@id_elems = 'nombre']");
			foreach($tmp as $t) {
				$form['nombre']= (string) $t;
			}
			$tmp = $xml->xpath("//row[@id_elems = 'apellido']");
			foreach($tmp as $t) {
				$form['apellido']= (string) $t;
			}
			$tmp = $xml->xpath("//row[@id_elems = 'cuip0 cuip1 cuip2']");
			foreach($tmp as $t) {
				$form['cuip']= str_replace(array('-',' '),'',(string) $t);
			}
			$tmp = $xml->xpath("//row[@id_elems = 'pasap']");
			foreach($tmp as $t) {
				$form['otro']= (string) $t;
			}
			$tmp = $xml->xpath("//row[@id_elems = 'mail']");
			foreach($tmp as $t) {
				$form['mail']= (string) $t;
			}
			$tmp = $xml->xpath("//row[@id = 'foto']");
			foreach($tmp as $t) {
				$form['foto']= "formulario/no-cargados/img/".basename((string) $t);
			}
			$tmp = $xml->xpath("//seccion[2]");
			foreach($tmp as $t) {
				$tc = $this->get_tipo_cliente();
				foreach($tc as $k=>$v) {
					if(strtolower($t['titulo']) == strtolower($v['label'])) {
						$form['id_tipo_cliente'] = $v['data'];
					}
				}
			}
			$this->s__form_path = $datos['formulario'];
		}
		$this->dep('formulario')->set_datos($form);
	}
	
	function evt__credencial__modificacion($datos) {
		$usuario = $this->cn()->validar($datos['credencial']);
		if(isset($usuario['usuario']['foto']) && substr($usuario['usuario']['foto'],0,4) != 'http') {
			//$fu = self::getFotoUrl();
			//$form['foto'] = $fu['url'].$usuario->foto."?alf_ticket=".$fu['ticket'];
			 $lugar='https:'."//asiruws.unc.edu.ar/foto/";
                        //$datos['foto'] = $fu['url'].$datos['foto']."?alf_ticket=".$fu['ticket'];
                        //$datos['foto'] = $lugar.$datos['foto'];
			 $form['foto'] =$lugar.$usuario['usuario']['foto'];

		}
		
		$form['nombre']= trim($usuario['usuario']['nombre']);
		$form['apellido']= trim($usuario['usuario']['apellido']);
		if(toba_ef_cuit::validar_cuit($usuario['usuario']['codigo_usuario']) === true) {
			$form['cuip']= $usuario['usuario']['codigo_usuario'];
		} else {
			$form['otro']= $usuario['usuario']['codigo_usuario'];
		}
		$form['codigo']= $usuario['usuario']['codigo'];
		$form['generar_credencial']='false';
		$this->dep('formulario')->set_datos($form);
	}

}
?>
