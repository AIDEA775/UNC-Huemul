<?php
class cn_evento extends toba_cn
{
	protected $s__datos = null;
	protected $s__datos_cliente = null;

	function get_lista() {
		$sql = "select * from fq_evento() where obsoleto = false";
		return toba::db()->consultar($sql);
	}

	function get_lista_cliente() {
		if(isset($this->_memoria['index'])) {
		  $sql = "select  c.*,
				  tc.descripcion as tipo_cliente 
			  from 	  fq_cliente() c 
			  inner join 
				  fq_evento(".$this->_memoria['index'].") e 
			  on 	  e.id_evento = c.id_evento 
				  and e.obsoleto = false 
			  inner join 
				  fq_tipo_cliente() tc 
			  on 	  tc.id_tipo_cliente = c.id_tipo_cliente 
			  where   c.obsoleto = false 
			  order by c.codigo";
	  		return toba::db()->consultar($sql);
		}
		return array();
	}
	 
	function get() {
		if(isset($this->_memoria['index'])) {
			$sql = "select 	id_evento,
	    				nombre, 
	    				date_part('year',fecha_desde)::varchar||'-'||date_part('month',fecha_desde)::varchar||'-'||date_part('day',fecha_desde)::varchar as fecha_desde, 
	    				date_part('year',fecha_hasta)::varchar||'-'||date_part('month',fecha_hasta)::varchar||'-'||date_part('day',fecha_hasta)::varchar as fecha_hasta, 
	    				cantidad, 
	    				obsoleto 
	    		from 	fq_evento(".$this->_memoria['index'].")";
			$n = toba::db()->consultar($sql);
			return $n[0];
		}
		return array();
	}

	function get_cliente() {
		if(isset($this->_memoria['index_cliente'])) {
			$sql = "select * from fq_cliente(".$this->_memoria['index_cliente'].")";
			$n = toba::db()->consultar($sql);
			return $n[0];
		}
		return array();
	}

	function get_tipo_cliente() {
		$sql = "select * from ff_tipo_cliente()";
		return toba::db()->consultar($sql);
	}

	function eliminar() {
		if(isset($this->_memoria['index'])) {
	  $sql = "select * from fd_evento(".$this->_memoria['index'].")";
	  toba::db()->consultar($sql);
		}
	}

	function eliminar_cliente($clientes=false) {
		if($clientes) {
			foreach($clientes as $c) {
	  			$sql = "select * from fd_cliente(".$c['id_cliente'].")";
	  			toba::db()->consultar($sql);
			}
		} elseif(isset($this->_memoria['index_cliente'])) {
	  		$sql = "select * from fd_cliente(".$this->_memoria['index_cliente'].")";
	  		toba::db()->consultar($sql);
		}
	}

	function set($datos) {
		$this->s__datos = $datos;
	}

	function set_cliente($datos) {
		$this->s__datos_cliente = $datos;
	}

	function guardar() {
		if($this->s__datos) {
			$id = $this->s__datos['id_evento']!=''?$this->s__datos['id_evento']:'null';
			$nom = $this->s__datos['nombre']!=''?"'".$this->s__datos['nombre']."'":'null';
			$fd = $this->s__datos['fecha_desde']!=''?"'".$this->s__datos['fecha_desde']."'":'null';
			$fh = $this->s__datos['fecha_hasta']!=''?"'".$this->s__datos['fecha_hasta']."'":'null';
			$cant = $this->s__datos['cantidad']!=''?$this->s__datos['cantidad']:'null';
			$sql = "select * from fs_evento(".$id."::integer, ".$nom."::varchar, ".$fd."::date, ".$fh."::date, ".$cant."::integer, false)";
			$r = toba::db()->consultar($sql);
			$this->_memoria['index']=$r[0]['fs_evento'];
		}
	}

	function guardar_cliente() {
		if($this->s__datos_cliente) {
			$datos = $this->get_cliente();
			$idtc = $this->s__datos_cliente['id_tipo_cliente']!=''?$this->s__datos_cliente['id_tipo_cliente']:'null';
			$beca = $this->s__datos_cliente['beca']!=''?$this->s__datos_cliente['beca']:'null';
			$fd = $this->s__datos_cliente['fecha_desde']!=''?"'".$this->s__datos_cliente['fecha_desde']."'":'null';
			$fh = $this->s__datos_cliente['fecha_hasta']!=''?"'".$this->s__datos_cliente['fecha_hasta']."'":'null';
			$saldo = $this->s__datos_cliente['saldo']!=''?$this->s__datos_cliente['saldo']:'null';
			$rac = $this->s__datos_cliente['raciones']!=''?$this->s__datos_cliente['raciones']:'null';
			$sql = "select * from fs_cliente(".$datos['id_cliente'].", '".$datos['codigo']."'::varchar, null, ".$datos['id_evento'].", ".$idtc.", ".$beca.", '".$datos['renovado']."', ".$fd.", ".$fh.", ".$saldo.", ".$rac.", false)";
			$r = toba::db()->consultar($sql);
			$this->_memoria['index_cliente']=$r[0]['fs_cliente'];
		}
	}

	/*function generar_clientes() {
		$datos = $this->get_lista_cliente();
		if($this->s__datos) {
	  for($i = 0; $i<($this->s__datos['cantidad']-count($datos)); $i++) {
	  	$rnd = abs(rand(000000000000000, 999999999999999));
	  	$cod = '02';
	  	$len = strlen($rnd);
	  	if($len < 15) {
	  		for($j=0; $j<15-$len; $j++) {
	  			$cod .= '0';
	  		}
	  	}
	  	$cod = $cod.$rnd;
	  	$fd = $this->s__datos['fecha_desde']!=''?"'".$this->s__datos['fecha_desde']."'":'null';
	  	$fh = $this->s__datos['fecha_hasta']!=''?"'".$this->s__datos['fecha_hasta']."'":'null';
	  	$idtc = $this->s__datos['id_tipo_cliente']!=''?$this->s__datos['id_tipo_cliente']:'null';
	  	$beca = $this->s__datos['beca']!=''?$this->s__datos['beca']:'null';
	  	$rac = $this->s__datos['raciones']!=''?$this->s__datos['raciones']:'null';
	  	$sql = "select * from fs_cliente(null, ".$cod."::bigint, null, ".$this->s__datos['id_evento'].", ".$idtc.", ".$beca.", '".date("d/m/Y")."', ".$fd.", ".$fh.", null, ".$rac.")";
	  	toba::db()->consultar($sql);
	  }
		}
	}*/

	function set_index($datos=false) {
		if($datos) {
	  $this->_memoria['index'] = $datos['id_evento'];
		} else {
	  unset($this->_memoria['index']);
		}
	}

	function set_index_cliente($datos=false) {
		if($datos) {
	  $this->_memoria['index_cliente'] = $datos['id_cliente'];
		} else {
	  unset($this->_memoria['index_cliente']);
		}
	}
	
	function get_servicios() {
		try {
			$payload = array(
				'servicio'=>'comedor',
				'login'=>array(
					'us'=>'toba', 
					'pw'=>'toba'
					)
			);
			$m = $this->ws("http://credencial.unc.edu.ar/obtenerServicios", $payload);
			$u = $m->get_array();
			if(!isset($u['servicios'])) {
				throw new Exception($r->wsf()->str);
			}
			return $u['servicios'];
		}catch(Exception $e) {
			toba::notificacion()->error($e->getMessage());
		}
	}
	
	function get_usuarios($datos, $filtro) {
		if($this->s__datos) {
			try {
				$servicios = array();
				foreach($datos['id_servicios'] as $v) {
					$servicios[]['id_servicio'] = $v; 
				} 
				$payload = array(
					'login'=>array(
						'us'=>'toba', 
						'pw'=>'toba'
						),
					'servicios'=>$servicios
				);
				$m = $this->ws("http://credencial.unc.edu.ar/obtenerUsuariosServicios", $payload);
				$u = $m->get_array();
				if(!isset($u['usuarios'])) {
					throw new Exception($r->wsf()->str);
				}
				$datos = $u['usuarios'];
				$act = $this->get_lista_cliente($filtro);
				$c = count($act);
				foreach($datos as $k=>$v) {
					if($this->s__datos['cantidad'] <= $c) break;
					$inAct = false;
					foreach($act as $a) {
						if($v['codigo'] == $a['codigo']) {
							$inAct=true;
							break;
						}
					}
					if($inAct) continue;
				  	$cod = "'".$v['codigo']."'";
				  	$fd = $this->s__datos['fecha_desde']!=''?"'".$this->s__datos['fecha_desde']."'":'null';
				  	$fh = $this->s__datos['fecha_hasta']!=''?"'".$this->s__datos['fecha_hasta']."'":'null';
				  	$idtc = $this->s__datos['id_tipo_cliente']!=''?$this->s__datos['id_tipo_cliente']:'null';
				  	$beca = $this->s__datos['beca']!=''?$this->s__datos['beca']:'null';
				  	$rac = $this->s__datos['raciones']!=''?$this->s__datos['raciones']:'null';
				  	$sql = "select * from fs_cliente(null, ".$cod."::varchar, null, ".$this->s__datos['id_evento'].", ".$idtc.", ".$beca.", '".date("d/m/Y")."', ".$fd.", ".$fh.", null, ".$rac.", false)";
				  	toba::db()->consultar($sql);
				  	$c++;
				}
				return array_merge($act, $datos); 
			}catch(Exception $e) {
				toba::notificacion()->error($e->getMessage());
			}
		}
	}
	
	function ws($action, $payload, $request=true, $msgop=array()) {
		$pubk = ws_get_cert_from_file(toba::proyecto()->get_path_temp().'/../keys/public.key');
		$prik = ws_get_key_from_file(toba::proyecto()->get_path_temp(). '/../keys/private.key');
		$rcpubk = ws_get_cert_from_file('http://credencial.unc.edu.ar/key/public.key');
		$policy = new WSPolicy(array("security" => array(
			"useUsernameToken" => TRUE, 
			"encrypt"=>TRUE/*,
			"includeTimeStamp" => TRUE*/)));
		$sec_token = new WSSecurityToken(array(
			 "user" => "toba",
             		 "password" => "toba",
			 "passwordType"=>'Digest',
             		 "certificate"=>$pubk,
			 "privateKey"=>$prik,
			 "receiverCertificate"=>$rcpubk/*,
             		 "ttl" => 300,
			 "clockSkewBuffer" => 324*/));
		$opciones = array("to" =>"http://credencial.unc.edu.ar/servicios.php/141000018",
					"useMTOM" => true,
 					"action" =>$action,
					"policy" => $policy,
             		"securityToken" => $sec_token);

		$servicio = toba::servicio_web('ws_codigo', $opciones);

		/*		$payload = <<<XML
		 <chequearUsuarios>
		 <login>
		 <us>toba</us>
		 <pw>toba</pw>
		 </login>
		 <usuarios>
		 <fila_0>
			<codigo>c8a582778141fda9fa02216de2006c8</codigo>
			</fila_0>
			<fila_1>
			<codigo>4016d4b380c1674bad45c150d1576f9</codigo>
			</fila_1>
			<fila_2>
			<codigo>aaaa</codigo>
			</fila_2>
			</usuarios>
			</chequearUsuarios>
			XML;*/
		if($request) {
			return $servicio->request(new toba_servicio_web_mensaje($payload, $msgop));
		} else {
			$servicio->send(new toba_servicio_web_mensaje($payload, $msgop));
		}
	}
}

?>
