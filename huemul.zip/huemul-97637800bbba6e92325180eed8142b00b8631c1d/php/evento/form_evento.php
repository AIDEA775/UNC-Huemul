<?php
class form_evento extends toba_ei_formulario
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Validacion general ----------------------------------
		if(!{$this->objeto_js}.ef('id_evento').tiene_estado()) {
		  {$this->objeto_js}.ef('id_tipo_cliente').ocultar();
		  {$this->objeto_js}.ef('beca').ocultar();
		  {$this->objeto_js}.ef('raciones').ocultar();
		}
		
		";
	}

}
?>