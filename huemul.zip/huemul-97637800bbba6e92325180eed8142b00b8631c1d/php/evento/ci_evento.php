<?php
include_once('lib/ci_comun.php');
class ci_evento extends ci_comun
{
	protected $s__filtro_cliente;
	protected $s__edicion;
	protected $s__clientes;
	protected $s__eliminar_clientes;

	function conf() {
	  $this->s__edicion =  $this->get_id_pantalla()=='edicion';
	}

	function conf__edicion() {
	  if(!$this->cn()->get()) {
	    $this->pantalla()->eliminar_dep('filtro_cliente');
	    $this->pantalla()->eliminar_dep('cuadro_cliente');
	    $this->pantalla()->eliminar_dep('formulario_servicios');
	  } else {
		$datos = utf8_mdecode($this->cn()->get_lista_cliente(utf8_mencode($this->s__filtro_cliente)));
		if($datos || $this->s__clientes) {
		  $dt = $this->cn()->get();
		  if($dt['cantidad'] <= count($datos)) {
		    $this->evento('generar')->ocultar();
		  }
		  $this->dep('filtro_cliente')->colapsar();
		} else {
		  $this->pantalla()->eliminar_dep('filtro_cliente');
		  $this->pantalla()->eliminar_dep('cuadro_cliente');
		}
	  }
	}

	function get_tipo_cliente() {
		return utf8_mdecode($this->cn()->get_tipo_cliente());
	}

		/**
	 * Permite cambiar la configuraci�n del formulario previo a la generaci�n de la salida
	 * El formato del carga debe ser array(<campo> => <valor>, ...)
	 */
	function conf__formulario_cliente(toba_ei_formulario $form)
	{
		$form->set_datos(utf8_mdecode($this->cn()->get_cliente()));
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 * @param array $datos Estado del componente al momento de ejecutar el evento. El formato es el mismo que en la carga de la configuraci�n
	 */
	function evt__formulario_cliente__modificacion($datos)
	{
		$this->cn()->set_cliente(utf8_mencode($datos));
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 * @param array $datos Estado del componente al momento de ejecutar el evento. El formato es el mismo que en la carga de la configuraci�n
	 */
	function evt__formulario_servicios__modificacion($datos)
	{
		$this->s__clientes = utf8_mdecode($this->cn()->get_usuarios(utf8_mencode($datos), utf8_mencode($this->s__filtro_cliente)));
	}
	
	//-----------------------------------------------------------------------------------
	//---- cuadro -----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	/**
	 * Permite cambiar la configuraci�n del cuadro previo a la generaci�n de la salida
	 * El formato de carga es de tipo recordset: array( array('columna' => valor, ...), ...)
	 */
	function conf__cuadro_cliente(toba_ei_cuadro $cuadro)
	{
	      $datos = utf8_mdecode($this->cn()->get_lista_cliente($this->s__filtro_cliente));
	      $cuadro->set_datos($datos);
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 * @param array $seleccion Id. de la fila seleccionada
	 */
	function evt__cuadro_cliente__seleccion($seleccion)
	{
		$this->cn()->set_index_cliente(utf8_mencode($seleccion));
		$this->set_pantalla('cliente');
	}

	/**
	 * Permite cambiar la configuraci�n del formulario previo a la generaci�n de la salida
	 * El formato del carga debe ser array(<campo> => <valor>, ...)
	 */
	function conf__filtro_cliente(toba_ei_filtro $filtro)
	{
		if(isset($this->s__filtro_cliente)) $filtro->set_datos($this->s__filtro_cliente);
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 * @param array $datos Estado del componente al momento de ejecutar el evento. El formato es el mismo que en la carga de la configuraci�n
	 */
	function evt__filtro_cliente__filtrar($datos)
	{
		$this->s__filtro_cliente = $datos;
	}

	/**
	 * Atrapa la interacci�n del usuario con el bot�n asociado
	 */
	function evt__filtro_cliente__cancelar()
	{
		$this->s__filtro_cliente = array();
	}
	//-----------------------------------------------------------------------------------
	//---- Eventos ----------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__cancelar()
	{
	  if($this->s__edicion) {
	    parent::evt__cancelar();
	  } else {
	    $this->set_pantalla('edicion');
	  }
	}

	function evt__eliminar()
	{
	  if($this->s__edicion) {
	    parent::evt__eliminar();
	  } else {
	    $this->cn()->eliminar_cliente();
	    $this->set_pantalla('edicion');
	  }
	}

	function evt__guardar()
	{
	  if($this->s__edicion) {
	    parent::evt__guardar();
	  } else {
	    $this->cn()->guardar_cliente();
	  }
	}

	function evt__generar()
	{
	  $this->cn()->generar_clientes();
	}

	function get_servicios() {
		return $this->cn()->get_servicios();
	}
	//-----------------------------------------------------------------------------------
	//---- cuadro_cliente ---------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function evt__cuadro_cliente__eliminar($datos)
	{
		$this->s__eliminar_clientes = $datos;
	}

	function evt__cuadro_cliente__quitar($datos)
	{
		if($this->s__eliminar_clientes) {
			$this->cn()->eliminar_cliente($this->s__eliminar_clientes);
		}
	}

}
?>
