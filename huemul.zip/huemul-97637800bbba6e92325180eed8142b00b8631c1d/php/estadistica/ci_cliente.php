<?php
class ci_cliente extends toba_ci
{
    function generar_html() {
      echo '<script type="text/javascript" src="http://www.google.com/jsapi"></script>';
      parent::generar_html();
    }

    function get_tipo_cliente() {
	    return $this->cn()->get_tipo_cliente();
    }

    function get_extra() {
	    return $this->cn()->get_extra();
    }

    /*function conf__cuadro(toba_ei_cuadro $cuadro) {
    	$cuadro->set_datos($this->cn()->get_resumen());
    }*/
    
    function extender_objeto_js() {
      echo "
      google.load('visualization', '1', {packages:['corechart', 'table']});
      google.setOnLoadCallback(handleChart);
      var query, chart, table, agrupado, filtro, estado, estado_sum, estado_op;
      var params = {};
      function handleChart() {
      	if(query) {
	    	query.abort();
	    }
		agrupado = '&agrupado='+{$this->objeto_js}.dep('formulario').ef('tipo_agrupado').get_estado();
		//var sum = '&sum='+{$this->objeto_js}.dep('formulario').ef('tipo_suma').get_estado();
		//var op = '&op='+{$this->objeto_js}.dep('formulario').ef('operador').get_estado();	
		//filtro = '&filtro=tc:'+{$this->objeto_js}.dep('formulario').ef('tipo_cliente').get_estado(); //+';fd:'+{$this->objeto_js}.dep('formulario').ef('fecha_desde').get_estado()+';fh:'+{$this->objeto_js}.dep('formulario').ef('fecha_hasta').get_estado()+';te:'+{$this->objeto_js}.dep('formulario').ef('tipo_extra').get_estado()+';g:'+{$this->objeto_js}.dep('formulario').ef('granularidad').get_estado();
		query = new google.visualization.Query('/comedor/1.0/gv-ds.php?accion=5&mod=e'+agrupado); //agrupado+sum+filtro+op);
		//query = new google.visualization.Query('http://atencionremota.com.ar/comedor/1.0/gv-ds.php?accion=3&mod=e'+agrupado+sum+filtro+op);
		if(!table) {
		  table = new google.visualization.Table(document.getElementById('table_div'));
		}
		//if({$this->objeto_js}.dep('formulario').ef('tipo_agrupado').get_estado() == '2') {
		//    chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
		//} else {
		    chart = new google.visualization.PieChart(document.getElementById('chart_div'));
		//}
		estado = {$this->objeto_js}.dep('formulario').ef('tipo_agrupado').get_estado();
		//estado_sum = {$this->objeto_js}.dep('formulario').ef('tipo_suma').get_estado();
		//estado_op = {$this->objeto_js}.dep('formulario').ef('operador').get_estado();
		//query.setRefreshInterval(5);
		query.send(drawChart);
	
      }
      function drawChart(response) {
		params.cht = 'p3';
		params.chs='700x300';
		params.chds = 0;
		params.chdl = '';
		params.chd = '';
		params.chl = '';
		params.chxl = '';
		params.chxr = '';
		params.d = '';
		
		if (response.isError()) {
		  alert('Error in query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
		  return;
		}
		var data = response.getDataTable();
		var a='';
				
		switch(estado) {
			case 'C':
				a += 'Cantidad de Clientes';
				break;
			case 'R':
				a += 'Sumatoria de Raciones';
				break;
			case 'S':
				a += 'Sumatoria de Saldos';
				break;
		}
		a += ' por Tipo de Cliente';
		var total =0;
		for(var i = 0; i < data.getNumberOfRows(); i++) {
			total += data.getValue(i, 1);
		}
		for(var i = 0; i < data.getNumberOfRows(); i++) {
			params.chds = data.getValue(i, 1)>params.chds?data.getValue(i, 1):params.chds;
			if(params.cht == 'p3') {
				params.chdl += '|'+data.getValue(i, 0);
				params.chl += '|'+(Math.round(data.getValue(i, 1)*1000/total)/10)+'%';
			}  else {
				params.d += '|'+data.getValue(i, 0);
				if (i==0 || i == data.getNumberOfRows()-1) {
					params.chxl += '|'+data.getValue(i, 0);
				}
			}
			params.chd += ','+data.getValue(i, 1);
		}
		if(params.chxt) {
			params.chxr += '0,0,'+(Math.ceil(params.chds+(params.chds/10)));
		} 
		params.chds = '0,'+(Math.ceil(params.chds+(params.chds/10)));
		if(params.chd) {
			params.cols = data.getColumnLabel(0)+'|'+data.getColumnLabel(1);
			params.chd = 't:'+params.chd.substring(1);
			params.chl = params.chl.substring(1);
			params.chdl = params.chdl.substring(1);
			params.d = params.d.substring(1);
			if(params.chxl!='')
				params.chxl = '1:'+params.chxl;
		}
		params.chtt = a;
		table.draw(data);
		/*if(estado_op == 1) {
			var data_new = new google.visualization.DataTable();
			data_new.addColumn('string', 'Datos');
			data_new.addColumn('number', 'Cantidad');
			for(var i = 0; i<data.getNumberOfRows(); i++) {
				data_new.addRow([data.getValue(i, 0)+' - '+data.getValue(i, 1), data.getValue(i, 2)]);
			}
			data = data_new;
		}*/
        chart.draw(data, {width: 450, height: 300, title: a, is3D: true});
        
        document.getElementById('sum_span').innerHTML = total;
      }
      
	{$this->objeto_js}.evt__pdf=function() {
		//if(agrupado || filtro) {
			     window.open(vinculador.crear_autovinculo('vista_xslfo', params, null), '_new');
		//}
		return false;
	};      
      ";
    }
    
    function vista_xml($inicial=false, $xmlns=null) {
    	if ($xmlns) {
			$this->xml_set_ns($xmlns);
		}
		$xml = $this->xml_get_tag_inicio();
		/*foreach ($this->get_dependencias() as $dep) 
		{
			if(method_exists($dep, 'vista_xml')) {
				$xml .= $dep->vista_xml(false,$xmlns);
			}
		}*/
		$p = toba::memoria()->get_parametros();
		$tmp;
		foreach($p as $k => $v) {
			if($v!='' || $v != null)
				$tmp .= '&'.urlencode($k).'='.urlencode($v);
		}
		$a =  tempnam(toba::proyecto()->get_path_temp(), 'chart_');
		file_put_contents($a,file_get_contents('http://chart.apis.google.com/chart?'.$tmp));
/*		echo 'http://chart.apis.google.com/chart?'.$tmp;
		echo "<pre>",print_r($p),"</pre>";
		echo "<img src='http://chart.apis.google.com/chart?",$tmp,"'>";
		exit;*/
		$xml .= $this->xml_imagen($a);
		$xml .= $this->xml_texto(' ');
		$c1 = explode('|',$p['chdl']?$p['chdl']:$p['d']);
		$c2 = explode(',',substr($p['chd'], 2));
		$data = array();
		$total = 0;
		for($i = 0; $i<count($c1); $i++) {
			$data[] = array($c1[$i], $c2[$i]);
			$total += (int) $c2[$i];
		}
		$data[] = array('Total', $total);
		$titulo = explode('|', $p['cols']);
		$this->xml_set_tabla_cols(array(array('titulo'=>$titulo[0]), array('titulo'=>$titulo[1])));
		$xml .= $this->xml_tabla($data);
		$xml .= $this->xml_get_tag_fin();
		return $xml;
    }    
}

?>
