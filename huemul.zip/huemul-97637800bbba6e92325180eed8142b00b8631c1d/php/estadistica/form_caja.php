<?php
class form_caja extends toba_ei_formulario
{

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		{$this->objeto_js}.ef('granularidad').mostrar(false);

		{$this->objeto_js}.ef('tipo_agrupado').cuando_cambia_valor(\"chVal()\");
    
		function chVal() {
		  if({$this->objeto_js}.ef('tipo_agrupado').get_estado() == '2') {
		    {$this->objeto_js}.ef('granularidad').mostrar(true);
		    //chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
		  } else {
		    {$this->objeto_js}.ef('granularidad').mostrar(false);
		    //chart = new google.visualization.PieChart(document.getElementById('chart_div'));
		  }
		}

		{$this->objeto_js}.evt__modificacion = function()
		{
		  handleChart();
		  return false;
		}
		";
	}
}
?>