<?php
class pant_caja extends toba_ei_pantalla
{
	function generar_layout()
	{
		$this->dep('formulario')->generar_html();
		echo "
		<hr/>
		<div>
			<div style='width: 450px; margin: auto' id='chart_div'></div>
			<hr/>
			<div style='width: 450px; margin: auto' id='table_div'></div>
			<hr/>
			<div style='width: 450px; margin: auto' id='sum_div'><span style='font-weight: bold'>Total:</span> <span style='float: right' id='sum_span'></span></div>
		</div>";
	}
}

?>