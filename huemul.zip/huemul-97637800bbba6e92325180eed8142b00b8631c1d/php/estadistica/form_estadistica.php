<?php
class form_estadistica extends toba_ei_formulario
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		{$this->objeto_js}.ef('granularidad').mostrar(false);

		{$this->objeto_js}.ef('agrupado_radio').cuando_cambia_valor(\"chVal()\");
    
		function chVal() {
		  if({$this->objeto_js}.ef('agrupado_radio').get_estado() == 'f') {
		    {$this->objeto_js}.ef('granularidad').mostrar(true);
		    //chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
		  } else {
		    {$this->objeto_js}.ef('granularidad').mostrar(false);
		    //chart = new google.visualization.PieChart(document.getElementById('chart_div'));
		  }
		}

		{$this->objeto_js}.evt__modificacion = function()
		{
		  handleChart();
		  return false;
		}
		";
	}

}
?>
