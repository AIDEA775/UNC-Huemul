<?php
class cn_estadistica extends toba_cn
{
      function get_tipo_cliente() {
	$sql = "select * from ff_tipo_cliente()";
	return toba::db()->consultar($sql);
      }

	function get_sedes() {
		$sql = "select * from sedes";
		return toba::db()->consultar($sql);
	}
}

?>
