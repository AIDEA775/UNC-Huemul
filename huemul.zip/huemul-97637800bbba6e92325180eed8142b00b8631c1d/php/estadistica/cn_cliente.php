<?php
class cn_cliente extends toba_cn
{
      function get_tipo_cliente() {
		$sql = "select * from ff_tipo_cliente()";
		return toba::db()->consultar($sql);
      }

      function get_extra() {
		$sql = "select * from ff_extra()";
		return toba::db()->consultar($sql);
      }
      
      function get_resumen() {
      	$sql = "select 'Saldo' as elemento, 
			'$'||sum(saldo)::varchar as cantidad
		from 	fq_cliente()
		where 	obsoleto = false
		union
		select 'Raciones' as elemento, 
			sum(raciones)::varchar as cantidad
		from 	fq_cliente()
		where 	obsoleto = false
		order by 1";
      	return toba::db()->consultar($sql);
      }
}

?>