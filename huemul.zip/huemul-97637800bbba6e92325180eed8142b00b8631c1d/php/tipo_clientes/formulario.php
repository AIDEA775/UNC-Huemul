<?php
class formulario extends toba_ei_formulario
{
	//-----------------------------------------------------------------------------------
	//---- JAVASCRIPT -------------------------------------------------------------------
	//-----------------------------------------------------------------------------------

	function extender_objeto_js()
	{
		echo "
		//---- Procesamiento de EFs --------------------------------
		

		var g_tipo_beca = null;
		var g_tipo_monto = null;

		/**
		 * M�todo que se invoca al cambiar el valor del ef en el cliente
		 * Se dispara inicialmente al graficar la pantalla, enviando en true el primer par�metro
		 */
		{$this->objeto_js}.evt__tipo_beca__procesar = function(es_inicial)
		{
		    var tipo_beca = this.ef('tipo_beca').get_estado();
		    if(g_tipo_beca != tipo_beca) {
		      g_tipo_beca = tipo_beca;
		      this.ef('tipo_monto').mostrar(g_tipo_beca == 'D');
		      var prb = document.getElementById('pre_beca');
		      var pob = document.getElementById('post_beca');
		      if(g_tipo_beca == 'C') {
			  prb.style.display='none';
			  pob.style.display='';
			  pob.innerHTML = 'Raciones';
		      } else {
			  g_tipo_monto = this.ef('tipo_monto').get_estado();
			  if(g_tipo_monto == '$') {
			    pob.style.display='none';
			    prb.style.display='';
			    prb.innerHTML = '$';
			  } else {
			    prb.style.display='none';
			    pob.style.display='';
			    pob.innerHTML = '%';
			  }
		      }
		    }
		}
		
		
		{$this->objeto_js}.evt__tipo_monto__procesar = function(es_inicial)
		{
		    var tipo_monto = this.ef('tipo_monto').get_estado();
		    if(!this.ef('tipo_monto').es_oculto() && tipo_monto != g_tipo_monto) {
			  g_tipo_monto = tipo_monto;
			  var prb = document.getElementById('pre_beca');
			  var pob = document.getElementById('post_beca');
			  if(g_tipo_monto == '$') {
			    pob.style.display='none';
			    prb.style.display='';
			    prb.innerHTML = '$';
			  } else {
			    prb.style.display='none';
			    pob.style.display='';
			    pob.innerHTML = '%';
			  }
		    }
		}


		var g_tipo_duracion = null;
		/**
		 * M�todo que se invoca al cambiar el valor del ef en el cliente
		 * Se dispara inicialmente al graficar la pantalla, enviando en true el primer par�metro
		 */
		{$this->objeto_js}.evt__tipo_duracion__procesar = function(es_inicial)
		{
		    var tipo_duracion = this.ef('tipo_duracion').get_estado();
		    if(g_tipo_duracion != tipo_duracion) {
		      g_tipo_duracion = tipo_duracion;
		      this.ef('tipo_renovacion').mostrar(g_tipo_duracion == 'R');
		      this.ef('renovacion').mostrar(g_tipo_duracion == 'R');
		      var tipo_renovacion = this.ef('tipo_renovacion').get_estado();
		      if(!this.ef('tipo_renovacion').es_oculto() && g_tipo_renovacion != tipo_renovacion) {
			  g_tipo_renovacion = tipo_renovacion;
			  var int = this.ef('intervalo').input();
			  if(g_tipo_renovacion == 'C') {
			    int.style.display = '';
			  } else {
			    int.style.display = 'none';
			  }
		      }
		    }
		}
		

		var g_tipo_renovacion = null;
		/**
		 * M�todo que se invoca al cambiar el valor del ef en el cliente
		 * Se dispara inicialmente al graficar la pantalla, enviando en true el primer par�metro
		 */
		{$this->objeto_js}.evt__tipo_renovacion__procesar = function(es_inicial)
		{
		   var tipo_renovacion = this.ef('tipo_renovacion').get_estado();
		   if(!this.ef('tipo_renovacion').es_oculto() && g_tipo_renovacion != tipo_renovacion) {
		      g_tipo_renovacion = tipo_renovacion;
		      var int = this.ef('intervalo').input();
		      if(g_tipo_renovacion == 'C') {
			int.style.display = '';
		      } else {
			int.style.display = 'none';
		      }
		   }
		}
		";
	}

	function generar_layout()
	{
	    $this->generar_html_ef('id_tipo_cliente');
	    $this->generar_html_ef('descripcion');
	    $this->generar_html_ef('tipo_beca');
	    $this->generar_html_ef('tipo_monto');
	    echo $this->get_html_ef('beca', null, true, '<span id="pre_beca"></span>', '<span id="post_beca"></span>');
	    $this->generar_html_ef('tipo_duracion');
	    $this->generar_html_ef('tipo_renovacion');
	    echo $this->get_html_ef('renovacion', null, true, false, $this->get_input_ef('intervalo'));
	    $this->generar_html_ef('max_personas_agregar');
	    $this->generar_html_ef('pase');
	}

	protected function get_html_ef($ef, $ancho_etiqueta=null, $con_etiqueta=true, $pre=false, $post=false)
        {
                $salida = '';
                if (! in_array($ef, $this->_lista_ef_post)) {
                        //Si el ef no se encuentra en la lista posibles, es probable que se alla quitado con una restriccion o una desactivacion manual
                        return;
                }
                $clase = 'ei-form-fila';
                $estilo_nodo = "";
                $id_ef = $this->_elemento_formulario[$ef]->get_id_form();
                if (! $this->_elemento_formulario[$ef]->esta_expandido()) {
                        $clase .= ' ei-form-fila-oculta';
                        $estilo_nodo = "display:none";
                }
                if (isset($this->_info_formulario['resaltar_efs_con_estado'])
                                && $this->_info_formulario['resaltar_efs_con_estado'] && $this->_elemento_formulario[$ef]->seleccionado()) {
                        $clase .= ' ei-form-fila-filtrada';
                }
                $es_fieldset = ($this->_elemento_formulario[$ef] instanceof toba_ef_fieldset);
                if (! $es_fieldset) {                                                   //Si es fieldset no puedo sacar el <div> porque el navegador cierra visualmente inmediatamente el ef.
                        $salida .= "<div class='$clase' style='$estilo_nodo' id='nodo_$id_ef'>\n";
                }
                if ($this->_elemento_formulario[$ef]->tiene_etiqueta() && $con_etiqueta) {
                        $salida .= $this->get_etiqueta_ef($ef, $ancho_etiqueta);
                        //--- El margin-left de 0 y el heigth de 1% es para evitar el 'bug de los 3px'  del IE
                        $ancho = isset($ancho_etiqueta) ? $ancho_etiqueta : $this->_ancho_etiqueta;
                        $salida .= "<div id='cont_$id_ef' style='margin-left:$ancho;_margin-left:0;_height:1%;'>\n";
			$salida .= ($pre)?$pre:'';
                        $salida .= $this->get_input_ef($ef);
			$salida .= ($post)?$post:'';
                        $salida .= "</div>";
                        if (isset($this->_info_formulario['expandir_descripcion']) && $this->_info_formulario['expandir_descripcion']) {
                                $salida .= '<span class="ei-form-fila-desc">'.$this->_elemento_formulario[$ef]->get_descripcion().'</span>';
                        }

                } else {
                        $salida .= $this->get_input_ef($ef);
                }
                if (! $es_fieldset) {
                        $salida .= "</div>\n";
                }
                return $salida;
        }

}

?>
