--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: comedor; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE comedor WITH TEMPLATE = template0 ENCODING = 'UTF8';


\connect comedor

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: anthill; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA anthill;


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = anthill, pg_catalog;

--
-- Name: t_ff; Type: TYPE; Schema: anthill; Owner: -
--

CREATE TYPE t_ff AS (
	data integer,
	label character varying
);


SET search_path = public, pg_catalog;

--
-- Name: asistencia; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asistencia AS (
	cuip bigint,
	otro bigint,
	nombre character varying(100),
	apellido character varying(100),
	tipo_cliente character varying(200),
	f1 character(1),
	f2 character(1),
	f3 character(1),
	f4 character(1),
	f5 character(1),
	f6 character(1),
	f7 character(1),
	f8 character(1),
	f9 character(1),
	f10 character(1),
	f11 character(1),
	f12 character(1),
	f13 character(1),
	f14 character(1),
	f15 character(1),
	f16 character(1),
	f17 character(1),
	f18 character(1),
	f19 character(1),
	f20 character(1),
	f21 character(1),
	f22 character(1),
	f23 character(1),
	f24 character(1),
	f25 character(1),
	f26 character(1),
	f27 character(1),
	f28 character(1),
	f29 character(1),
	f30 character(1),
	f31 character(1)
);


--
-- Name: busqueda; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE busqueda AS (
	tipo_codigo integer,
	id_cliente integer,
	id_persona integer,
	nombre character varying(100),
	apellido character varying(100),
	cuip bigint,
	saldo real,
	id_extra integer,
	descripcion character varying(200),
	precio_unitario real,
	cantidad integer
);


--
-- Name: paso; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE paso AS (
	codigo character varying(32),
	data character varying(100)
);


--
-- Name: t_ff; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE t_ff AS (
	data integer,
	label character varying
);


SET search_path = anthill, pg_catalog;

--
-- Name: ce(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce() RETURNS character varying
    AS $$
	select ce_dv(); --Borrar las vistas
	select ce_df(); --Borrar las funciones
--	select ce_view(); 
	select ce_ff(); --Crea las funciones de 1 columna para las foraneas
	select ce_view_all(); --Crea las vistas
	select ce_fs(); --Crea las funciones de ABM
	--select ce_fl(); --Crea las funciones que filtran por las claves foraneas
	select ce_fl_by_fk(); --Crea las funciones que filtran por la clave foranea fk
	select ce_fd(); --Crea las funciones que realizan las bajas
	select ce_fq(); --Crea las funciones que realizan los listados standares
--	select ce_fx();
	select ce_adhoc()::varchar; --Crea ejecuta las funciones adhoc de la aplicacion
	select ce_tg(); --Crea los triggers de auditoria
$$
    LANGUAGE sql;


--
-- Name: ce_adhoc(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_adhoc() RETURNS integer
    AS $$
declare 
	rec record;
	ejecutar varchar;
	i integer;
begin
	i=0;
	for rec in 
		select 	*
		from 	v_ce_adhoc
		order by orden
	loop
		ejecutar=rec.ejecutar;
		execute ejecutar;
		i=i+1;
	end loop;
	return i;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_df(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_df() RETURNS character varying
    AS $$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	arg varchar;
	i int;
	retorno varchar;
begin
	ret = '';
	retorno ='';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid
		where 	((	proname ilike ('ff%') or 
				proname ilike ('fd%') or 
				proname ilike ('fq%') or 
				proname ilike ('fs%') or 
				proname ilike ('fl%') ) and 
			substr(proname,3,1)='_') or 
			(( 	proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%'))and 
			substr(proname,4,1)='_') or 
			((	proname ilike ('ffx%') or 
				proname ilike ('fdx%') or 
				proname ilike ('fqx%') or 
				proname ilike ('fsx%') or 
				proname ilike ('flx%') ) and 
			substr(proname,4,1)='_') or
			(( 	proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%'))and 
			substr(proname,5,1)='_') 
	loop
		arg='';		
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
		end if;
		ret = 'drop function if exists ' ||rec.nspname||'.'||rec.proname ||' ('||arg||') cascade;';
		execute ret;
	end loop;
	return retorno;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_dv(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_dv() RETURNS character varying
    AS $$
declare 
	ret varchar;
	rec record;
begin
	ret = '';
	for rec in 
		select 	c.oid, relname, nspname
		from 	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'v'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
		order by oid
	loop
		ret = 'drop view if exists ' ||rec.nspname||'.'||rec.relname ||' cascade;';
		execute ret;
	end loop;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_fd(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fd(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	v_view varchar;
	schma varchar;
begin
	select n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where 	c.oid = $1;

	ret = 	'create or replace function '||schma||'.fd_' ||v_view||' (id_'||v_view||'_arg int) returns int as'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'declare'||E'\n'||
		'	rowc integer;'||E'\n'||
		'	canti integer;'||E'\n'||
		'begin'||E'\n'||
		--'   	delete from '||schma||'.'||v_view||' where id_'||v_view||' = $1;'||E'\n'||
		'	update '||schma||'.'||v_view||' set obsoleto = true where id_'||v_view||' = $1;'||E'\n'||
		'   	get diagnostics rowc = row_count;'||E'\n'||
		'   	if rowc <= 0 then'||E'\n'||
		'      		RAISE EXCEPTION ''En la entidad '||schma||'.'||v_view||' no se pudo borrar.'';'||E'\n'||
		'   	end if;'||E'\n'||
		' return $1;'||E'\n'||
		'end;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'language plpgsql;';	
	execute ret;
	return ret ;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_fd(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fd() RETURNS character varying
    AS $$
	select 	ce_fd(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$$
    LANGUAGE sql;


--
-- Name: ce_ff(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_ff(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	ret = '';
	select n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
		and c.oid=$1;
	for rec in 
		select	a.attname, t.typname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum = 2
		order by a.attnum
	loop
		ret = 	'create or replace function '||schma||'.ff_' ||v_view||' (id_'||v_view||'_arg int) returns '||rec.typname||' as'||E'\n'||
			E'$' || 'body$ '||E'\n'||
			'   select '||rec.attname||' from '||schma||'.'||v_view||E'\n' ||
			' where id_'||v_view||' = $1 and COALESCE(obsoleto, false) = false;'||E'\n' ||
			E'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;

		ret = 	'create or replace function '||schma||'.ff_' ||v_view||' () returns setof t_ff as'||E'\n'||
			E'$' || 'body$ '||E'\n'||
--id as data, name as label
			'   select id_'||v_view||'::int as data, '||rec.attname||'::varchar as label'||E'\n'||
			' from '||schma||'.'||v_view||E'\n'||
			' where COALESCE(obsoleto, false) = false;'||E'\n' ||
			E'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;
	end loop;
	return ret;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_ff(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_ff() RETURNS character varying
    AS $$
declare
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select	ce_ff(oid) as a
		from 	pg_class
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
		order by oid
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_fl(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fl(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	arg varchar; 
	where_arg varchar; 
	i int; 
begin
	ret = '';
	select distinct n.nspname, l.relname into schma, v_view --, l.oid --
	from 	pg_class l
	inner join
		pg_namespace n
	on	n.oid = l.relnamespace
	inner join
		pg_constraint c
	on	c.conrelid = l.oid
		and c.contype = 'f'
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
		and l.oid=$1;
	i=0;
	arg='';
	where_arg ='';
	for rec in 
		select	a.attname, cl.relname, t.typname
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_attribute af
		on	af.attnum = any(c.confkey)
			and af.attrelid = cl.oid
		inner join
			pg_type t
		on	t.oid = af.atttypid
		where	a.attrelid =  $1 
			and a.attnum > 0
		order by a.attnum
	loop
		i=i+1;
		arg = arg||rec.attname|| '_arg ' || rec.typname || ', ';
		where_arg = where_arg || '($' || i || ' is null or coalesce('|| rec.attname || ',0) = coalesce($' || i || ',0)) and ';
	end loop;

	arg = substring(arg from 1 for char_length(arg) -2);
	where_arg = substring(where_arg from 1 for char_length(where_arg) -5);
	
	for rec in 
		select	a.attname, t.typname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum = 2
		order by a.attnum
	loop
		ret = 	'create or replace function '||schma||'.fl_' ||v_view||' ('||arg||') returns setof t_ff as'||E'\n'||
			'$' || 'body$ '||E'\n'||
			'   select id_'||v_view||'::int, '||rec.attname||'::varchar from '||schma||'.v_'||v_view||' where '||where_arg||';'||E'\n'||
			'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;
	end loop;
	return ret;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_fl(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fl() RETURNS character varying
    AS $$
declare 
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select 	distinct ce_fl (l.oid) as a
		from 	pg_class l
		inner join
			pg_constraint c
		on	c.conrelid = l.oid
			and c.contype = 'f'
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_fl_by_fk(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fl_by_fk(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	select distinct n.nspname, c.relname into schma, v_view 
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where	c.oid=$1;

	ret='';
	
	for rec in 
		select	a.attname, cl.relname, t.typname
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_attribute af
		on	af.attnum = any(c.confkey)
			and af.attrelid = cl.oid
		inner join
			pg_type t
		on	t.oid = af.atttypid
		where	a.attrelid = $1 
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret ||
		'create or replace function '||schma||'.fl_'||v_view||'_by_'||rec.attname||'(var_'||rec.attname||' '|| rec.typname||') returns setof '||schma||'.v_'||v_view||' as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select * from '||schma||'.v_'||v_view||' where '||rec.attname||' = $1;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		' language sql;'||E'\n';
	end loop;
	execute ret;
	return ret;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_fl_by_fk(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fl_by_fk() RETURNS character varying
    AS $$
declare 
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select 	distinct ce_fl_by_fk (l.oid) as a
		from 	pg_class l
		inner join
			pg_constraint c
		on	c.conrelid = l.oid
			and c.contype = 'f'
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_fq(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fq(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	ret_i varchar;
	ret_ql varchar;
	ret_ta varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	arg varchar;
	arg_i varchar;
	arg_rango varchar;
	whe_ins varchar;
	whe_rango varchar;
	i_body varchar;
	ejecutar varchar;
	auxiliar varchar;
	count int;
begin
	ret = '';
	arg = '';
	whe_ins = '';
	whe_rango = '';
	i_body = '';
	arg_i = '';
	arg_rango = '';
	auxiliar ='';
	count = 1;


	select  n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.oid=$1;

	for rec in 
		select	a.attname, t.typname, a.attnum
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum > 0
		order by a.attnum
	loop
		--Para retorno
		ret = ret || rec.attname || ', ';
		
		--Para argumento
		arg = arg || rec.attname || '_arg ' || rec.typname || ', ' ;

		--Para los where
		if rec.typname like 'int%' or rec.typname = 'numeric' or rec.typname = 'date' or rec.typname like 'float%' then --or rec.typname = 'bool' or rec.typname = 'boolean'
			select into whe_ins whe_ins || E'\n'|| '('||rec.attname||' = '||rec.attname || '_arg or '||rec.attname || '_arg is null) and ';
			--para fqr (con rangos)
			select into whe_rango whe_rango || E'\n'|| '(('||rec.attname||' >= '||rec.attname || '_arg_desde or '||rec.attname || '_arg_desde is null) and '||
					     ' ('||rec.attname||' <= '||rec.attname || '_arg_hasta or '||rec.attname || '_arg_hasta is null))and ';
			arg_rango = arg_rango || rec.attname || '_arg_desde ' || rec.typname || ', ' ;
			arg_rango = arg_rango || rec.attname || '_arg_hasta ' || rec.typname || ', ' ;
		elseif rec.typname = 'bool' or rec.typname = 'boolean' then
			select into whe_ins whe_ins || E'\n'|| '(' ||rec.attname || '_arg is null or '||rec.attname||'::boolean = '||rec.attname || '_arg::boolean) and ';
			select into whe_rango whe_rango || E'\n'|| '(' ||rec.attname || '_arg is null or '||rec.attname||'::boolean = '||rec.attname || '_arg::boolean) and ';
			arg_rango = arg_rango || rec.attname || '_arg ' || rec.typname || ', ' ;
		else
			select into whe_ins whe_ins || E'\n'|| 'translate(coalesce('||rec.attname||'::varchar, ''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'') ilike ''%''||translate(coalesce(('||rec.attname || '_arg)::varchar,''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'')||''%'' and ';
			select into whe_rango whe_rango || E'\n'|| 'translate(coalesce('||rec.attname||'::varchar, ''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'') ilike ''%''||translate(coalesce(('||rec.attname || '_arg)::varchar,''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'')||''%'' and ';
			arg_rango = arg_rango || rec.attname || '_arg ' || rec.typname || ', ' ;
		end if;
	end loop;
	for rec in
		select	cl.oid, a.attname, cl.relname, a.attnum
		from	pg_attribute a
		inner join
			pg_constraint c
		on	a.attrelid = c.conrelid
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
			and a.attnum > 0
		inner join
			pg_class cl
		on	c.conrelid = cl.oid
		where	c.confrelid = $1
			and a.attnum > 0
		order by cl.relname
	loop
		arg_i = arg_i ||rec.attname||'_'||rec.oid::varchar||'_arg integer, ';
		i_body = i_body ||'	if '||rec.attname||'_'||rec.oid::varchar||'_arg is not null then '||E'\n'||
			'		tmp = tmp || '' inner join fq_'||rec.relname||'(''||'||rec.attname||'_'||rec.oid::varchar||'_arg||'') t'||count::varchar||
				' on t.id_'||v_view||' = t'||count||'.'||rec.attname||'''; '||E'\n'||
			'end if;'||E'\n';
			count = count+1;
	end loop;
	--ret = substring(ret from 1 for char_length(ret) -2);
	ret_ql = ret;
	for rec in 
		select	a.attname, a.attnum, n.nspname, cl.relname, t.typname, c.* 
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid	
		inner join 
			pg_namespace n
		on	n.oid = cl.relnamespace
		inner join
			pg_type t
		on	t.oid = a.atttypid
		where	a.attrelid =  $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret_ql = ret_ql || rec.nspname||'.ff_' ||rec.relname||' ('|| rec.attname||') as ff_' || rec.attname || ', ' ;
	end loop;
	ret_ql = substring(ret_ql from 1 for char_length(ret_ql) -2);
	ret = substring(ret from 1 for char_length(ret) -2);
	ret_i = substring(ret_i from 1 for char_length(ret_i) -2);
	arg = substring(arg from 1 for char_length(arg) -2);
	whe_ins = substring(whe_ins from 1 for char_length(whe_ins) -5);
	arg_rango = substring(arg_rango from 1 for char_length(arg_rango) -2);
	whe_rango = substring(whe_rango from 1 for char_length(whe_rango) -5);
	--whe_fil = substring(whe_fil from 1 for char_length(whe_fil) -5);

	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' () returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
		' select *'||E'\n' ||  --||ret
		' from '||schma||'.v_'||v_view||'_all; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
		' select *'||E'\n' ||
		' from '||schma||'.v_'||v_view||'_all '||E'\n' ||
		' limit $1 offset $2; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (id_' ||v_view||'_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where id_'||v_view||' = $1; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (id_' ||v_view||'_arg int, lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where id_'||v_view||' = $1 '||E'\n' ||
		' limit $2 offset $3; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fq_'||v_view||' (' ||arg||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_ins||'; '||E'\n' ||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fqr_'||v_view||' (' ||arg_rango||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_rango||'; '||E'\n' ||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fq_'||v_view||' (' ||arg||', lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_ins||E'\n' ||
		' limit lim_arg offset off_arg;'||E'\n'||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 'create or replace function '||schma||'.fql_'||v_view||' (id_' ||v_view||'_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select '||ret_ql||
		--' from v_'||v_view||
		' from '||schma||'.fq_'||v_view||'()'||
		' where id_'||v_view||' = $1; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar;
	
	if char_length(arg_i) > 2 then
		arg_i = substring(arg_i from 1 for char_length(arg_i) -2);
		ejecutar = 	'create or replace function '||schma||'.fqi_'||v_view||' (' ||arg_i||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
			' declare '||E'\n'||
			' 	tmp varchar; '||E'\n'||
			' 	ret record; '||E'\n'||
			' begin '||E'\n'||
			' 	tmp = ''select t.* from '||schma||'.fq_'||v_view||'() t '';'||E'\n'||
			i_body||
			' 	for ret in'||E'\n'||
			'		execute tmp'||E'\n'||
			'	loop'||E'\n'||
			'		return next ret;'||E'\n'||
			'	end loop;'||E'\n'||
			' end; '||E'\n'||
			 '$' || 'body$ '||E'\n'||
			 ' language ''plpgsql'';';
		execute ejecutar;
	end if;
	return ejecutar ||E'\n';
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_fq(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fq() RETURNS character varying
    AS $$
	select 	ce_fq(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1 
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$$
    LANGUAGE sql;


--
-- Name: ce_fs(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fs(id_table oid) RETURNS character varying
    AS $_$
declare 
	arg varchar;
	sarg varchar;
	arr_arg varchar;
	arg_ins varchar;
	value_ins varchar;
	whe_ins varchar;
	set_update varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	ret varchar;
	ignorar int[];
begin
	arg = '';
	sarg = '';
	arr_arg = '';
	arg_ins = '';
	whe_ins = '';
	value_ins ='';
	set_update ='';
	--RAISE EXCEPTION 'source si %', ignorar;
	for rec in 
		select	a.attname, t.typname, a.attnum, c.relname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		inner join
			pg_class c
		on	c.oid = a.attrelid
		where	a.attrelid = $1 and 
			a.attnum > 0 
		order by a.attnum
	loop
		arg = arg || rec.attname || '_arg ' || rec.typname || ', ' ;
		sarg = sarg || rec.attname || '_arg, ' ;
		arr_arg = arr_arg || rec.attname || '_arg::varchar, ' ;
		if rec.attnum <> 1 then
			arg_ins = arg_ins || rec.attname || ', ' ;
			value_ins = value_ins || '$'||rec.attnum||', '||E'\n\t\t';
			select into whe_ins whe_ins ||
				'coalesce('||rec.attname||','|| case when rec.typname ilike 'int%' or rec.typname ilike 'float%' then '0' when rec.typname = 'attribute_nested' then '''single''' when rec.typname = 'bool' then '''false''' else '''''::'||rec.typname end||') ='||
				'coalesce(case when ignorar @> array['||rec.attnum||'] then '||rec.attname||' else $'||rec.attnum||' end ,'|| case when rec.typname ilike 'int%' or rec.typname ilike 'float%' then '0' when rec.typname = 'attribute_nested' then '''single''' when rec.typname = 'bool' then '''false''' else '''''::'||rec.typname end||') and '||E'\n\t\t\t';
			set_update = set_update||rec.attname||' = $'||rec.attnum||', '||E'\n\t\t\t';
		end if;
	end loop;
	
	if char_length(arg) >= 2 then
		arg = substring(arg from 1 for char_length(arg) -2);
	end if;	
	if char_length(sarg) >= 2 then
		sarg = substring(sarg from 1 for char_length(sarg) -2);
	end if;
	if char_length(arr_arg) >= 2 then
		arr_arg = substring(arr_arg from 1 for char_length(arr_arg) -2);
	end if;
	if char_length(arg_ins) >= 2 then
		arg_ins = substring(arg_ins from 1 for char_length(arg_ins) -2);
	end if;	
	if char_length(value_ins) >= 2 then
		value_ins = substring(value_ins from 1 for char_length(value_ins) -5);
	end if;	
	if char_length(whe_ins) >= 5 then
		whe_ins = substring(whe_ins from 1 for char_length(whe_ins) -9);
	end if;	
	if char_length(set_update) >= 2 then
		set_update =  substring(set_update from 1 for char_length(set_update) -6);
	end if;	
	
	select  n.nspname,c.relname into schma,v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.relnatts > 1
		and c.relname not like '%_mig%'
--		and relname not like 'ce_%'
		and c.oid=$1;
	ret = 	'create or replace function '||schma||'.fs_'||v_view||' (' ||arg||') returns int as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' declare '||E'\n'||
		'   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;'||E'\n'||
		' begin '||E'\n'||
		' 	if $1 is null then '||E'\n'||
		'      		insert into '||schma||'.'||v_view||' (' ||arg_ins ||') '||E'\n'||
		'      		values ('||value_ins||'); '||E'\n'||
		'      		get diagnostics rowc = row_count;'||E'\n'||
		'      		select into retorno max(id_'||v_view||')'||E'\n'||
		'      		from	'||schma||'.v_'||v_view||';'||E'\n'||
		--'      		where	'||whe_ins||';'||E'\n'||
		'  	else '||E'\n'||
		'      		update   '||schma||'.'||v_view||E'\n'||
		'      		set	'||set_update||E'\n'||
		'      		where	id_'||v_view||' = $1;'||E'\n'||
		'      		get diagnostics rowc = row_count;'||E'\n'||
		'      		retorno = $1;'||E'\n'||
		'  	end if; '||E'\n'||
		'  	if rowc <= 0 then '||E'\n'||
		'  		RAISE EXCEPTION ''En la entidad '||schma||'.'||v_view||' no se pudo guardar.'';'||E'\n'||
		'  	end if;'||E'\n'||		
		'  return retorno;'||E'\n'||
		'end;'||E'\n'||		
		 '$' || 'body$ '||E'\n'||
		 'language plpgsql;';
	execute ret;
	return ret ;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_fs(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fs() RETURNS character varying
    AS $$
	select  ce_fs(oid) --*
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char" 
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
	
$$
    LANGUAGE sql;


--
-- Name: ce_fx(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_fx() RETURNS character varying
    AS $_$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	arg varchar;
	condicion varchar;
	i int;
	retorno varchar;
begin
	retorno ='';
	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid 
		where 	((	proname ilike ('fd%') or 
				proname ilike ('fq%') or 
				proname ilike ('fs%') or 
				proname ilike ('fl%')
				) and 
			substr(proname,3,1)='_')
	loop
		arg='';		
		condicion ='';
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''''||'||E'$'||i+1||'||'''' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, ' --acaaca
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<table>''||
			query_to_xml(''select * from '||rec.nspname||'.'||substr(rec.proname,1,2)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</table>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;


	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid  
		where 	((	proname ilike ('ff%')
				) and 
			substr(proname,3,1)='_')
	loop
		arg='';	
		condicion ='';	
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''||'||E'$'||i+1||'||'' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<query>''||
			query_to_xml(''select * from '||rec.nspname||'.'||substr(rec.proname,1,2)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</query>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;


	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid
		where 	((
				proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%')
				) and 
			substr(proname,4,1)='_')
	loop
		arg='';	
		condicion ='';	
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''||'||E'$'||i+1||'||'' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname ||'.' ||rec.proname ||' ('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname ||'.'||substr(rec.proname,1,3)||'x_'||substr(rec.proname,5)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<query>''||
			query_to_xml(''select * from '||rec.nspname ||'.'||substr(rec.proname,1,3)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</query>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;

	return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_get_attribute(name, name); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_get_attribute(tblname name, sch name) RETURNS SETOF xml
    AS $$
declare
	ret xml;
	tmp varchar;
	rec record;
begin
	for rec in 
		select	a.attname, 
			t.typname, 
			a.attnum, 
			a.attlen,
			a.attnotnull, 
			a.atttypmod,
			co.contype,
			c2.relname,
			a.*
		from	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		inner join
			pg_attribute a
		on a.attrelid = c.oid
		inner join
			pg_type t
		on	t.oid = atttypid
		left join
			pg_constraint co
		on	co.conrelid = c.oid
			and a.attnum = any(co.conkey)
			and co.contype = 'f'
		left join
			pg_class c2
		on	co.confrelid = c2.oid
		where	pg_get_userbyid(c.relowner) = current_user
			and c.relname = tblname
			and n.nspname = sch
			and (c.relkind = 'r'::"char" or
				c.relkind = 'v'::"char")
			and c.relnatts > 1
			and a.attnum > 0
		order by a.attnum
	loop
		tmp = 'select xmlelement(name "asl:attribute", xmlattributes('''|| rec.attname || ''' as name, '''|| initcap(replace(rec.attname, '_', ' ')) || ''' as label, ''true'' as column, ';
		if rec.typname = 'bool' then
			tmp = tmp || '''boolean'' as type';
		elsif rec.typname = 'int4' or rec.typname = 'int2' or rec.typname = 'int8' then
			if rec.contype is not null then
				tmp = tmp || '''integer'' as type, ''si'' as "foranea"';
			else
				tmp = tmp || '''integer'' as type';
			end if;
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;			
		elsif rec.typname = 'float4' or rec.typname = 'float8' then
			tmp = tmp || '''float'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;			
		elsif rec.typname = 'date' or rec.typname = 'time' or rec.typname = 'timestamp' then
			tmp = tmp || '''date'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;
		else
			tmp = tmp || '''varchar'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;
			if rec.atttypmod <> -1 then
				tmp = tmp || ', '''||(rec.atttypmod-4)::varchar|| ''' as "maxChars"';
			end if;
		end if;
		tmp = tmp ||'))';
		execute tmp into ret;
		return next ret;
	end loop;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_get_external_request(name, name); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_get_external_request(tblname name, sch name) RETURNS xml
    AS $$
declare
	rec record;
	rec2 record;
	ret xml;
	tmp varchar;
begin 
	
	for rec in
		select	a.attname, c2.relname
		from	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		inner join
			pg_attribute a
		on a.attrelid = c.oid
		inner join
			pg_constraint co
		on	co.conrelid = c.oid
			and a.attnum = any(co.conkey)
			and co.contype = 'f'
		inner join
			pg_class c2
		on	co.confrelid = c2.oid
		where	pg_get_userbyid(c.relowner) = current_user
			and c.relname = tblname
			and n.nspname = sch
			and (c.relkind = 'r'::"char" or
				c.relkind = 'v'::"char")
			and c.relnatts > 1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = xmlconcat(ret, xmlelement(
			name "asl:request", 
			xmlattributes(
				'ff_'||rec.relname as name,
				'{[form_'||rec.attname||', filtro_'||rec.attname||']}' as targets
			)
		));
	end loop;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_get_manager_list(name, name, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_get_manager_list(tblname name, sch name, is_parent boolean) RETURNS xml
    AS $$
declare
	ret xml;
	ops varchar;
begin
	select case relkind 
		when 'r' then 
			'true' 
		else 
			'false' 
		end into ops 
	from 	pg_class 
	where 	relname = tblname 
	and 	is_parent = true;
	
	select 	xmlconcat(
			xmlelement(
				name "asl:attributes",
				(
					select 	xmlagg(x)
					from	anthill.ce_get_attribute(tblname, sch) as x
				)
			),
			xmlelement(
				name "asl:children",
				(
				select xmlagg(xmlelement(name "asl:child",xmlattributes('tab' as pos),c2.relname))
				from	pg_class c
				inner join
					pg_namespace n
				on	n.oid = c.relnamespace
				inner join
					pg_constraint co
				on	co.confrelid = c.oid
				inner join
					pg_class c2
				on	co.conrelid = c2.oid
				where	pg_get_userbyid(c.relowner) = current_user
					and c.relname = tblname
					and n.nspname = sch
					and (c.relkind = 'r'::"char" or
						c.relkind = 'v'::"char")
					and c.relnatts > 1
					and co.contype = 'f'
					and is_parent = true
				)
			)
		)
	into ret;
	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_get_xml(name, name); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_get_xml(tblname name, sch name) RETURNS xml
    AS $$
declare
	tmp varchar;
	dbn name;
	rec record;
	ret xml;
	
begin

	select current_database() into dbn;
	
	select xmlroot(
		xmlelement(
			name "asl:manager", 
			xmlattributes(
				'http://anthill.com.ar/2009/asl' as "xmlns:asl", 
				initcap(replace(tblname, '_', ' ')) as label,
				tblname as name,
				dbn as db
			),
			xmlelement(
				name "asl:external", 
				(
					select 	xmlagg(x)
					from	anthill.ce_get_external_request(tblname, sch) as x
				)
			),
			anthill.ce_get_manager_list(tblname, sch, true)
		), 
		version '1.0', 
		standalone no
	) into ret;

	return ret;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_tg(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_tg() RETURNS character varying
    AS $$
	select 	ce_tg(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$$
    LANGUAGE sql;


--
-- Name: ce_tg(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_tg(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	v_view varchar;
	schma varchar;
begin
	select  nspname, relname into schma, v_view 
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	c.oid = $1;
	
	ret = 	'create or replace function '||schma||'.ftg_' ||v_view||' () returns trigger as'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		'   if (tg_op = ''UPDATE'') then'||E'\n'||
		'   	if old.obsoleto != new.obsoleto then'||E'\n'||
		'   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) '||E'\n'||
		'   		values ('''||schma||'.'||v_view||''',new.id_'||v_view||',''obsoleto'',new.obsoleto,user,now());'||E'\n'||
		'   	end if;'||E'\n'||
		'   elsif (tg_op = ''INSERT'') then'||E'\n'||
		'   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) '||E'\n'||
		'   	values ('''||schma||'.'||v_view||''',new.id_'||v_view||',true,user,now());'||E'\n'||
		'   end if;'||E'\n'||
		'   return new;'||E'\n'||
		'end;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'language plpgsql;';	
	execute ret;
	ret = 	'create trigger tiu_'||schma||'_'||v_view||' before insert or update on '||schma||'.'||v_view||' for each row execute procedure '||schma||'.ftg_' ||v_view||' ();';
	execute ret;
	DROP TRIGGER if exists tiu_anthill_ce_auditoria ON anthill.ce_auditoria;
	return ret ;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_view_all(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_view_all() RETURNS character varying
    AS $$
declare 
	ret varchar;
begin
	perform ce_view_all(oid)
	from 	pg_class
	where 	relkind = 'r'::"char" and
		pg_get_userbyid(relowner) = current_user
		and relnatts > 1
		and relname not like '%_mig%'
	order by oid;
	return '';
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_view_all(oid); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ce_view_all(id_table oid) RETURNS character varying
    AS $_$
declare 
	ret varchar;
	ejecutar varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	ret = '';
	
	for rec in 
		select	a.attname, t.typname, a.attnum
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret || rec.attname || ', ' ;
	end loop;
	
	for rec in 
		select	a.attname, cl.relname, n.nspname, c.* 
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_namespace n
		on	n.oid = cl.relnamespace
		where	a.attrelid =  $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret || rec.nspname||'.ff_' ||rec.relname||' ('|| rec.attname||') as ff_' || rec.attname || ', ' ;
	end loop;

	ret = substring(ret from 1 for char_length(ret) -2); 

	select  n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.oid=$1;

	ejecutar = 'create or replace view '||schma||'.v_' ||v_view||'_all as select '||ret||' from '||schma||'.'||v_view ;
	execute ejecutar ;
	ejecutar  = 'create or replace view '||schma||'.v_' ||v_view||' as select '||ret||' from '||schma||'.v_' ||v_view||'_all where coalesce(obsoleto,false) = false' ;
	execute ejecutar ;
	return ejecutar ;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_ce_adhoc(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fd_ce_adhoc(id_ce_adhoc_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update anthill.ce_adhoc set obsoleto = true where id_ce_adhoc = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad anthill.ce_adhoc no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_ce_auditoria(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fd_ce_auditoria(id_ce_auditoria_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update anthill.ce_auditoria set obsoleto = true where id_ce_auditoria = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad anthill.ce_auditoria no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ff_ce_adhoc(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ff_ce_adhoc(id_ce_adhoc_arg integer) RETURNS character varying
    AS $_$ 
   select ejecutar from anthill.ce_adhoc
 where id_ce_adhoc = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_ce_adhoc(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ff_ce_adhoc() RETURNS SETOF t_ff
    AS $$ 
   select id_ce_adhoc::int as data, ejecutar::varchar as label
 from anthill.ce_adhoc
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_ce_auditoria(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ff_ce_auditoria(id_ce_auditoria_arg integer) RETURNS character varying
    AS $_$ 
   select entidad from anthill.ce_auditoria
 where id_ce_auditoria = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_ce_auditoria(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ff_ce_auditoria() RETURNS SETOF t_ff
    AS $$ 
   select id_ce_auditoria::int as data, entidad::varchar as label
 from anthill.ce_auditoria
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ce_adhoc; Type: TABLE; Schema: anthill; Owner: -; Tablespace: 
--

CREATE TABLE ce_adhoc (
    id_ce_adhoc integer NOT NULL,
    ejecutar character varying,
    orden integer,
    obsoleto boolean
);


--
-- Name: v_ce_adhoc_all; Type: VIEW; Schema: anthill; Owner: -
--

CREATE VIEW v_ce_adhoc_all AS
    SELECT ce_adhoc.id_ce_adhoc, ce_adhoc.ejecutar, ce_adhoc.orden, ce_adhoc.obsoleto FROM ce_adhoc;


--
-- Name: fq_ce_adhoc(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc() RETURNS SETOF v_ce_adhoc_all
    AS $$ 
 select *
 from anthill.v_ce_adhoc_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_ce_adhoc(integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc(lim_arg integer, off_arg integer) RETURNS SETOF v_ce_adhoc_all
    AS $_$ 
 select *
 from anthill.v_ce_adhoc_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_adhoc(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc(id_ce_adhoc_arg integer) RETURNS SETOF v_ce_adhoc_all
    AS $_$ 
 select *
 from anthill.v_ce_adhoc_all
 where id_ce_adhoc = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_adhoc(integer, integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc(id_ce_adhoc_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_ce_adhoc_all
    AS $_$ 
 select *
 from anthill.v_ce_adhoc_all
 where id_ce_adhoc = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_adhoc(integer, character varying, integer, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc(id_ce_adhoc_arg integer, ejecutar_arg character varying, orden_arg integer, obsoleto_arg boolean) RETURNS SETOF v_ce_adhoc_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_adhoc_all
 where 
(id_ce_adhoc = id_ce_adhoc_arg or id_ce_adhoc_arg is null) and 
translate(coalesce(ejecutar::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((ejecutar_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(orden = orden_arg or orden_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_ce_adhoc(integer, character varying, integer, boolean, integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_adhoc(id_ce_adhoc_arg integer, ejecutar_arg character varying, orden_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_ce_adhoc_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_adhoc_all
 where 
(id_ce_adhoc = id_ce_adhoc_arg or id_ce_adhoc_arg is null) and 
translate(coalesce(ejecutar::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((ejecutar_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(orden = orden_arg or orden_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ce_auditoria; Type: TABLE; Schema: anthill; Owner: -; Tablespace: 
--

CREATE TABLE ce_auditoria (
    id_ce_auditoria bigint NOT NULL,
    entidad character varying,
    id integer,
    nueva_fila boolean,
    atributo character varying(255),
    valor character varying(255),
    usuario character varying,
    fecha timestamp without time zone,
    obsoleto boolean
);


--
-- Name: v_ce_auditoria_all; Type: VIEW; Schema: anthill; Owner: -
--

CREATE VIEW v_ce_auditoria_all AS
    SELECT ce_auditoria.id_ce_auditoria, ce_auditoria.entidad, ce_auditoria.id, ce_auditoria.nueva_fila, ce_auditoria.atributo, ce_auditoria.valor, ce_auditoria.usuario, ce_auditoria.fecha, ce_auditoria.obsoleto FROM ce_auditoria;


--
-- Name: fq_ce_auditoria(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria() RETURNS SETOF v_ce_auditoria_all
    AS $$ 
 select *
 from anthill.v_ce_auditoria_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_ce_auditoria(integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria(lim_arg integer, off_arg integer) RETURNS SETOF v_ce_auditoria_all
    AS $_$ 
 select *
 from anthill.v_ce_auditoria_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_auditoria(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria(id_ce_auditoria_arg integer) RETURNS SETOF v_ce_auditoria_all
    AS $_$ 
 select *
 from anthill.v_ce_auditoria_all
 where id_ce_auditoria = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_auditoria(integer, integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria(id_ce_auditoria_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_ce_auditoria_all
    AS $_$ 
 select *
 from anthill.v_ce_auditoria_all
 where id_ce_auditoria = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_ce_auditoria(bigint, character varying, integer, boolean, character varying, character varying, character varying, timestamp without time zone, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria(id_ce_auditoria_arg bigint, entidad_arg character varying, id_arg integer, nueva_fila_arg boolean, atributo_arg character varying, valor_arg character varying, usuario_arg character varying, fecha_arg timestamp without time zone, obsoleto_arg boolean) RETURNS SETOF v_ce_auditoria_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_auditoria_all
 where 
(id_ce_auditoria = id_ce_auditoria_arg or id_ce_auditoria_arg is null) and 
translate(coalesce(entidad::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((entidad_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id = id_arg or id_arg is null) and 
(nueva_fila_arg is null or nueva_fila::boolean = nueva_fila_arg::boolean) and 
translate(coalesce(atributo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((atributo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(valor::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((valor_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(usuario::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((usuario_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_ce_auditoria(bigint, character varying, integer, boolean, character varying, character varying, character varying, timestamp without time zone, boolean, integer, integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fq_ce_auditoria(id_ce_auditoria_arg bigint, entidad_arg character varying, id_arg integer, nueva_fila_arg boolean, atributo_arg character varying, valor_arg character varying, usuario_arg character varying, fecha_arg timestamp without time zone, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_ce_auditoria_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_auditoria_all
 where 
(id_ce_auditoria = id_ce_auditoria_arg or id_ce_auditoria_arg is null) and 
translate(coalesce(entidad::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((entidad_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id = id_arg or id_arg is null) and 
(nueva_fila_arg is null or nueva_fila::boolean = nueva_fila_arg::boolean) and 
translate(coalesce(atributo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((atributo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(valor::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((valor_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(usuario::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((usuario_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fql_ce_adhoc(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fql_ce_adhoc(id_ce_adhoc_arg integer) RETURNS SETOF v_ce_adhoc_all
    AS $_$ 
 select id_ce_adhoc, ejecutar, orden, obsoleto from anthill.fq_ce_adhoc() where id_ce_adhoc = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_ce_auditoria(integer); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fql_ce_auditoria(id_ce_auditoria_arg integer) RETURNS SETOF v_ce_auditoria_all
    AS $_$ 
 select id_ce_auditoria, entidad, id, nueva_fila, atributo, valor, usuario, fecha, obsoleto from anthill.fq_ce_auditoria() where id_ce_auditoria = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fqr_ce_adhoc(integer, integer, character varying, integer, integer, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fqr_ce_adhoc(id_ce_adhoc_arg_desde integer, id_ce_adhoc_arg_hasta integer, ejecutar_arg character varying, orden_arg_desde integer, orden_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_ce_adhoc_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_adhoc_all
 where 
((id_ce_adhoc >= id_ce_adhoc_arg_desde or id_ce_adhoc_arg_desde is null) and  (id_ce_adhoc <= id_ce_adhoc_arg_hasta or id_ce_adhoc_arg_hasta is null))and 
translate(coalesce(ejecutar::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((ejecutar_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((orden >= orden_arg_desde or orden_arg_desde is null) and  (orden <= orden_arg_hasta or orden_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_ce_auditoria(bigint, bigint, character varying, integer, integer, boolean, character varying, character varying, character varying, timestamp without time zone, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fqr_ce_auditoria(id_ce_auditoria_arg_desde bigint, id_ce_auditoria_arg_hasta bigint, entidad_arg character varying, id_arg_desde integer, id_arg_hasta integer, nueva_fila_arg boolean, atributo_arg character varying, valor_arg character varying, usuario_arg character varying, fecha_arg timestamp without time zone, obsoleto_arg boolean) RETURNS SETOF v_ce_auditoria_all
    AS $$ 
begin
 return query
 select *
 from anthill.v_ce_auditoria_all
 where 
((id_ce_auditoria >= id_ce_auditoria_arg_desde or id_ce_auditoria_arg_desde is null) and  (id_ce_auditoria <= id_ce_auditoria_arg_hasta or id_ce_auditoria_arg_hasta is null))and 
translate(coalesce(entidad::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((entidad_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((id >= id_arg_desde or id_arg_desde is null) and  (id <= id_arg_hasta or id_arg_hasta is null))and 
(nueva_fila_arg is null or nueva_fila::boolean = nueva_fila_arg::boolean) and 
translate(coalesce(atributo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((atributo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(valor::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((valor_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(usuario::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((usuario_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fs_ce_adhoc(integer, character varying, integer, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fs_ce_adhoc(id_ce_adhoc_arg integer, ejecutar_arg character varying, orden_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into anthill.ce_adhoc (ejecutar, orden, obsoleto) 
      		values ($2, 
		$3, 
		$4); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_ce_adhoc)
      		from	anthill.v_ce_adhoc;
  	else 
      		update   anthill.ce_adhoc
      		set	ejecutar = $2, 
			orden = $3, 
			obsoleto = $4
      		where	id_ce_adhoc = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad anthill.ce_adhoc no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_ce_auditoria(bigint, character varying, integer, boolean, character varying, character varying, character varying, timestamp without time zone, boolean); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION fs_ce_auditoria(id_ce_auditoria_arg bigint, entidad_arg character varying, id_arg integer, nueva_fila_arg boolean, atributo_arg character varying, valor_arg character varying, usuario_arg character varying, fecha_arg timestamp without time zone, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into anthill.ce_auditoria (entidad, id, nueva_fila, atributo, valor, usuario, fecha, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6, 
		$7, 
		$8, 
		$9); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_ce_auditoria)
      		from	anthill.v_ce_auditoria;
  	else 
      		update   anthill.ce_auditoria
      		set	entidad = $2, 
			id = $3, 
			nueva_fila = $4, 
			atributo = $5, 
			valor = $6, 
			usuario = $7, 
			fecha = $8, 
			obsoleto = $9
      		where	id_ce_auditoria = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad anthill.ce_auditoria no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ftg_ce_adhoc(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ftg_ce_adhoc() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('anthill.ce_adhoc',new.id_ce_adhoc,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('anthill.ce_adhoc',new.id_ce_adhoc,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_ce_auditoria(); Type: FUNCTION; Schema: anthill; Owner: -
--

CREATE FUNCTION ftg_ce_auditoria() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('anthill.ce_auditoria',new.id_ce_auditoria,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('anthill.ce_auditoria',new.id_ce_auditoria,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

--
-- Name: ce_ejecutar(xml); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ce_ejecutar(xml) RETURNS character varying
    AS $_$
declare 
	ejecutar varchar;
	tmp xml[];
	td xml[];
	source xml[];
	ignorar xml[];
	valor xml[];
	funciones xml[];
	atributos xml[];
	tmp2 xml[];
	tmp_path text;
	v_view varchar; 
	i int;
	j int;
	ret xml;
	retorno xml;
	mal int;
	v_ignorar varchar;
begin
	ejecutar = '';
	v_ignorar = '  ';
	mal=0;
	funciones = xpath('//funcion',$1);
	i=1;
	WHILE i <= array_upper(funciones,1) LOOP
		tmp=xpath('//funcion/@nombre', funciones[i]);
		ejecutar = 'select * from '||XMLSERIALIZE ( CONTENT tmp[1] as varchar) || '(  ';
		atributos = xpath('//funcion/atributo',funciones[i]);
		j=1;
		WHILE j <= array_upper(atributos,1) LOOP
			td = xpath('//@tipo_dato',atributos[j]);
			source = xpath('//@source',atributos[j]);
			ignorar = xpath('//@ignorar',atributos[j]);
			valor = xpath('//text()',atributos[j]);
			if coalesce(trim(XMLSERIALIZE (CONTENT ignorar[1] as varchar)))='SI' then
				v_ignorar = v_ignorar || j||', ';
			end if;
			if coalesce(trim(XMLSERIALIZE (CONTENT source[1] as varchar)))='SI' then
				tmp_path = '/table[@nombre='''||XMLSERIALIZE (CONTENT valor[1] as varchar)::text||''']/row/'||XMLSERIALIZE (CONTENT valor[1] as varchar)::text||'/text()';
				tmp2 = xpath(tmp_path,retorno);
				--RAISE EXCEPTION 'source si %', tmp2;
				ejecutar = ejecutar || 	ce_tipo_dato(
						coalesce(trim(XMLSERIALIZE (CONTENT tmp2[1] as varchar)),''), 
						coalesce(trim(XMLSERIALIZE (CONTENT    td[1] as varchar)),'')
					   ) || ', ';
			else
				ejecutar = ejecutar || 	ce_tipo_dato(
						coalesce(trim(XMLSERIALIZE (CONTENT valor[1] as varchar)),''), 
						coalesce(trim(XMLSERIALIZE (CONTENT    td[1] as varchar)),'')
					   ) || ', ';
			end if;
			j = j +1;
		END LOOP;
		ejecutar = substring(ejecutar from 1 for char_length(ejecutar) -2);
		if v_ignorar <> '  ' then 
			v_ignorar = substring(v_ignorar from 1 for char_length(v_ignorar) -2);
		end if;


		select  case when XMLSERIALIZE ( CONTENT tmp[1] as varchar) like 'fs_%' then 
				case when v_ignorar <> '  ' then 
					ejecutar || ', array[' || v_ignorar || ']' 
				else 	
					ejecutar || ', null::int[]' 
				end 
			else 	ejecutar
			end
			into 	ejecutar
		;
		--if XMLSERIALIZE ( CONTENT tmp[1] as varchar) = 'fq_concepto' then
			--RAISE EXCEPTION '%', ejecutar;
		--end if;
		ejecutar = ejecutar ||
			')';
		--RAISE EXCEPTION 'actual %', ejecutar;
		begin
			select '<table nombre='''||XMLSERIALIZE ( CONTENT tmp[1] as varchar)||'''>'||query_to_xml(ejecutar,true,true,'')||'</table>' into ret; 
		exception
			when others then 
			begin
				mal=1;
				select '<table  nombre='''||XMLSERIALIZE ( CONTENT tmp[1] as varchar)||'''><error>'||SQLSTATE||':'||SQLERRM||'</error></table>' into ret;
			end;
		end;
		retorno = xmlconcat(retorno,E'\n',ret);
		i=i+1;
	end loop;
	if mal <> 0 then
		RAISE EXCEPTION '%', retorno; 
	end if;
	return ('<resultado>'||retorno||'</resultado>')::xml;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ce_tipo_dato(character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ce_tipo_dato(character varying, character varying) RETURNS character varying
    AS $_$
declare 
	retorno varchar;
	valor varchar;
begin
	if $1 = '' or $1 isnull 
	then
		valor='null::'||$2;
		retorno = valor;
	else
		valor=$1;
		if 	$2 = 'int4' or 
			$2 = 'integer' or 
			$2 = 'boolean' or 
			$2 = 'numeric' 
		then 
			retorno = valor||'::'||$2;
		else
			retorno = ''''||valor||'''::'||$2;
		end if;
	end if;
	return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: f_asistencia(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION f_asistencia(id_tipo_cliente_arg integer, mes integer, anio integer) RETURNS SETOF asistencia
    AS $$
declare
	rec record;
	rec2 record;
	dm integer;
	co integer;
	tmp text;
begin
	SELECT date_part('day', 
        (anio::varchar || '-' ||
        mes::varchar || '-01')::date 
                + '1 month'::interval
                - '1 day'::interval) into dm;
                
	for rec in
		select 	p.cuip,
			p.otro,
			p.nombre,
			p.apellido,
			c.id_cliente,
			tc.descripcion
		from	persona p
		inner join
			cliente c
		on	c.id_persona = p.id_persona
		inner join
			tipo_cliente tc
		on	c.id_tipo_cliente = tc.id_tipo_cliente
		where	c.id_tipo_cliente = id_tipo_cliente_arg
			or id_tipo_cliente_arg is null
	loop
		co = 1;
		tmp = 	'select '||coalesce(rec.cuip::varchar,'null')||'::bigint, '||
			'	'||coalesce(rec.otro::varchar,'null')||'::bigint, '||
			'	'''||coalesce(rec.nombre::varchar,'null')||'''::varchar, '||
			'	'''||coalesce(rec.apellido::varchar,'null')||'''::varchar, '||
			'	'''||coalesce(rec.descripcion::varchar,'null')||'''::varchar, ';
		loop
			if co > dm then
				exit;
			end if;
			if exists(select 1 from racion where id_cliente = rec.id_cliente and fecha::date = (anio::varchar||'-'||mes::varchar||'-'||co::varchar)::date) then
				tmp = tmp || '	''t''::char, ';
			elsif date_part('dow', (anio::varchar||'-'||mes::varchar||'-'||co::varchar)::timestamp) = any(ARRAY[0::int, 6::int]) then
				tmp = tmp || '	''n''::char, ';
			else
				tmp = tmp || '	''f''::char, ';
			end if;
			co = co+1;
		end loop;
		loop
			if co > 31 then
				exit;
			end if;
			tmp = tmp || '	''n''::char, ';
			co = co+1;
		end loop;
		tmp = substring(tmp from 1 for char_length(tmp)-2);
		execute tmp into rec2;
		return next rec2;
	end loop;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: f_buscar(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION f_buscar(codigo character varying) RETURNS SETOF busqueda
    AS $_$ 
select 	*
from	(
	select case when c.id_persona is null and c.id_evento is not null then 3 else 1 end as tipo_codigo,
		c.id_cliente,
		p.id_persona,
		p.nombre,
		p.apellido,
		p.cuip,
		c.saldo,
		null as id_extra,
		null as descripcion,
		null as precio_unitario,
		null as cantidad
	from	fq_cliente(null, $1, null, null, null, null, null, null, null, null, null, false) c
	left join
		fq_persona() p
	on	p.id_persona = c.id_persona
	union
	select	2 as tipo_codigo,
		null,
		null,
		null,
		null,
		null,
		null,
		id_extra,
		descripcion,
		precio_unitario,
		case when cero_chk=false then null else cantidad end as cantidad
	from 	fq_extra(null, null, $1, null, null, null, false)
	where 	cero_chk=false or cantidad > 0
) a
limit 1
$_$
    LANGUAGE sql;


--
-- Name: f_paso_molinete(character varying, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION f_paso_molinete(codigo_arg character varying, sync boolean) RETURNS SETOF paso
    AS $_$
declare
	id_cliente_var int;
	test_pasadas_var boolean;
	test_duracion_var boolean;
	test_beca_var boolean; 
	tipo_beca_var char(1);
	valor_var real;
begin
	select 	c.id_cliente,
		pg.racion_x_persona+(case when a.agr is null then 
			0
		   else
			case when tc.max_personas_agregar > 0 and a.agr > tc.max_personas_agregar then
				tc.max_personas_agregar*pg.racion_x_persona
			else
				a.agr*pg.racion_x_persona
			end
		   end)::int > (select count(*) 
			from 	racion r 
			where 	r.id_cliente = c.id_cliente and 
				date_trunc('day', r.fecha) = date_trunc('day', current_timestamp)
		), --chequeo si ya pasó y la cantidad de veces que puede pasar
		case when tc.tipo_duracion = 'R' then
		  case when tc.tipo_renovacion = 'F' then
		    case when tc.renovacion ~ '^[0-9][0-9]?/[0-9][0-9]$' then
		      current_timestamp <= (tc.renovacion||'/'||date_part('year', current_timestamp))::date
		    else
		      current_timestamp <= (tc.renovacion||'/'||date_part('month', current_timestamp)||'/'||date_part('year', current_timestamp))::date
		    end
		  else
		    current_timestamp <= (c.renovado + tc.renovacion::interval)::date
		  end
		when tc.tipo_duracion = 'F' and coalesce(c.fecha_desde, e.fecha_desde) is not null and coalesce(c.fecha_hasta, e.fecha_hasta) is not null then
		    current_timestamp between coalesce(c.fecha_desde, e.fecha_desde) and coalesce(c.fecha_hasta, e.fecha_hasta)			
		else 
		  true
		end, --chequeo si está en una fecha valida
		case when tc.tipo_beca = 'D' then
			case when tc.tipo_monto = '$' then
				c.saldo >=  pg.precio_x_racion - coalesce(c.beca, tc.beca, 0)
			else
				c.saldo >=  pg.precio_x_racion - (pg.precio_x_racion * coalesce(c.beca, tc.beca, 0) / 100)
			end
		else
			coalesce(c.raciones, floor(tc.beca)::int) >= 1
		end, --chequeo que la cantidad de raciones / saldo sea suficiente
		tc.tipo_beca,
		case when tc.tipo_monto = '$' then
			(pg.precio_x_racion - coalesce(c.beca, tc.beca, 0))
		else
			(pg.precio_x_racion - (pg.precio_x_racion * coalesce(c.beca, tc.beca, 0) / 100))
		end
	into 	id_cliente_var,
		test_pasadas_var,
		test_duracion_var,
		test_beca_var,
		tipo_beca_var,
		valor_var
	from 	v_cliente c
	inner join
		v_tipo_cliente tc
	on	c.id_tipo_cliente = tc.id_tipo_cliente
	inner join
		(select *
		from 	v_parametros_generales
		limit 1) pg
	on	1=1
	left join
		(select count(*) as agr,
			id_cliente
		 from 	v_agregado
		 group by id_cliente) a
	on	tc.max_personas_agregar <> 0
		and a.id_cliente = c.id_cliente
	left join
		v_evento e
	on	e.id_evento = c.id_evento
	where	c.codigo = codigo_arg;

	--chequeo si existe el cliente
	if id_cliente_var is null then
		--No es un cliente valido
		if sync then
			return query select null::varchar as codigo, null::varchar as data;
		else
			return query select codigo_arg as codigo, 'no_pase'::varchar as data;
		end if;
	else
		if not(sync) and not(test_pasadas_var and test_duracion_var and test_beca_var) then
			return query select codigo_arg as codigo, 'no_pase'::varchar as data;
		else
			if tipo_beca_var = 'D' then
				update 	cliente
				set	saldo = saldo - valor_var
				where	id_cliente = id_cliente_var;
			else
				valor_var = 0;
				update 	cliente
				set	raciones = raciones -1
				where	id_cliente = id_cliente_var;
			end if;

			insert into racion (id_cliente, tipo_racion, valor)
			values	(id_cliente_var, case when tipo_beca_var = 'D' then 'D' else 'R' end, valor_var);
			
			if sync then
				return query select null::varchar as codigo, null::varchar as data;
			else
				return query select codigo_arg as codigo, 'pase'::varchar as data;
			end if;
		end if;
	end if;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_agregado(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_agregado(id_agregado_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.agregado set obsoleto = true where id_agregado = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.agregado no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_cliente(id_cliente_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.cliente set obsoleto = true where id_cliente = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.cliente no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_evento(id_evento_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.evento set obsoleto = true where id_evento = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.evento no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_extra(id_extra_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.extra set obsoleto = true where id_extra = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.extra no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_item_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_item_venta(id_item_venta_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.item_venta set obsoleto = true where id_item_venta = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.item_venta no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_parametros_generales(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_parametros_generales(id_parametros_generales_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.parametros_generales set obsoleto = true where id_parametros_generales = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.parametros_generales no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_persona(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_persona(id_persona_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.persona set obsoleto = true where id_persona = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.persona no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_racion(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_racion(id_racion_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.racion set obsoleto = true where id_racion = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.racion no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_tipo_cliente(id_tipo_cliente_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.tipo_cliente set obsoleto = true where id_tipo_cliente = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.tipo_cliente no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fd_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fd_venta(id_venta_arg integer) RETURNS integer
    AS $_$ 
declare
	rowc integer;
	canti integer;
begin
	update public.venta set obsoleto = true where id_venta = $1;
   	get diagnostics rowc = row_count;
   	if rowc <= 0 then
      		RAISE EXCEPTION 'En la entidad public.venta no se pudo borrar.';
   	end if;
 return $1;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ff_agregado(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_agregado(id_agregado_arg integer) RETURNS integer
    AS $_$ 
   select id_cliente from public.agregado
 where id_agregado = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_agregado(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_agregado() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_agregado::int as data, id_cliente::varchar as label
 from public.agregado
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_cliente(id_cliente_arg integer) RETURNS character varying
    AS $_$ 
   select codigo from public.cliente
 where id_cliente = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_cliente() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_cliente::int as data, codigo::varchar as label
 from public.cliente
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_evento(id_evento_arg integer) RETURNS character varying
    AS $_$ 
   select nombre from public.evento
 where id_evento = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_evento(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_evento() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_evento::int as data, nombre::varchar as label
 from public.evento
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_extra(id_extra_arg integer) RETURNS character varying
    AS $_$ 
   select descripcion from public.extra
 where id_extra = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_extra(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_extra() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_extra::int as data, descripcion::varchar as label
 from public.extra
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_item_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_item_venta(id_item_venta_arg integer) RETURNS integer
    AS $_$ 
   select id_venta from public.item_venta
 where id_item_venta = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_item_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_item_venta() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_item_venta::int as data, id_venta::varchar as label
 from public.item_venta
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_persona(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_persona(id_persona_arg integer) RETURNS character varying
    AS $_$ 
   select nombre from public.persona
 where id_persona = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_persona(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_persona() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_persona::int as data, nombre::varchar as label
 from public.persona
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_racion(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_racion(id_racion_arg integer) RETURNS timestamp without time zone
    AS $_$ 
   select fecha from public.racion
 where id_racion = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_racion(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_racion() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_racion::int as data, fecha::varchar as label
 from public.racion
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_tipo_cliente(id_tipo_cliente_arg integer) RETURNS character varying
    AS $_$ 
   select descripcion from public.tipo_cliente
 where id_tipo_cliente = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_tipo_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_tipo_cliente() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_tipo_cliente::int as data, descripcion::varchar as label
 from public.tipo_cliente
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: ff_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_venta(id_venta_arg integer) RETURNS integer
    AS $_$ 
   select id_cliente from public.venta
 where id_venta = $1 and COALESCE(obsoleto, false) = false;
$_$
    LANGUAGE sql;


--
-- Name: ff_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ff_venta() RETURNS SETOF anthill.t_ff
    AS $$ 
   select id_venta::int as data, id_cliente::varchar as label
 from public.venta
 where COALESCE(obsoleto, false) = false;
$$
    LANGUAGE sql;


--
-- Name: agregado; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE agregado (
    id_agregado integer NOT NULL,
    id_cliente integer,
    id_persona integer,
    orden integer DEFAULT 0,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_agregado_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_agregado_all AS
    SELECT agregado.id_agregado, agregado.id_cliente, agregado.id_persona, agregado.orden, agregado.obsoleto, ff_cliente(agregado.id_cliente) AS ff_id_cliente FROM agregado;


--
-- Name: v_agregado; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_agregado AS
    SELECT v_agregado_all.id_agregado, v_agregado_all.id_cliente, v_agregado_all.id_persona, v_agregado_all.orden, v_agregado_all.obsoleto, ff_cliente(v_agregado_all.id_cliente) AS ff_id_cliente FROM v_agregado_all WHERE (COALESCE(v_agregado_all.obsoleto, false) = false);


--
-- Name: fl_agregado_by_id_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_agregado_by_id_cliente(var_id_cliente integer) RETURNS SETOF v_agregado
    AS $_$ 
 select * from public.v_agregado where id_cliente = $1;
$_$
    LANGUAGE sql;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cliente (
    id_cliente integer NOT NULL,
    codigo character varying(100),
    id_persona integer,
    id_evento integer,
    id_tipo_cliente integer,
    beca real,
    renovado date,
    fecha_desde date,
    fecha_hasta date,
    saldo real DEFAULT 0.0,
    raciones integer DEFAULT 0,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_cliente_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_cliente_all AS
    SELECT cliente.id_cliente, cliente.codigo, cliente.id_persona, cliente.id_evento, cliente.id_tipo_cliente, cliente.beca, cliente.renovado, cliente.fecha_desde, cliente.fecha_hasta, cliente.saldo, cliente.raciones, cliente.obsoleto, ff_evento(cliente.id_evento) AS ff_id_evento, ff_tipo_cliente(cliente.id_tipo_cliente) AS ff_id_tipo_cliente FROM cliente;


--
-- Name: v_cliente; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_cliente AS
    SELECT v_cliente_all.id_cliente, v_cliente_all.codigo, v_cliente_all.id_persona, v_cliente_all.id_evento, v_cliente_all.id_tipo_cliente, v_cliente_all.beca, v_cliente_all.renovado, v_cliente_all.fecha_desde, v_cliente_all.fecha_hasta, v_cliente_all.saldo, v_cliente_all.raciones, v_cliente_all.obsoleto, ff_evento(v_cliente_all.id_evento) AS ff_id_evento, ff_tipo_cliente(v_cliente_all.id_tipo_cliente) AS ff_id_tipo_cliente FROM v_cliente_all WHERE (COALESCE(v_cliente_all.obsoleto, false) = false);


--
-- Name: fl_cliente_by_id_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_cliente_by_id_evento(var_id_evento integer) RETURNS SETOF v_cliente
    AS $_$ 
 select * from public.v_cliente where id_evento = $1;
$_$
    LANGUAGE sql;


--
-- Name: fl_cliente_by_id_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_cliente_by_id_tipo_cliente(var_id_tipo_cliente integer) RETURNS SETOF v_cliente
    AS $_$ 
 select * from public.v_cliente where id_tipo_cliente = $1;
$_$
    LANGUAGE sql;


--
-- Name: item_venta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item_venta (
    id_item_venta integer NOT NULL,
    id_venta integer NOT NULL,
    id_extra integer,
    cantidad integer,
    subtotal real,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_item_venta_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_item_venta_all AS
    SELECT item_venta.id_item_venta, item_venta.id_venta, item_venta.id_extra, item_venta.cantidad, item_venta.subtotal, item_venta.obsoleto, ff_venta(item_venta.id_venta) AS ff_id_venta, ff_extra(item_venta.id_extra) AS ff_id_extra FROM item_venta;


--
-- Name: v_item_venta; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_item_venta AS
    SELECT v_item_venta_all.id_item_venta, v_item_venta_all.id_venta, v_item_venta_all.id_extra, v_item_venta_all.cantidad, v_item_venta_all.subtotal, v_item_venta_all.obsoleto, ff_venta(v_item_venta_all.id_venta) AS ff_id_venta, ff_extra(v_item_venta_all.id_extra) AS ff_id_extra FROM v_item_venta_all WHERE (COALESCE(v_item_venta_all.obsoleto, false) = false);


--
-- Name: fl_item_venta_by_id_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_item_venta_by_id_extra(var_id_extra integer) RETURNS SETOF v_item_venta
    AS $_$ 
 select * from public.v_item_venta where id_extra = $1;
$_$
    LANGUAGE sql;


--
-- Name: fl_item_venta_by_id_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_item_venta_by_id_venta(var_id_venta integer) RETURNS SETOF v_item_venta
    AS $_$ 
 select * from public.v_item_venta where id_venta = $1;
$_$
    LANGUAGE sql;


--
-- Name: racion; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE racion (
    id_racion integer NOT NULL,
    fecha timestamp without time zone DEFAULT now(),
    id_cliente integer,
    tipo_racion "char" DEFAULT 'D'::"char",
    valor real,
    obsoleto boolean DEFAULT false,
    CONSTRAINT chk_racion_tipo_racion CHECK ((tipo_racion = ANY (ARRAY['D'::"char", 'R'::"char"])))
);


--
-- Name: v_racion_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_racion_all AS
    SELECT racion.id_racion, racion.fecha, racion.id_cliente, racion.tipo_racion, racion.valor, racion.obsoleto, ff_cliente(racion.id_cliente) AS ff_id_cliente FROM racion;


--
-- Name: v_racion; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_racion AS
    SELECT v_racion_all.id_racion, v_racion_all.fecha, v_racion_all.id_cliente, v_racion_all.tipo_racion, v_racion_all.valor, v_racion_all.obsoleto, ff_cliente(v_racion_all.id_cliente) AS ff_id_cliente FROM v_racion_all WHERE (COALESCE(v_racion_all.obsoleto, false) = false);


--
-- Name: fl_racion_by_id_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_racion_by_id_cliente(var_id_cliente integer) RETURNS SETOF v_racion
    AS $_$ 
 select * from public.v_racion where id_cliente = $1;
$_$
    LANGUAGE sql;


--
-- Name: venta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE venta (
    id_venta integer NOT NULL,
    id_cliente integer,
    fecha timestamp without time zone DEFAULT now(),
    ingreso real,
    saldo real,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_venta_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_venta_all AS
    SELECT venta.id_venta, venta.id_cliente, venta.fecha, venta.ingreso, venta.saldo, venta.obsoleto, ff_cliente(venta.id_cliente) AS ff_id_cliente FROM venta;


--
-- Name: v_venta; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_venta AS
    SELECT v_venta_all.id_venta, v_venta_all.id_cliente, v_venta_all.fecha, v_venta_all.ingreso, v_venta_all.saldo, v_venta_all.obsoleto, ff_cliente(v_venta_all.id_cliente) AS ff_id_cliente FROM v_venta_all WHERE (COALESCE(v_venta_all.obsoleto, false) = false);


--
-- Name: fl_venta_by_id_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fl_venta_by_id_cliente(var_id_cliente integer) RETURNS SETOF v_venta
    AS $_$ 
 select * from public.v_venta where id_cliente = $1;
$_$
    LANGUAGE sql;


--
-- Name: fq_agregado(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado() RETURNS SETOF v_agregado_all
    AS $$ 
 select *
 from public.v_agregado_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_agregado(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado(lim_arg integer, off_arg integer) RETURNS SETOF v_agregado_all
    AS $_$ 
 select *
 from public.v_agregado_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_agregado(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado(id_agregado_arg integer) RETURNS SETOF v_agregado_all
    AS $_$ 
 select *
 from public.v_agregado_all
 where id_agregado = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_agregado(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado(id_agregado_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_agregado_all
    AS $_$ 
 select *
 from public.v_agregado_all
 where id_agregado = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_agregado(integer, integer, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado(id_agregado_arg integer, id_cliente_arg integer, id_persona_arg integer, orden_arg integer, obsoleto_arg boolean) RETURNS SETOF v_agregado_all
    AS $$ 
begin
 return query
 select *
 from public.v_agregado_all
 where 
(id_agregado = id_agregado_arg or id_agregado_arg is null) and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
(id_persona = id_persona_arg or id_persona_arg is null) and 
(orden = orden_arg or orden_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_agregado(integer, integer, integer, integer, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_agregado(id_agregado_arg integer, id_cliente_arg integer, id_persona_arg integer, orden_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_agregado_all
    AS $$ 
begin
 return query
 select *
 from public.v_agregado_all
 where 
(id_agregado = id_agregado_arg or id_agregado_arg is null) and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
(id_persona = id_persona_arg or id_persona_arg is null) and 
(orden = orden_arg or orden_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente() RETURNS SETOF v_cliente_all
    AS $$ 
 select *
 from public.v_cliente_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_cliente(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente(lim_arg integer, off_arg integer) RETURNS SETOF v_cliente_all
    AS $_$ 
 select *
 from public.v_cliente_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente(id_cliente_arg integer) RETURNS SETOF v_cliente_all
    AS $_$ 
 select *
 from public.v_cliente_all
 where id_cliente = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_cliente(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente(id_cliente_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_cliente_all
    AS $_$ 
 select *
 from public.v_cliente_all
 where id_cliente = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_cliente(integer, character varying, integer, integer, integer, real, date, date, date, real, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente(id_cliente_arg integer, codigo_arg character varying, id_persona_arg integer, id_evento_arg integer, id_tipo_cliente_arg integer, beca_arg real, renovado_arg date, fecha_desde_arg date, fecha_hasta_arg date, saldo_arg real, raciones_arg integer, obsoleto_arg boolean) RETURNS SETOF v_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_cliente_all
 where 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id_persona = id_persona_arg or id_persona_arg is null) and 
(id_evento = id_evento_arg or id_evento_arg is null) and 
(id_tipo_cliente = id_tipo_cliente_arg or id_tipo_cliente_arg is null) and 
(beca = beca_arg or beca_arg is null) and 
(renovado = renovado_arg or renovado_arg is null) and 
(fecha_desde = fecha_desde_arg or fecha_desde_arg is null) and 
(fecha_hasta = fecha_hasta_arg or fecha_hasta_arg is null) and 
(saldo = saldo_arg or saldo_arg is null) and 
(raciones = raciones_arg or raciones_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_cliente(integer, character varying, integer, integer, integer, real, date, date, date, real, integer, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_cliente(id_cliente_arg integer, codigo_arg character varying, id_persona_arg integer, id_evento_arg integer, id_tipo_cliente_arg integer, beca_arg real, renovado_arg date, fecha_desde_arg date, fecha_hasta_arg date, saldo_arg real, raciones_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_cliente_all
 where 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id_persona = id_persona_arg or id_persona_arg is null) and 
(id_evento = id_evento_arg or id_evento_arg is null) and 
(id_tipo_cliente = id_tipo_cliente_arg or id_tipo_cliente_arg is null) and 
(beca = beca_arg or beca_arg is null) and 
(renovado = renovado_arg or renovado_arg is null) and 
(fecha_desde = fecha_desde_arg or fecha_desde_arg is null) and 
(fecha_hasta = fecha_hasta_arg or fecha_hasta_arg is null) and 
(saldo = saldo_arg or saldo_arg is null) and 
(raciones = raciones_arg or raciones_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: evento; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE evento (
    id_evento integer NOT NULL,
    nombre character varying(250) NOT NULL,
    fecha_desde date NOT NULL,
    fecha_hasta date NOT NULL,
    cantidad integer NOT NULL,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_evento_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_evento_all AS
    SELECT evento.id_evento, evento.nombre, evento.fecha_desde, evento.fecha_hasta, evento.cantidad, evento.obsoleto FROM evento;


--
-- Name: fq_evento(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento() RETURNS SETOF v_evento_all
    AS $$ 
 select *
 from public.v_evento_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_evento(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento(lim_arg integer, off_arg integer) RETURNS SETOF v_evento_all
    AS $_$ 
 select *
 from public.v_evento_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento(id_evento_arg integer) RETURNS SETOF v_evento_all
    AS $_$ 
 select *
 from public.v_evento_all
 where id_evento = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_evento(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento(id_evento_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_evento_all
    AS $_$ 
 select *
 from public.v_evento_all
 where id_evento = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_evento(integer, character varying, date, date, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento(id_evento_arg integer, nombre_arg character varying, fecha_desde_arg date, fecha_hasta_arg date, cantidad_arg integer, obsoleto_arg boolean) RETURNS SETOF v_evento_all
    AS $$ 
begin
 return query
 select *
 from public.v_evento_all
 where 
(id_evento = id_evento_arg or id_evento_arg is null) and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(fecha_desde = fecha_desde_arg or fecha_desde_arg is null) and 
(fecha_hasta = fecha_hasta_arg or fecha_hasta_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_evento(integer, character varying, date, date, integer, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_evento(id_evento_arg integer, nombre_arg character varying, fecha_desde_arg date, fecha_hasta_arg date, cantidad_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_evento_all
    AS $$ 
begin
 return query
 select *
 from public.v_evento_all
 where 
(id_evento = id_evento_arg or id_evento_arg is null) and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(fecha_desde = fecha_desde_arg or fecha_desde_arg is null) and 
(fecha_hasta = fecha_hasta_arg or fecha_hasta_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: extra; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE extra (
    id_extra integer NOT NULL,
    descripcion character varying(200),
    codigo character varying(32),
    precio_unitario real DEFAULT 0.0,
    cantidad integer,
    cero_chk boolean DEFAULT false,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_extra_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_extra_all AS
    SELECT extra.id_extra, extra.descripcion, extra.codigo, extra.precio_unitario, extra.cantidad, extra.cero_chk, extra.obsoleto FROM extra;


--
-- Name: fq_extra(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra() RETURNS SETOF v_extra_all
    AS $$ 
 select *
 from public.v_extra_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_extra(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra(lim_arg integer, off_arg integer) RETURNS SETOF v_extra_all
    AS $_$ 
 select *
 from public.v_extra_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra(id_extra_arg integer) RETURNS SETOF v_extra_all
    AS $_$ 
 select *
 from public.v_extra_all
 where id_extra = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_extra(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra(id_extra_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_extra_all
    AS $_$ 
 select *
 from public.v_extra_all
 where id_extra = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_extra(integer, character varying, character varying, real, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra(id_extra_arg integer, descripcion_arg character varying, codigo_arg character varying, precio_unitario_arg real, cantidad_arg integer, cero_chk_arg boolean, obsoleto_arg boolean) RETURNS SETOF v_extra_all
    AS $$ 
begin
 return query
 select *
 from public.v_extra_all
 where 
(id_extra = id_extra_arg or id_extra_arg is null) and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(precio_unitario = precio_unitario_arg or precio_unitario_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(cero_chk_arg is null or cero_chk::boolean = cero_chk_arg::boolean) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_extra(integer, character varying, character varying, real, integer, boolean, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_extra(id_extra_arg integer, descripcion_arg character varying, codigo_arg character varying, precio_unitario_arg real, cantidad_arg integer, cero_chk_arg boolean, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_extra_all
    AS $$ 
begin
 return query
 select *
 from public.v_extra_all
 where 
(id_extra = id_extra_arg or id_extra_arg is null) and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(precio_unitario = precio_unitario_arg or precio_unitario_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(cero_chk_arg is null or cero_chk::boolean = cero_chk_arg::boolean) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_item_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta() RETURNS SETOF v_item_venta_all
    AS $$ 
 select *
 from public.v_item_venta_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_item_venta(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta(lim_arg integer, off_arg integer) RETURNS SETOF v_item_venta_all
    AS $_$ 
 select *
 from public.v_item_venta_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_item_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta(id_item_venta_arg integer) RETURNS SETOF v_item_venta_all
    AS $_$ 
 select *
 from public.v_item_venta_all
 where id_item_venta = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_item_venta(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta(id_item_venta_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_item_venta_all
    AS $_$ 
 select *
 from public.v_item_venta_all
 where id_item_venta = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_item_venta(integer, integer, integer, integer, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta(id_item_venta_arg integer, id_venta_arg integer, id_extra_arg integer, cantidad_arg integer, subtotal_arg real, obsoleto_arg boolean) RETURNS SETOF v_item_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_item_venta_all
 where 
(id_item_venta = id_item_venta_arg or id_item_venta_arg is null) and 
(id_venta = id_venta_arg or id_venta_arg is null) and 
(id_extra = id_extra_arg or id_extra_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(subtotal = subtotal_arg or subtotal_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_item_venta(integer, integer, integer, integer, real, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_item_venta(id_item_venta_arg integer, id_venta_arg integer, id_extra_arg integer, cantidad_arg integer, subtotal_arg real, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_item_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_item_venta_all
 where 
(id_item_venta = id_item_venta_arg or id_item_venta_arg is null) and 
(id_venta = id_venta_arg or id_venta_arg is null) and 
(id_extra = id_extra_arg or id_extra_arg is null) and 
(cantidad = cantidad_arg or cantidad_arg is null) and 
(subtotal = subtotal_arg or subtotal_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: parametros_generales; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE parametros_generales (
    id_parametros_generales integer NOT NULL,
    precio_x_racion real DEFAULT 0.0,
    racion_x_persona integer DEFAULT 1,
    obsoleto boolean DEFAULT false
);


--
-- Name: v_parametros_generales_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_parametros_generales_all AS
    SELECT parametros_generales.id_parametros_generales, parametros_generales.precio_x_racion, parametros_generales.racion_x_persona, parametros_generales.obsoleto FROM parametros_generales;


--
-- Name: fq_parametros_generales(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales() RETURNS SETOF v_parametros_generales_all
    AS $$ 
 select *
 from public.v_parametros_generales_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_parametros_generales(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales(lim_arg integer, off_arg integer) RETURNS SETOF v_parametros_generales_all
    AS $_$ 
 select *
 from public.v_parametros_generales_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_parametros_generales(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales(id_parametros_generales_arg integer) RETURNS SETOF v_parametros_generales_all
    AS $_$ 
 select *
 from public.v_parametros_generales_all
 where id_parametros_generales = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_parametros_generales(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales(id_parametros_generales_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_parametros_generales_all
    AS $_$ 
 select *
 from public.v_parametros_generales_all
 where id_parametros_generales = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_parametros_generales(integer, real, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales(id_parametros_generales_arg integer, precio_x_racion_arg real, racion_x_persona_arg integer, obsoleto_arg boolean) RETURNS SETOF v_parametros_generales_all
    AS $$ 
begin
 return query
 select *
 from public.v_parametros_generales_all
 where 
(id_parametros_generales = id_parametros_generales_arg or id_parametros_generales_arg is null) and 
(precio_x_racion = precio_x_racion_arg or precio_x_racion_arg is null) and 
(racion_x_persona = racion_x_persona_arg or racion_x_persona_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_parametros_generales(integer, real, integer, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_parametros_generales(id_parametros_generales_arg integer, precio_x_racion_arg real, racion_x_persona_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_parametros_generales_all
    AS $$ 
begin
 return query
 select *
 from public.v_parametros_generales_all
 where 
(id_parametros_generales = id_parametros_generales_arg or id_parametros_generales_arg is null) and 
(precio_x_racion = precio_x_racion_arg or precio_x_racion_arg is null) and 
(racion_x_persona = racion_x_persona_arg or racion_x_persona_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: persona; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE persona (
    id_persona integer NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    cuip bigint,
    otro character varying(100),
    mail character varying(250),
    foto character varying(500),
    obsoleto boolean DEFAULT false
);


--
-- Name: v_persona_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_persona_all AS
    SELECT persona.id_persona, persona.nombre, persona.apellido, persona.cuip, persona.otro, persona.mail, persona.foto, persona.obsoleto FROM persona;


--
-- Name: fq_persona(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona() RETURNS SETOF v_persona_all
    AS $$ 
 select *
 from public.v_persona_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_persona(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona(lim_arg integer, off_arg integer) RETURNS SETOF v_persona_all
    AS $_$ 
 select *
 from public.v_persona_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_persona(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona(id_persona_arg integer) RETURNS SETOF v_persona_all
    AS $_$ 
 select *
 from public.v_persona_all
 where id_persona = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_persona(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona(id_persona_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_persona_all
    AS $_$ 
 select *
 from public.v_persona_all
 where id_persona = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_persona(integer, character varying, character varying, bigint, character varying, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona(id_persona_arg integer, nombre_arg character varying, apellido_arg character varying, cuip_arg bigint, otro_arg character varying, mail_arg character varying, foto_arg character varying, obsoleto_arg boolean) RETURNS SETOF v_persona_all
    AS $$ 
begin
 return query
 select *
 from public.v_persona_all
 where 
(id_persona = id_persona_arg or id_persona_arg is null) and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(apellido::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((apellido_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(cuip = cuip_arg or cuip_arg is null) and 
translate(coalesce(otro::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((otro_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(mail::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((mail_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(foto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((foto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_persona(integer, character varying, character varying, bigint, character varying, character varying, character varying, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_persona(id_persona_arg integer, nombre_arg character varying, apellido_arg character varying, cuip_arg bigint, otro_arg character varying, mail_arg character varying, foto_arg character varying, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_persona_all
    AS $$ 
begin
 return query
 select *
 from public.v_persona_all
 where 
(id_persona = id_persona_arg or id_persona_arg is null) and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(apellido::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((apellido_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(cuip = cuip_arg or cuip_arg is null) and 
translate(coalesce(otro::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((otro_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(mail::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((mail_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(foto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((foto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_racion(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion() RETURNS SETOF v_racion_all
    AS $$ 
 select *
 from public.v_racion_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_racion(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion(lim_arg integer, off_arg integer) RETURNS SETOF v_racion_all
    AS $_$ 
 select *
 from public.v_racion_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_racion(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion(id_racion_arg integer) RETURNS SETOF v_racion_all
    AS $_$ 
 select *
 from public.v_racion_all
 where id_racion = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_racion(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion(id_racion_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_racion_all
    AS $_$ 
 select *
 from public.v_racion_all
 where id_racion = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_racion(integer, timestamp without time zone, integer, character, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion(id_racion_arg integer, fecha_arg timestamp without time zone, id_cliente_arg integer, tipo_racion_arg character, valor_arg real, obsoleto_arg boolean) RETURNS SETOF v_racion_all
    AS $$ 
begin
 return query
 select *
 from public.v_racion_all
 where 
(id_racion = id_racion_arg or id_racion_arg is null) and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(tipo_racion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_racion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(valor = valor_arg or valor_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_racion(integer, timestamp without time zone, integer, character, real, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_racion(id_racion_arg integer, fecha_arg timestamp without time zone, id_cliente_arg integer, tipo_racion_arg character, valor_arg real, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_racion_all
    AS $$ 
begin
 return query
 select *
 from public.v_racion_all
 where 
(id_racion = id_racion_arg or id_racion_arg is null) and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(tipo_racion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_racion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(valor = valor_arg or valor_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: tipo_cliente; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tipo_cliente (
    id_tipo_cliente integer NOT NULL,
    descripcion character varying(200) NOT NULL,
    tipo_beca character varying(1) DEFAULT 'D'::"char",
    tipo_monto character varying(1) DEFAULT '$'::"char",
    beca real,
    tipo_duracion character varying(1) DEFAULT 'R'::"char",
    tipo_renovacion character varying(1) DEFAULT 'F'::"char",
    renovacion character varying(10),
    max_personas_agregar integer DEFAULT 0,
    obsoleto boolean DEFAULT false,
    CONSTRAINT chk_tipo_beca CHECK (((tipo_beca)::text = ANY ((ARRAY['D'::"char", 'C'::"char"])::text[]))),
    CONSTRAINT chk_tipo_duracion CHECK (((tipo_duracion)::text = ANY ((ARRAY['R'::"char", 'S'::"char", 'F'::"char"])::text[]))),
    CONSTRAINT chk_tipo_monto CHECK (((tipo_monto)::text = ANY ((ARRAY['$'::"char", '%'::"char"])::text[]))),
    CONSTRAINT chk_tipo_renovacion CHECK (((tipo_renovacion)::text = ANY ((ARRAY['F'::"char", 'C'::"char"])::text[])))
);


--
-- Name: v_tipo_cliente_all; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_tipo_cliente_all AS
    SELECT tipo_cliente.id_tipo_cliente, tipo_cliente.descripcion, tipo_cliente.tipo_beca, tipo_cliente.tipo_monto, tipo_cliente.beca, tipo_cliente.tipo_duracion, tipo_cliente.tipo_renovacion, tipo_cliente.renovacion, tipo_cliente.max_personas_agregar, tipo_cliente.obsoleto FROM tipo_cliente;


--
-- Name: fq_tipo_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente() RETURNS SETOF v_tipo_cliente_all
    AS $$ 
 select *
 from public.v_tipo_cliente_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_tipo_cliente(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente(lim_arg integer, off_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $_$ 
 select *
 from public.v_tipo_cliente_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente(id_tipo_cliente_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $_$ 
 select *
 from public.v_tipo_cliente_all
 where id_tipo_cliente = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_tipo_cliente(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente(id_tipo_cliente_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $_$ 
 select *
 from public.v_tipo_cliente_all
 where id_tipo_cliente = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_tipo_cliente(integer, character varying, character varying, character varying, real, character varying, character varying, character varying, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente(id_tipo_cliente_arg integer, descripcion_arg character varying, tipo_beca_arg character varying, tipo_monto_arg character varying, beca_arg real, tipo_duracion_arg character varying, tipo_renovacion_arg character varying, renovacion_arg character varying, max_personas_agregar_arg integer, obsoleto_arg boolean) RETURNS SETOF v_tipo_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_tipo_cliente_all
 where 
(id_tipo_cliente = id_tipo_cliente_arg or id_tipo_cliente_arg is null) and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_beca::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_beca_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_monto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_monto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(beca = beca_arg or beca_arg is null) and 
translate(coalesce(tipo_duracion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_duracion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(max_personas_agregar = max_personas_agregar_arg or max_personas_agregar_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_tipo_cliente(integer, character varying, character varying, character varying, real, character varying, character varying, character varying, integer, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_tipo_cliente(id_tipo_cliente_arg integer, descripcion_arg character varying, tipo_beca_arg character varying, tipo_monto_arg character varying, beca_arg real, tipo_duracion_arg character varying, tipo_renovacion_arg character varying, renovacion_arg character varying, max_personas_agregar_arg integer, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_tipo_cliente_all
 where 
(id_tipo_cliente = id_tipo_cliente_arg or id_tipo_cliente_arg is null) and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_beca::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_beca_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_monto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_monto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(beca = beca_arg or beca_arg is null) and 
translate(coalesce(tipo_duracion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_duracion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(max_personas_agregar = max_personas_agregar_arg or max_personas_agregar_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta() RETURNS SETOF v_venta_all
    AS $$ 
 select *
 from public.v_venta_all; 
$$
    LANGUAGE sql;


--
-- Name: fq_venta(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta(lim_arg integer, off_arg integer) RETURNS SETOF v_venta_all
    AS $_$ 
 select *
 from public.v_venta_all 
 limit $1 offset $2; 
$_$
    LANGUAGE sql;


--
-- Name: fq_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta(id_venta_arg integer) RETURNS SETOF v_venta_all
    AS $_$ 
 select *
 from public.v_venta_all
 where id_venta = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fq_venta(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta(id_venta_arg integer, lim_arg integer, off_arg integer) RETURNS SETOF v_venta_all
    AS $_$ 
 select *
 from public.v_venta_all
 where id_venta = $1 
 limit $2 offset $3; 
$_$
    LANGUAGE sql;


--
-- Name: fq_venta(integer, integer, timestamp without time zone, real, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta(id_venta_arg integer, id_cliente_arg integer, fecha_arg timestamp without time zone, ingreso_arg real, saldo_arg real, obsoleto_arg boolean) RETURNS SETOF v_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_venta_all
 where 
(id_venta = id_venta_arg or id_venta_arg is null) and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(ingreso = ingreso_arg or ingreso_arg is null) and 
(saldo = saldo_arg or saldo_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fq_venta(integer, integer, timestamp without time zone, real, real, boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fq_venta(id_venta_arg integer, id_cliente_arg integer, fecha_arg timestamp without time zone, ingreso_arg real, saldo_arg real, obsoleto_arg boolean, lim_arg integer, off_arg integer) RETURNS SETOF v_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_venta_all
 where 
(id_venta = id_venta_arg or id_venta_arg is null) and 
(id_cliente = id_cliente_arg or id_cliente_arg is null) and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(ingreso = ingreso_arg or ingreso_arg is null) and 
(saldo = saldo_arg or saldo_arg is null) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean)
 limit lim_arg offset off_arg;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqi_cliente(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqi_cliente(id_cliente_644917_arg integer, id_cliente_724263_arg integer, id_cliente_701555_arg integer) RETURNS SETOF v_cliente_all
    AS $$ 
 declare 
 	tmp varchar; 
 	ret record; 
 begin 
 	tmp = 'select t.* from public.fq_cliente() t ';
	if id_cliente_644917_arg is not null then 
		tmp = tmp || ' inner join fq_agregado('||id_cliente_644917_arg||') t1 on t.id_cliente = t1.id_cliente'; 
end if;
	if id_cliente_724263_arg is not null then 
		tmp = tmp || ' inner join fq_racion('||id_cliente_724263_arg||') t2 on t.id_cliente = t2.id_cliente'; 
end if;
	if id_cliente_701555_arg is not null then 
		tmp = tmp || ' inner join fq_venta('||id_cliente_701555_arg||') t3 on t.id_cliente = t3.id_cliente'; 
end if;
 	for ret in
		execute tmp
	loop
		return next ret;
	end loop;
 end; 
$$
    LANGUAGE plpgsql;


--
-- Name: fqi_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqi_evento(id_evento_643387_arg integer) RETURNS SETOF v_evento_all
    AS $$ 
 declare 
 	tmp varchar; 
 	ret record; 
 begin 
 	tmp = 'select t.* from public.fq_evento() t ';
	if id_evento_643387_arg is not null then 
		tmp = tmp || ' inner join fq_cliente('||id_evento_643387_arg||') t1 on t.id_evento = t1.id_evento'; 
end if;
 	for ret in
		execute tmp
	loop
		return next ret;
	end loop;
 end; 
$$
    LANGUAGE plpgsql;


--
-- Name: fqi_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqi_extra(id_extra_701570_arg integer) RETURNS SETOF v_extra_all
    AS $$ 
 declare 
 	tmp varchar; 
 	ret record; 
 begin 
 	tmp = 'select t.* from public.fq_extra() t ';
	if id_extra_701570_arg is not null then 
		tmp = tmp || ' inner join fq_item_venta('||id_extra_701570_arg||') t1 on t.id_extra = t1.id_extra'; 
end if;
 	for ret in
		execute tmp
	loop
		return next ret;
	end loop;
 end; 
$$
    LANGUAGE plpgsql;


--
-- Name: fqi_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqi_tipo_cliente(id_tipo_cliente_643387_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $$ 
 declare 
 	tmp varchar; 
 	ret record; 
 begin 
 	tmp = 'select t.* from public.fq_tipo_cliente() t ';
	if id_tipo_cliente_643387_arg is not null then 
		tmp = tmp || ' inner join fq_cliente('||id_tipo_cliente_643387_arg||') t1 on t.id_tipo_cliente = t1.id_tipo_cliente'; 
end if;
 	for ret in
		execute tmp
	loop
		return next ret;
	end loop;
 end; 
$$
    LANGUAGE plpgsql;


--
-- Name: fqi_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqi_venta(id_venta_701570_arg integer) RETURNS SETOF v_venta_all
    AS $$ 
 declare 
 	tmp varchar; 
 	ret record; 
 begin 
 	tmp = 'select t.* from public.fq_venta() t ';
	if id_venta_701570_arg is not null then 
		tmp = tmp || ' inner join fq_item_venta('||id_venta_701570_arg||') t1 on t.id_venta = t1.id_venta'; 
end if;
 	for ret in
		execute tmp
	loop
		return next ret;
	end loop;
 end; 
$$
    LANGUAGE plpgsql;


--
-- Name: fql_agregado(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_agregado(id_agregado_arg integer) RETURNS SETOF v_agregado_all
    AS $_$ 
 select id_agregado, id_cliente, id_persona, orden, obsoleto, public.ff_cliente (id_cliente) as ff_id_cliente from public.fq_agregado() where id_agregado = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_cliente(id_cliente_arg integer) RETURNS SETOF v_cliente_all
    AS $_$ 
 select id_cliente, codigo, id_persona, id_evento, id_tipo_cliente, beca, renovado, fecha_desde, fecha_hasta, saldo, raciones, obsoleto, public.ff_evento (id_evento) as ff_id_evento, public.ff_tipo_cliente (id_tipo_cliente) as ff_id_tipo_cliente from public.fq_cliente() where id_cliente = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_evento(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_evento(id_evento_arg integer) RETURNS SETOF v_evento_all
    AS $_$ 
 select id_evento, nombre, fecha_desde, fecha_hasta, cantidad, obsoleto from public.fq_evento() where id_evento = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_extra(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_extra(id_extra_arg integer) RETURNS SETOF v_extra_all
    AS $_$ 
 select id_extra, descripcion, codigo, precio_unitario, cantidad, cero_chk, obsoleto from public.fq_extra() where id_extra = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_item_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_item_venta(id_item_venta_arg integer) RETURNS SETOF v_item_venta_all
    AS $_$ 
 select id_item_venta, id_venta, id_extra, cantidad, subtotal, obsoleto, public.ff_venta (id_venta) as ff_id_venta, public.ff_extra (id_extra) as ff_id_extra from public.fq_item_venta() where id_item_venta = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_parametros_generales(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_parametros_generales(id_parametros_generales_arg integer) RETURNS SETOF v_parametros_generales_all
    AS $_$ 
 select id_parametros_generales, precio_x_racion, racion_x_persona, obsoleto from public.fq_parametros_generales() where id_parametros_generales = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_persona(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_persona(id_persona_arg integer) RETURNS SETOF v_persona_all
    AS $_$ 
 select id_persona, nombre, apellido, cuip, otro, mail, foto, obsoleto from public.fq_persona() where id_persona = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_racion(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_racion(id_racion_arg integer) RETURNS SETOF v_racion_all
    AS $_$ 
 select id_racion, fecha, id_cliente, tipo_racion, valor, obsoleto, public.ff_cliente (id_cliente) as ff_id_cliente from public.fq_racion() where id_racion = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_tipo_cliente(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_tipo_cliente(id_tipo_cliente_arg integer) RETURNS SETOF v_tipo_cliente_all
    AS $_$ 
 select id_tipo_cliente, descripcion, tipo_beca, tipo_monto, beca, tipo_duracion, tipo_renovacion, renovacion, max_personas_agregar, obsoleto from public.fq_tipo_cliente() where id_tipo_cliente = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fql_venta(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fql_venta(id_venta_arg integer) RETURNS SETOF v_venta_all
    AS $_$ 
 select id_venta, id_cliente, fecha, ingreso, saldo, obsoleto, public.ff_cliente (id_cliente) as ff_id_cliente from public.fq_venta() where id_venta = $1; 
$_$
    LANGUAGE sql;


--
-- Name: fqr_agregado(integer, integer, integer, integer, integer, integer, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_agregado(id_agregado_arg_desde integer, id_agregado_arg_hasta integer, id_cliente_arg_desde integer, id_cliente_arg_hasta integer, id_persona_arg_desde integer, id_persona_arg_hasta integer, orden_arg_desde integer, orden_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_agregado_all
    AS $$ 
begin
 return query
 select *
 from public.v_agregado_all
 where 
((id_agregado >= id_agregado_arg_desde or id_agregado_arg_desde is null) and  (id_agregado <= id_agregado_arg_hasta or id_agregado_arg_hasta is null))and 
((id_cliente >= id_cliente_arg_desde or id_cliente_arg_desde is null) and  (id_cliente <= id_cliente_arg_hasta or id_cliente_arg_hasta is null))and 
((id_persona >= id_persona_arg_desde or id_persona_arg_desde is null) and  (id_persona <= id_persona_arg_hasta or id_persona_arg_hasta is null))and 
((orden >= orden_arg_desde or orden_arg_desde is null) and  (orden <= orden_arg_hasta or orden_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_cliente(integer, integer, character varying, integer, integer, integer, integer, integer, integer, real, real, date, date, date, date, date, date, real, real, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_cliente(id_cliente_arg_desde integer, id_cliente_arg_hasta integer, codigo_arg character varying, id_persona_arg_desde integer, id_persona_arg_hasta integer, id_evento_arg_desde integer, id_evento_arg_hasta integer, id_tipo_cliente_arg_desde integer, id_tipo_cliente_arg_hasta integer, beca_arg_desde real, beca_arg_hasta real, renovado_arg_desde date, renovado_arg_hasta date, fecha_desde_arg_desde date, fecha_desde_arg_hasta date, fecha_hasta_arg_desde date, fecha_hasta_arg_hasta date, saldo_arg_desde real, saldo_arg_hasta real, raciones_arg_desde integer, raciones_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_cliente_all
 where 
((id_cliente >= id_cliente_arg_desde or id_cliente_arg_desde is null) and  (id_cliente <= id_cliente_arg_hasta or id_cliente_arg_hasta is null))and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((id_persona >= id_persona_arg_desde or id_persona_arg_desde is null) and  (id_persona <= id_persona_arg_hasta or id_persona_arg_hasta is null))and 
((id_evento >= id_evento_arg_desde or id_evento_arg_desde is null) and  (id_evento <= id_evento_arg_hasta or id_evento_arg_hasta is null))and 
((id_tipo_cliente >= id_tipo_cliente_arg_desde or id_tipo_cliente_arg_desde is null) and  (id_tipo_cliente <= id_tipo_cliente_arg_hasta or id_tipo_cliente_arg_hasta is null))and 
((beca >= beca_arg_desde or beca_arg_desde is null) and  (beca <= beca_arg_hasta or beca_arg_hasta is null))and 
((renovado >= renovado_arg_desde or renovado_arg_desde is null) and  (renovado <= renovado_arg_hasta or renovado_arg_hasta is null))and 
((fecha_desde >= fecha_desde_arg_desde or fecha_desde_arg_desde is null) and  (fecha_desde <= fecha_desde_arg_hasta or fecha_desde_arg_hasta is null))and 
((fecha_hasta >= fecha_hasta_arg_desde or fecha_hasta_arg_desde is null) and  (fecha_hasta <= fecha_hasta_arg_hasta or fecha_hasta_arg_hasta is null))and 
((saldo >= saldo_arg_desde or saldo_arg_desde is null) and  (saldo <= saldo_arg_hasta or saldo_arg_hasta is null))and 
((raciones >= raciones_arg_desde or raciones_arg_desde is null) and  (raciones <= raciones_arg_hasta or raciones_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_evento(integer, integer, character varying, date, date, date, date, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_evento(id_evento_arg_desde integer, id_evento_arg_hasta integer, nombre_arg character varying, fecha_desde_arg_desde date, fecha_desde_arg_hasta date, fecha_hasta_arg_desde date, fecha_hasta_arg_hasta date, cantidad_arg_desde integer, cantidad_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_evento_all
    AS $$ 
begin
 return query
 select *
 from public.v_evento_all
 where 
((id_evento >= id_evento_arg_desde or id_evento_arg_desde is null) and  (id_evento <= id_evento_arg_hasta or id_evento_arg_hasta is null))and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((fecha_desde >= fecha_desde_arg_desde or fecha_desde_arg_desde is null) and  (fecha_desde <= fecha_desde_arg_hasta or fecha_desde_arg_hasta is null))and 
((fecha_hasta >= fecha_hasta_arg_desde or fecha_hasta_arg_desde is null) and  (fecha_hasta <= fecha_hasta_arg_hasta or fecha_hasta_arg_hasta is null))and 
((cantidad >= cantidad_arg_desde or cantidad_arg_desde is null) and  (cantidad <= cantidad_arg_hasta or cantidad_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_extra(integer, integer, character varying, character varying, real, real, integer, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_extra(id_extra_arg_desde integer, id_extra_arg_hasta integer, descripcion_arg character varying, codigo_arg character varying, precio_unitario_arg_desde real, precio_unitario_arg_hasta real, cantidad_arg_desde integer, cantidad_arg_hasta integer, cero_chk_arg boolean, obsoleto_arg boolean) RETURNS SETOF v_extra_all
    AS $$ 
begin
 return query
 select *
 from public.v_extra_all
 where 
((id_extra >= id_extra_arg_desde or id_extra_arg_desde is null) and  (id_extra <= id_extra_arg_hasta or id_extra_arg_hasta is null))and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(codigo::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((codigo_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((precio_unitario >= precio_unitario_arg_desde or precio_unitario_arg_desde is null) and  (precio_unitario <= precio_unitario_arg_hasta or precio_unitario_arg_hasta is null))and 
((cantidad >= cantidad_arg_desde or cantidad_arg_desde is null) and  (cantidad <= cantidad_arg_hasta or cantidad_arg_hasta is null))and 
(cero_chk_arg is null or cero_chk::boolean = cero_chk_arg::boolean) and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_item_venta(integer, integer, integer, integer, integer, integer, integer, integer, real, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_item_venta(id_item_venta_arg_desde integer, id_item_venta_arg_hasta integer, id_venta_arg_desde integer, id_venta_arg_hasta integer, id_extra_arg_desde integer, id_extra_arg_hasta integer, cantidad_arg_desde integer, cantidad_arg_hasta integer, subtotal_arg_desde real, subtotal_arg_hasta real, obsoleto_arg boolean) RETURNS SETOF v_item_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_item_venta_all
 where 
((id_item_venta >= id_item_venta_arg_desde or id_item_venta_arg_desde is null) and  (id_item_venta <= id_item_venta_arg_hasta or id_item_venta_arg_hasta is null))and 
((id_venta >= id_venta_arg_desde or id_venta_arg_desde is null) and  (id_venta <= id_venta_arg_hasta or id_venta_arg_hasta is null))and 
((id_extra >= id_extra_arg_desde or id_extra_arg_desde is null) and  (id_extra <= id_extra_arg_hasta or id_extra_arg_hasta is null))and 
((cantidad >= cantidad_arg_desde or cantidad_arg_desde is null) and  (cantidad <= cantidad_arg_hasta or cantidad_arg_hasta is null))and 
((subtotal >= subtotal_arg_desde or subtotal_arg_desde is null) and  (subtotal <= subtotal_arg_hasta or subtotal_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_parametros_generales(integer, integer, real, real, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_parametros_generales(id_parametros_generales_arg_desde integer, id_parametros_generales_arg_hasta integer, precio_x_racion_arg_desde real, precio_x_racion_arg_hasta real, racion_x_persona_arg_desde integer, racion_x_persona_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_parametros_generales_all
    AS $$ 
begin
 return query
 select *
 from public.v_parametros_generales_all
 where 
((id_parametros_generales >= id_parametros_generales_arg_desde or id_parametros_generales_arg_desde is null) and  (id_parametros_generales <= id_parametros_generales_arg_hasta or id_parametros_generales_arg_hasta is null))and 
((precio_x_racion >= precio_x_racion_arg_desde or precio_x_racion_arg_desde is null) and  (precio_x_racion <= precio_x_racion_arg_hasta or precio_x_racion_arg_hasta is null))and 
((racion_x_persona >= racion_x_persona_arg_desde or racion_x_persona_arg_desde is null) and  (racion_x_persona <= racion_x_persona_arg_hasta or racion_x_persona_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_persona(integer, integer, character varying, character varying, bigint, bigint, character varying, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_persona(id_persona_arg_desde integer, id_persona_arg_hasta integer, nombre_arg character varying, apellido_arg character varying, cuip_arg_desde bigint, cuip_arg_hasta bigint, otro_arg character varying, mail_arg character varying, foto_arg character varying, obsoleto_arg boolean) RETURNS SETOF v_persona_all
    AS $$ 
begin
 return query
 select *
 from public.v_persona_all
 where 
((id_persona >= id_persona_arg_desde or id_persona_arg_desde is null) and  (id_persona <= id_persona_arg_hasta or id_persona_arg_hasta is null))and 
translate(coalesce(nombre::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((nombre_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(apellido::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((apellido_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((cuip >= cuip_arg_desde or cuip_arg_desde is null) and  (cuip <= cuip_arg_hasta or cuip_arg_hasta is null))and 
translate(coalesce(otro::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((otro_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(mail::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((mail_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(foto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((foto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_racion(integer, integer, timestamp without time zone, integer, integer, character, real, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_racion(id_racion_arg_desde integer, id_racion_arg_hasta integer, fecha_arg timestamp without time zone, id_cliente_arg_desde integer, id_cliente_arg_hasta integer, tipo_racion_arg character, valor_arg_desde real, valor_arg_hasta real, obsoleto_arg boolean) RETURNS SETOF v_racion_all
    AS $$ 
begin
 return query
 select *
 from public.v_racion_all
 where 
((id_racion >= id_racion_arg_desde or id_racion_arg_desde is null) and  (id_racion <= id_racion_arg_hasta or id_racion_arg_hasta is null))and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((id_cliente >= id_cliente_arg_desde or id_cliente_arg_desde is null) and  (id_cliente <= id_cliente_arg_hasta or id_cliente_arg_hasta is null))and 
translate(coalesce(tipo_racion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_racion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((valor >= valor_arg_desde or valor_arg_desde is null) and  (valor <= valor_arg_hasta or valor_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_tipo_cliente(integer, integer, character varying, character varying, character varying, real, real, character varying, character varying, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_tipo_cliente(id_tipo_cliente_arg_desde integer, id_tipo_cliente_arg_hasta integer, descripcion_arg character varying, tipo_beca_arg character varying, tipo_monto_arg character varying, beca_arg_desde real, beca_arg_hasta real, tipo_duracion_arg character varying, tipo_renovacion_arg character varying, renovacion_arg character varying, max_personas_agregar_arg_desde integer, max_personas_agregar_arg_hasta integer, obsoleto_arg boolean) RETURNS SETOF v_tipo_cliente_all
    AS $$ 
begin
 return query
 select *
 from public.v_tipo_cliente_all
 where 
((id_tipo_cliente >= id_tipo_cliente_arg_desde or id_tipo_cliente_arg_desde is null) and  (id_tipo_cliente <= id_tipo_cliente_arg_hasta or id_tipo_cliente_arg_hasta is null))and 
translate(coalesce(descripcion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((descripcion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_beca::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_beca_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_monto::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_monto_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((beca >= beca_arg_desde or beca_arg_desde is null) and  (beca <= beca_arg_hasta or beca_arg_hasta is null))and 
translate(coalesce(tipo_duracion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_duracion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(tipo_renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((tipo_renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
translate(coalesce(renovacion::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((renovacion_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((max_personas_agregar >= max_personas_agregar_arg_desde or max_personas_agregar_arg_desde is null) and  (max_personas_agregar <= max_personas_agregar_arg_hasta or max_personas_agregar_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fqr_venta(integer, integer, integer, integer, timestamp without time zone, real, real, real, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fqr_venta(id_venta_arg_desde integer, id_venta_arg_hasta integer, id_cliente_arg_desde integer, id_cliente_arg_hasta integer, fecha_arg timestamp without time zone, ingreso_arg_desde real, ingreso_arg_hasta real, saldo_arg_desde real, saldo_arg_hasta real, obsoleto_arg boolean) RETURNS SETOF v_venta_all
    AS $$ 
begin
 return query
 select *
 from public.v_venta_all
 where 
((id_venta >= id_venta_arg_desde or id_venta_arg_desde is null) and  (id_venta <= id_venta_arg_hasta or id_venta_arg_hasta is null))and 
((id_cliente >= id_cliente_arg_desde or id_cliente_arg_desde is null) and  (id_cliente <= id_cliente_arg_hasta or id_cliente_arg_hasta is null))and 
translate(coalesce(fecha::varchar, ''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN') ilike '%'||translate(coalesce((fecha_arg)::varchar,''),'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ','aeiouAEIOUaeiouAEIOUnN')||'%' and 
((ingreso >= ingreso_arg_desde or ingreso_arg_desde is null) and  (ingreso <= ingreso_arg_hasta or ingreso_arg_hasta is null))and 
((saldo >= saldo_arg_desde or saldo_arg_desde is null) and  (saldo <= saldo_arg_hasta or saldo_arg_hasta is null))and 
(obsoleto_arg is null or obsoleto::boolean = obsoleto_arg::boolean); 
end;
$$
    LANGUAGE plpgsql;


--
-- Name: fs_agregado(integer, integer, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_agregado(id_agregado_arg integer, id_cliente_arg integer, id_persona_arg integer, orden_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.agregado (id_cliente, id_persona, orden, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_agregado)
      		from	public.v_agregado;
  	else 
      		update   public.agregado
      		set	id_cliente = $2, 
			id_persona = $3, 
			orden = $4, 
			obsoleto = $5
      		where	id_agregado = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.agregado no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_cliente(integer, character varying, integer, integer, integer, real, date, date, date, real, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_cliente(id_cliente_arg integer, codigo_arg character varying, id_persona_arg integer, id_evento_arg integer, id_tipo_cliente_arg integer, beca_arg real, renovado_arg date, fecha_desde_arg date, fecha_hasta_arg date, saldo_arg real, raciones_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.cliente (codigo, id_persona, id_evento, id_tipo_cliente, beca, renovado, fecha_desde, fecha_hasta, saldo, raciones, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6, 
		$7, 
		$8, 
		$9, 
		$10, 
		$11, 
		$12); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_cliente)
      		from	public.v_cliente;
  	else 
      		update   public.cliente
      		set	codigo = $2, 
			id_persona = $3, 
			id_evento = $4, 
			id_tipo_cliente = $5, 
			beca = $6, 
			renovado = $7, 
			fecha_desde = $8, 
			fecha_hasta = $9, 
			saldo = $10, 
			raciones = $11, 
			obsoleto = $12
      		where	id_cliente = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.cliente no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_evento(integer, character varying, date, date, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_evento(id_evento_arg integer, nombre_arg character varying, fecha_desde_arg date, fecha_hasta_arg date, cantidad_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.evento (nombre, fecha_desde, fecha_hasta, cantidad, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_evento)
      		from	public.v_evento;
  	else 
      		update   public.evento
      		set	nombre = $2, 
			fecha_desde = $3, 
			fecha_hasta = $4, 
			cantidad = $5, 
			obsoleto = $6
      		where	id_evento = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.evento no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_extra(integer, character varying, character varying, real, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_extra(id_extra_arg integer, descripcion_arg character varying, codigo_arg character varying, precio_unitario_arg real, cantidad_arg integer, cero_chk_arg boolean, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.extra (descripcion, codigo, precio_unitario, cantidad, cero_chk, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6, 
		$7); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_extra)
      		from	public.v_extra;
  	else 
      		update   public.extra
      		set	descripcion = $2, 
			codigo = $3, 
			precio_unitario = $4, 
			cantidad = $5, 
			cero_chk = $6, 
			obsoleto = $7
      		where	id_extra = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.extra no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_item_venta(integer, integer, integer, integer, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_item_venta(id_item_venta_arg integer, id_venta_arg integer, id_extra_arg integer, cantidad_arg integer, subtotal_arg real, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.item_venta (id_venta, id_extra, cantidad, subtotal, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_item_venta)
      		from	public.v_item_venta;
  	else 
      		update   public.item_venta
      		set	id_venta = $2, 
			id_extra = $3, 
			cantidad = $4, 
			subtotal = $5, 
			obsoleto = $6
      		where	id_item_venta = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.item_venta no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_parametros_generales(integer, real, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_parametros_generales(id_parametros_generales_arg integer, precio_x_racion_arg real, racion_x_persona_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.parametros_generales (id_parametros_generales, precio_x_racion, racion_x_persona, obsoleto) 
      		values ($1, 
		$2, 
		$3, 
		$4); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_parametros_generales)
      		from	public.v_parametros_generales;
  	else 
      		update   public.parametros_generales
      		set	precio_x_racion = $2, 
			racion_x_persona = $3, 
			obsoleto = $4
      		where	id_parametros_generales = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.parametros_generales no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_persona(integer, character varying, character varying, bigint, character varying, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_persona(id_persona_arg integer, nombre_arg character varying, apellido_arg character varying, cuip_arg bigint, otro_arg character varying, mail_arg character varying, foto_arg character varying, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.persona (nombre, apellido, cuip, otro, mail, foto, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6, 
		$7, 
		$8); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_persona)
      		from	public.v_persona;
  	else 
      		update   public.persona
      		set	nombre = $2, 
			apellido = $3, 
			cuip = $4, 
			otro = $5, 
			mail = $6, 
			foto = $7, 
			obsoleto = $8
      		where	id_persona = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.persona no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_racion(integer, timestamp without time zone, integer, character, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_racion(id_racion_arg integer, fecha_arg timestamp without time zone, id_cliente_arg integer, tipo_racion_arg character, valor_arg real, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.racion (fecha, id_cliente, tipo_racion, valor, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_racion)
      		from	public.v_racion;
  	else 
      		update   public.racion
      		set	fecha = $2, 
			id_cliente = $3, 
			tipo_racion = $4, 
			valor = $5, 
			obsoleto = $6
      		where	id_racion = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.racion no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_tipo_cliente(integer, character varying, character varying, character varying, real, character varying, character varying, character varying, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_tipo_cliente(id_tipo_cliente_arg integer, descripcion_arg character varying, tipo_beca_arg character varying, tipo_monto_arg character varying, beca_arg real, tipo_duracion_arg character varying, tipo_renovacion_arg character varying, renovacion_arg character varying, max_personas_agregar_arg integer, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.tipo_cliente (descripcion, tipo_beca, tipo_monto, beca, tipo_duracion, tipo_renovacion, renovacion, max_personas_agregar, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6, 
		$7, 
		$8, 
		$9, 
		$10); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_tipo_cliente)
      		from	public.v_tipo_cliente;
  	else 
      		update   public.tipo_cliente
      		set	descripcion = $2, 
			tipo_beca = $3, 
			tipo_monto = $4, 
			beca = $5, 
			tipo_duracion = $6, 
			tipo_renovacion = $7, 
			renovacion = $8, 
			max_personas_agregar = $9, 
			obsoleto = $10
      		where	id_tipo_cliente = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.tipo_cliente no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: fs_venta(integer, integer, timestamp without time zone, real, real, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION fs_venta(id_venta_arg integer, id_cliente_arg integer, fecha_arg timestamp without time zone, ingreso_arg real, saldo_arg real, obsoleto_arg boolean) RETURNS integer
    AS $_$ 
 declare 
   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;
 begin 
 	if $1 is null then 
      		insert into public.venta (id_cliente, fecha, ingreso, saldo, obsoleto) 
      		values ($2, 
		$3, 
		$4, 
		$5, 
		$6); 
      		get diagnostics rowc = row_count;
      		select into retorno max(id_venta)
      		from	public.v_venta;
  	else 
      		update   public.venta
      		set	id_cliente = $2, 
			fecha = $3, 
			ingreso = $4, 
			saldo = $5, 
			obsoleto = $6
      		where	id_venta = $1;
      		get diagnostics rowc = row_count;
      		retorno = $1;
  	end if; 
  	if rowc <= 0 then 
  		RAISE EXCEPTION 'En la entidad public.venta no se pudo guardar.';
  	end if;
  return retorno;
end;
$_$
    LANGUAGE plpgsql;


--
-- Name: ftg_agregado(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_agregado() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.agregado',new.id_agregado,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.agregado',new.id_agregado,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_cliente() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.cliente',new.id_cliente,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.cliente',new.id_cliente,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_evento(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_evento() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.evento',new.id_evento,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.evento',new.id_evento,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_extra(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_extra() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.extra',new.id_extra,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.extra',new.id_extra,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_item_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_item_venta() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.item_venta',new.id_item_venta,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.item_venta',new.id_item_venta,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_parametros_generales(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_parametros_generales() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.parametros_generales',new.id_parametros_generales,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.parametros_generales',new.id_parametros_generales,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_persona(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_persona() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.persona',new.id_persona,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.persona',new.id_persona,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_racion(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_racion() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.racion',new.id_racion,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.racion',new.id_racion,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_tipo_cliente(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_tipo_cliente() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.tipo_cliente',new.id_tipo_cliente,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.tipo_cliente',new.id_tipo_cliente,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


--
-- Name: ftg_venta(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION ftg_venta() RETURNS trigger
    AS $$ 
begin
   if (tg_op = 'UPDATE') then
   	if old.obsoleto != new.obsoleto then
   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) 
   		values ('public.venta',new.id_venta,'obsoleto',new.obsoleto,user,now());
   	end if;
   elsif (tg_op = 'INSERT') then
   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) 
   	values ('public.venta',new.id_venta,true,user,now());
   end if;
   return new;
end;
$$
    LANGUAGE plpgsql;


SET search_path = anthill, pg_catalog;

--
-- Name: ce_adhoc_id_ce_adhoc_seq; Type: SEQUENCE; Schema: anthill; Owner: -
--

CREATE SEQUENCE ce_adhoc_id_ce_adhoc_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: ce_adhoc_id_ce_adhoc_seq; Type: SEQUENCE OWNED BY; Schema: anthill; Owner: -
--

ALTER SEQUENCE ce_adhoc_id_ce_adhoc_seq OWNED BY ce_adhoc.id_ce_adhoc;


--
-- Name: ce_auditoria_id_ce_auditoria_seq; Type: SEQUENCE; Schema: anthill; Owner: -
--

CREATE SEQUENCE ce_auditoria_id_ce_auditoria_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: ce_auditoria_id_ce_auditoria_seq; Type: SEQUENCE OWNED BY; Schema: anthill; Owner: -
--

ALTER SEQUENCE ce_auditoria_id_ce_auditoria_seq OWNED BY ce_auditoria.id_ce_auditoria;


--
-- Name: v_ce_adhoc; Type: VIEW; Schema: anthill; Owner: -
--

CREATE VIEW v_ce_adhoc AS
    SELECT v_ce_adhoc_all.id_ce_adhoc, v_ce_adhoc_all.ejecutar, v_ce_adhoc_all.orden, v_ce_adhoc_all.obsoleto FROM v_ce_adhoc_all WHERE (COALESCE(v_ce_adhoc_all.obsoleto, false) = false);


--
-- Name: v_ce_auditoria; Type: VIEW; Schema: anthill; Owner: -
--

CREATE VIEW v_ce_auditoria AS
    SELECT v_ce_auditoria_all.id_ce_auditoria, v_ce_auditoria_all.entidad, v_ce_auditoria_all.id, v_ce_auditoria_all.nueva_fila, v_ce_auditoria_all.atributo, v_ce_auditoria_all.valor, v_ce_auditoria_all.usuario, v_ce_auditoria_all.fecha, v_ce_auditoria_all.obsoleto FROM v_ce_auditoria_all WHERE (COALESCE(v_ce_auditoria_all.obsoleto, false) = false);


SET search_path = public, pg_catalog;

--
-- Name: agregado_id_agregado_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE agregado_id_agregado_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: agregado_id_agregado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE agregado_id_agregado_seq OWNED BY agregado.id_agregado;


--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cliente_id_cliente_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cliente_id_cliente_seq OWNED BY cliente.id_cliente;


--
-- Name: evento_id_evento_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE evento_id_evento_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: evento_id_evento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE evento_id_evento_seq OWNED BY evento.id_evento;


--
-- Name: extra_id_extra_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE extra_id_extra_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: extra_id_extra_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE extra_id_extra_seq OWNED BY extra.id_extra;


--
-- Name: item_venta_id_item_venta_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE item_venta_id_item_venta_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: item_venta_id_item_venta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE item_venta_id_item_venta_seq OWNED BY item_venta.id_item_venta;


--
-- Name: parametros_generales_id_parametros_generales_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE parametros_generales_id_parametros_generales_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: parametros_generales_id_parametros_generales_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE parametros_generales_id_parametros_generales_seq OWNED BY parametros_generales.id_parametros_generales;


--
-- Name: persona_id_persona_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE persona_id_persona_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: persona_id_persona_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE persona_id_persona_seq OWNED BY persona.id_persona;


--
-- Name: racion_id_racion_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE racion_id_racion_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: racion_id_racion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE racion_id_racion_seq OWNED BY racion.id_racion;


--
-- Name: tipo_cliente_id_tipo_cliente_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tipo_cliente_id_tipo_cliente_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: tipo_cliente_id_tipo_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tipo_cliente_id_tipo_cliente_seq OWNED BY tipo_cliente.id_tipo_cliente;


--
-- Name: v_evento; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_evento AS
    SELECT v_evento_all.id_evento, v_evento_all.nombre, v_evento_all.fecha_desde, v_evento_all.fecha_hasta, v_evento_all.cantidad, v_evento_all.obsoleto FROM v_evento_all WHERE (COALESCE(v_evento_all.obsoleto, false) = false);


--
-- Name: v_extra; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_extra AS
    SELECT v_extra_all.id_extra, v_extra_all.descripcion, v_extra_all.codigo, v_extra_all.precio_unitario, v_extra_all.cantidad, v_extra_all.cero_chk, v_extra_all.obsoleto FROM v_extra_all WHERE (COALESCE(v_extra_all.obsoleto, false) = false);


--
-- Name: v_parametros_generales; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_parametros_generales AS
    SELECT v_parametros_generales_all.id_parametros_generales, v_parametros_generales_all.precio_x_racion, v_parametros_generales_all.racion_x_persona, v_parametros_generales_all.obsoleto FROM v_parametros_generales_all WHERE (COALESCE(v_parametros_generales_all.obsoleto, false) = false);


--
-- Name: v_persona; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_persona AS
    SELECT v_persona_all.id_persona, v_persona_all.nombre, v_persona_all.apellido, v_persona_all.cuip, v_persona_all.otro, v_persona_all.mail, v_persona_all.foto, v_persona_all.obsoleto FROM v_persona_all WHERE (COALESCE(v_persona_all.obsoleto, false) = false);


--
-- Name: v_tipo_cliente; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW v_tipo_cliente AS
    SELECT v_tipo_cliente_all.id_tipo_cliente, v_tipo_cliente_all.descripcion, v_tipo_cliente_all.tipo_beca, v_tipo_cliente_all.tipo_monto, v_tipo_cliente_all.beca, v_tipo_cliente_all.tipo_duracion, v_tipo_cliente_all.tipo_renovacion, v_tipo_cliente_all.renovacion, v_tipo_cliente_all.max_personas_agregar, v_tipo_cliente_all.obsoleto FROM v_tipo_cliente_all WHERE (COALESCE(v_tipo_cliente_all.obsoleto, false) = false);


--
-- Name: venta_id_venta_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE venta_id_venta_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: venta_id_venta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE venta_id_venta_seq OWNED BY venta.id_venta;


SET search_path = anthill, pg_catalog;

--
-- Name: id_ce_adhoc; Type: DEFAULT; Schema: anthill; Owner: -
--

ALTER TABLE ce_adhoc ALTER COLUMN id_ce_adhoc SET DEFAULT nextval('ce_adhoc_id_ce_adhoc_seq'::regclass);


--
-- Name: id_ce_auditoria; Type: DEFAULT; Schema: anthill; Owner: -
--

ALTER TABLE ce_auditoria ALTER COLUMN id_ce_auditoria SET DEFAULT nextval('ce_auditoria_id_ce_auditoria_seq'::regclass);


SET search_path = public, pg_catalog;

--
-- Name: id_agregado; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE agregado ALTER COLUMN id_agregado SET DEFAULT nextval('agregado_id_agregado_seq'::regclass);


--
-- Name: id_cliente; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE cliente ALTER COLUMN id_cliente SET DEFAULT nextval('cliente_id_cliente_seq'::regclass);


--
-- Name: id_evento; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE evento ALTER COLUMN id_evento SET DEFAULT nextval('evento_id_evento_seq'::regclass);


--
-- Name: id_extra; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE extra ALTER COLUMN id_extra SET DEFAULT nextval('extra_id_extra_seq'::regclass);


--
-- Name: id_item_venta; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE item_venta ALTER COLUMN id_item_venta SET DEFAULT nextval('item_venta_id_item_venta_seq'::regclass);


--
-- Name: id_parametros_generales; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE parametros_generales ALTER COLUMN id_parametros_generales SET DEFAULT nextval('parametros_generales_id_parametros_generales_seq'::regclass);


--
-- Name: id_persona; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE persona ALTER COLUMN id_persona SET DEFAULT nextval('persona_id_persona_seq'::regclass);


--
-- Name: id_racion; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE racion ALTER COLUMN id_racion SET DEFAULT nextval('racion_id_racion_seq'::regclass);


--
-- Name: id_tipo_cliente; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE tipo_cliente ALTER COLUMN id_tipo_cliente SET DEFAULT nextval('tipo_cliente_id_tipo_cliente_seq'::regclass);


--
-- Name: id_venta; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE venta ALTER COLUMN id_venta SET DEFAULT nextval('venta_id_venta_seq'::regclass);


SET search_path = anthill, pg_catalog;

--
-- Name: ce_adhoc_ejecutar_key; Type: CONSTRAINT; Schema: anthill; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ce_adhoc
    ADD CONSTRAINT ce_adhoc_ejecutar_key UNIQUE (ejecutar);


--
-- Name: ce_adhoc_pkey; Type: CONSTRAINT; Schema: anthill; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ce_adhoc
    ADD CONSTRAINT ce_adhoc_pkey PRIMARY KEY (id_ce_adhoc);


--
-- Name: ce_auditoria_pkey; Type: CONSTRAINT; Schema: anthill; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ce_auditoria
    ADD CONSTRAINT ce_auditoria_pkey PRIMARY KEY (id_ce_auditoria);


SET search_path = public, pg_catalog;

--
-- Name: pk_cliente; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT pk_cliente PRIMARY KEY (id_cliente);


--
-- Name: pk_extras; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY extra
    ADD CONSTRAINT pk_extras PRIMARY KEY (id_extra);


--
-- Name: pk_hijo_cliente; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY agregado
    ADD CONSTRAINT pk_hijo_cliente PRIMARY KEY (id_agregado);


--
-- Name: pk_id_evento; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY evento
    ADD CONSTRAINT pk_id_evento PRIMARY KEY (id_evento);


--
-- Name: pk_id_persona; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY persona
    ADD CONSTRAINT pk_id_persona PRIMARY KEY (id_persona);


--
-- Name: pk_item_venta; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item_venta
    ADD CONSTRAINT pk_item_venta PRIMARY KEY (id_item_venta);


--
-- Name: pk_parametros_generales; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY parametros_generales
    ADD CONSTRAINT pk_parametros_generales PRIMARY KEY (id_parametros_generales);


--
-- Name: pk_racion; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY racion
    ADD CONSTRAINT pk_racion PRIMARY KEY (id_racion);


--
-- Name: pk_tipo_cliente; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tipo_cliente
    ADD CONSTRAINT pk_tipo_cliente PRIMARY KEY (id_tipo_cliente);


--
-- Name: pk_venta; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY venta
    ADD CONSTRAINT pk_venta PRIMARY KEY (id_venta);


SET search_path = anthill, pg_catalog;

--
-- Name: tiu_anthill_ce_adhoc; Type: TRIGGER; Schema: anthill; Owner: -
--

CREATE TRIGGER tiu_anthill_ce_adhoc
    BEFORE INSERT OR UPDATE ON ce_adhoc
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_ce_adhoc();


SET search_path = public, pg_catalog;

--
-- Name: tiu_public_agregado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_agregado
    BEFORE INSERT OR UPDATE ON agregado
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_agregado();


--
-- Name: tiu_public_cliente; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_cliente
    BEFORE INSERT OR UPDATE ON cliente
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_cliente();


--
-- Name: tiu_public_evento; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_evento
    BEFORE INSERT OR UPDATE ON evento
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_evento();


--
-- Name: tiu_public_extra; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_extra
    BEFORE INSERT OR UPDATE ON extra
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_extra();


--
-- Name: tiu_public_item_venta; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_item_venta
    BEFORE INSERT OR UPDATE ON item_venta
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_item_venta();


--
-- Name: tiu_public_parametros_generales; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_parametros_generales
    BEFORE INSERT OR UPDATE ON parametros_generales
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_parametros_generales();


--
-- Name: tiu_public_persona; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_persona
    BEFORE INSERT OR UPDATE ON persona
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_persona();


--
-- Name: tiu_public_racion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_racion
    BEFORE INSERT OR UPDATE ON racion
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_racion();


--
-- Name: tiu_public_tipo_cliente; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_tipo_cliente
    BEFORE INSERT OR UPDATE ON tipo_cliente
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_tipo_cliente();


--
-- Name: tiu_public_venta; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tiu_public_venta
    BEFORE INSERT OR UPDATE ON venta
    FOR EACH ROW
    EXECUTE PROCEDURE ftg_venta();


--
-- Name: fk_agregado_cliente; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY agregado
    ADD CONSTRAINT fk_agregado_cliente FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);


--
-- Name: fk_cliente_evento; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT fk_cliente_evento FOREIGN KEY (id_evento) REFERENCES evento(id_evento);


--
-- Name: fk_cliente_tipo_cliente; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT fk_cliente_tipo_cliente FOREIGN KEY (id_tipo_cliente) REFERENCES tipo_cliente(id_tipo_cliente);


--
-- Name: fk_item_venta_extra; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_venta
    ADD CONSTRAINT fk_item_venta_extra FOREIGN KEY (id_extra) REFERENCES extra(id_extra);


--
-- Name: fk_item_venta_venta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_venta
    ADD CONSTRAINT fk_item_venta_venta FOREIGN KEY (id_venta) REFERENCES venta(id_venta);


--
-- Name: fk_racion_cliente; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY racion
    ADD CONSTRAINT fk_racion_cliente FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);


--
-- Name: fk_venta_cliente; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY venta
    ADD CONSTRAINT fk_venta_cliente FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);


--
-- PostgreSQL database dump complete
--

