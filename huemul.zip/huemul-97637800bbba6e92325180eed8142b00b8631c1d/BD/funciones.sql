-- Type: asistencia
/*
DROP TYPE asistencia cascade;

CREATE TYPE asistencia AS
   (cuip bigint,
    otro character varying(100),
    nombre character varying(100),
    apellido character varying(100),
    tipo_cliente varchar(200),
    f1 char(1),
    f2 char(1),
    f3 char(1),
    f4 char(1),
    f5 char(1),
    f6 char(1),
    f7 char(1),
    f8 char(1),
    f9 char(1),
    f10 char(1),
    f11 char(1),
    f12 char(1),
    f13 char(1),
    f14 char(1),
    f15 char(1),
    f16 char(1),
    f17 char(1),
    f18 char(1),
    f19 char(1),
    f20 char(1),
    f21 char(1),
    f22 char(1),
    f23 char(1),
    f24 char(1),
    f25 char(1),
    f26 char(1),
    f27 char(1),
    f28 char(1),
    f29 char(1),
    f30 char(1),
    f31 char(1));
--ALTER TYPE asistencia OWNER TO jaspe;

--

--drop function f_asistencia(int, int, int) 

create or replace function f_asistencia (id_tipo_cliente_arg integer, mes integer, anio integer)
returns setof asistencia as
$BODY$
	select * from f_asistencia ($1, $2, $3, null::varchar)
$BODY$
language 'sql';

create or replace function f_asistencia (id_tipo_cliente_arg integer, mes integer, anio integer, buscar varchar)
returns setof asistencia as
$BODY$
declare
	rec record;
	rec2 record;
	dm integer;
	co integer;
	tmp text;
begin
	SELECT date_part('day', 
        (anio::varchar || '-' ||
        mes::varchar || '-01')::date 
                + '1 month'::interval
                - '1 day'::interval) into dm;
                
	for rec in
		select 	p.cuip,
			p.otro,
			p.nombre,
			p.apellido,
			c.id_cliente,
			tc.descripcion
		from	persona p
		inner join
			cliente c
		on	c.id_persona = p.id_persona
		inner join
			tipo_cliente tc
		on	c.id_tipo_cliente = tc.id_tipo_cliente
		where	(c.id_tipo_cliente = id_tipo_cliente_arg
			or id_tipo_cliente_arg is null)
			and (buscar is null
			or p.cuip::varchar ~* buscar
			or p.otro ~* buscar
			or p.nombre ~* buscar
			or p.apellido ~* buscar)
	loop
		co = 1;
		tmp = 	'select '||coalesce(rec.cuip::varchar,'null')||'::bigint, '||
			'	'||quote_literal(coalesce(rec.otro::varchar,''))||'::character varying(100), '||
			'	'||quote_literal(coalesce(rec.nombre::varchar,''))||'::character varying(100), '||
			'	'||quote_literal(coalesce(rec.apellido::varchar,''))||'::character varying(100), '||
			'	'||quote_literal(coalesce(rec.descripcion::varchar,''))||'::character varying(200), ';
		loop
			if co > dm then
				exit;
			end if;
			if exists(select 1 from racion where id_cliente = rec.id_cliente and fecha::date = (anio::varchar||'-'||mes::varchar||'-'||co::varchar)::date) then
				tmp = tmp || '	''t''::char, ';
			elsif date_part('dow', (anio::varchar||'-'||mes::varchar||'-'||co::varchar)::timestamp) = any(ARRAY[0::int, 6::int]) then
				tmp = tmp || '	''n''::char, ';
			else
				tmp = tmp || '	''f''::char, ';
			end if;
			co = co+1;
		end loop;
		loop
			if co > 31 then
				exit;
			end if;
			tmp = tmp || '	''n''::char, ';
			co = co+1;
		end loop;
		tmp = substring(tmp from 1 for char_length(tmp)-2);
		--return next tmp;
		execute tmp into rec2;
		return next rec2;
	end loop;
end;
$BODY$
language 'plpgsql';

--select * from f_asistencia(null, 10, 2010);

-- select * from f_asistencia(6, 10, 2010)

-- select * from f_asistencia(null, 09, 2011)
-- Type: busqueda

-- DROP TYPE busqueda;
/*
CREATE TYPE busqueda AS
   (tipo_codigo integer,
    id_cliente integer,
    id_persona integer,
    nombre character varying(100),
    apellido character varying(100),
    cuip bigint,
    saldo real,
    id_extra integer,
    descripcion character varying(200),
    precio_unitario real,
    cantidad integer);
ALTER TYPE busqueda OWNER TO jaspe;
*/
/*
-- Function: f_buscar(bigint)

-- DROP FUNCTION f_buscar(bigint);

CREATE OR REPLACE FUNCTION f_buscar(codigo varchar)
  RETURNS SETOF busqueda AS
$BODY$ 
select 	*
from	(
	select case when c.id_persona is null and c.id_evento is not null then 3 else 1 end as tipo_codigo,
		c.id_cliente,
		p.id_persona,
		p.nombre,
		p.apellido,
		p.cuip,
		c.saldo,
		null as id_extra,
		null as descripcion,
		null as precio_unitario,
		null as cantidad
	from	fq_cliente(null, $1, null, null, null, null, null, null, null, null, null, false) c
	left join
		fq_persona() p
	on	p.id_persona = c.id_persona
	union
	select	2 as tipo_codigo,
		null,
		null,
		null,
		null,
		null,
		null,
		id_extra,
		descripcion,
		precio_unitario,
		case when cero_chk=false then null else cantidad end as cantidad
	from 	fq_extra(null, null, $1, null, null, null, false)
	where 	cero_chk=false or cantidad > 0
) a
limit 1
$BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100
  ROWS 1000;

*/

drop type paso cascade;
create type paso as (codigo varchar, data varchar, status varchar);



CREATE OR REPLACE FUNCTION f_paso_molinete(codigo_arg character varying, sync boolean, fecha_arg timestamp without time zone)
  RETURNS SETOF paso AS
$BODY$
declare
	id_cliente_var int;
	test_pasadas_var boolean;
	test_duracion_var boolean;
	test_beca_var boolean; 
	tipo_beca_var char(1);
	valor_var real;
	mensaje_var varchar;
begin
	mensaje_var = '';
	select 	c.id_cliente,
		pg.racion_x_persona+(case when a.agr is null then 
			0
		   else
			case when tc.max_personas_agregar > 0 and a.agr > tc.max_personas_agregar then
				tc.max_personas_agregar*pg.racion_x_persona
			else
				a.agr*pg.racion_x_persona
			end
		   end)::int > (select count(*) 
			from 	racion r 
			where 	r.id_cliente = c.id_cliente and 
				date_trunc('day', r.fecha) = date_trunc('day', fecha_arg)
		), --chequeo si ya pasó y la cantidad de veces que puede pasar
		case when tc.tipo_duracion = 'R' then
		  fecha_arg is not null and case when tc.tipo_renovacion = 'F' then
		    case when tc.renovacion ~ '^[0-9][0-9]?/[0-9][0-9]$' then
		      fecha_arg <= (tc.renovacion||'/'||date_part('year', fecha_arg))::date
		    else
		      fecha_arg <= (tc.renovacion||'/'||date_part('month', fecha_arg)||'/'||date_part('year', fecha_arg))::date
		    end
		  else
		    fecha_arg <= (c.renovado + tc.renovacion::interval)::date
		  end
		when tc.tipo_duracion = 'F' and coalesce(c.fecha_desde, e.fecha_desde) is not null and coalesce(c.fecha_hasta, e.fecha_hasta) is not null then
		    fecha_arg is not null and fecha_arg between coalesce(c.fecha_desde, e.fecha_desde) and coalesce(c.fecha_hasta, e.fecha_hasta)			
		else 
		  true
		end, --chequeo si está en una fecha valida
		case when tc.tipo_beca = 'D' then
			c.saldo is not null and case when tc.tipo_monto = '$' then
				c.saldo >=  pg.precio_x_racion - coalesce(c.beca, tc.beca, 0)
			else
				c.saldo >=  pg.precio_x_racion - (pg.precio_x_racion * coalesce(c.beca, tc.beca, 0) / 100)
			end
		else
			c.raciones is not null and coalesce(c.raciones, floor(tc.beca)::int) >= 1
		end, --chequeo que la cantidad de raciones / saldo sea suficiente
		tc.tipo_beca,
		case when tc.tipo_monto = '$' then
			(pg.precio_x_racion - coalesce(c.beca, tc.beca, 0))
		else
			(pg.precio_x_racion - (pg.precio_x_racion * coalesce(c.beca, tc.beca, 0) / 100))
		end
	into 	id_cliente_var,
		test_pasadas_var,
		test_duracion_var,
		test_beca_var,
		tipo_beca_var,
		valor_var
	from 	v_cliente c
	inner join
		v_tipo_cliente tc
	on	c.id_tipo_cliente = tc.id_tipo_cliente
	inner join
		(select *
		from 	v_parametros_generales
		limit 1) pg
	on	1=1
	left join
		(select count(*) as agr,
			id_cliente
		 from 	v_agregado
		 group by id_cliente) a
	on	tc.max_personas_agregar <> 0
		and a.id_cliente = c.id_cliente
	left join
		v_evento e
	on	e.id_evento = c.id_evento
	where	c.codigo = codigo_arg;

	--chequeo si existe el cliente
	if id_cliente_var is null then
		--No es un cliente valido
		if sync then
			return query select null::varchar as codigo, null::varchar as data, 'El cliente no existe'::varchar as status;
		else
			return query select codigo_arg as codigo, 'no_pase'::varchar as data, 'El cliente no existe'::varchar as status;
		end if;
	else
		if not(sync) and not(test_pasadas_var and test_duracion_var and test_beca_var) then
			if not(test_pasadas_var) then
				mensaje_var = mensaje_var||'No puede pasar nuevamente por el día de hoy.'||E'\n';
			end if;
			if not(test_duracion_var) then
				mensaje_var = mensaje_var||'La tarjeta ha expirado.'||E'\n';
			end if;
			if not(test_beca_var) then
				mensaje_var = mensaje_var||'No tiene más raciones/saldo en su cuenta.';
			end if;
			return query select codigo_arg as codigo, 'no_pase'::varchar as data, mensaje_var::varchar as status;
		else
			if tipo_beca_var = 'D' then
				update 	cliente
				set	saldo = saldo - valor_var
				where	id_cliente = id_cliente_var;
			else
				valor_var = 0;
				update 	cliente
				set	raciones = raciones -1
				where	id_cliente = id_cliente_var;
			end if;

			insert into racion (id_cliente, tipo_racion, valor, fecha)
			values	(id_cliente_var, case when tipo_beca_var = 'D' then 'D' else 'R' end, valor_var, fecha_arg);
			
			if sync or fecha_arg::date < current_timestamp::date then
				return query select null::varchar as codigo, null::varchar as data, 'Ok'::varchar as status;
			else
				return query select codigo_arg as codigo, 'pase'::varchar as data, 'Ok'::varchar as status;
			end if;
		end if;
	end if;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000;


create or replace function f_paso_molinete(codigo_arg varchar, sync boolean)
returns setof paso
as
$BODY$
	select * from f_paso_molinete($1, $2, current_timestamp::timestamp);
$BODY$
language 'sql';


select * from f_paso_molinete('d5736b1dda7c89909ac53c609c482eb', false, '2011-09-28'::timestamp);

select * from f_paso_molinete('528b70697d9b4acd4b3099d843eecdb', false)