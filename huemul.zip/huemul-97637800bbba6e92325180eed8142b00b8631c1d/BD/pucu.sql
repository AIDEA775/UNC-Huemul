set search_path to public,pg_catalog;

drop language if exists 'plpgsql' cascade;
create language 'plpgsql';

drop type if exists t_ff cascade; 
CREATE TYPE t_ff AS  (data integer,   "label" character varying);

create or replace function ce_tipo_dato (varchar, varchar) returns varchar as
$BODY$
declare 
	retorno varchar;
	valor varchar;
begin
	if $1 = '' or $1 isnull 
	then
		valor='null::'||$2;
		retorno = valor;
	else
		valor=$1;
		if 	$2 = 'int4' or 
			$2 = 'integer' or 
			$2 = 'boolean' or 
			$2 = 'numeric' 
		then 
			retorno = valor||'::'||$2;
		else
			retorno = ''''||valor||'''::'||$2;
		end if;
	end if;
	return retorno;
end;
$BODY$
LANGUAGE 'plpgsql';

DROP FUNCTION if exists ce_ejecutar(xml);
CREATE OR REPLACE FUNCTION ce_ejecutar(xml)
  RETURNS character varying AS
$BODY$
declare 
	ejecutar varchar;
	tmp xml[];
	td xml[];
	source xml[];
	ignorar xml[];
	valor xml[];
	funciones xml[];
	atributos xml[];
	tmp2 xml[];
	tmp_path text;
	v_view varchar; 
	i int;
	j int;
	ret xml;
	retorno xml;
	mal int;
	v_ignorar varchar;
begin
	ejecutar = '';
	v_ignorar = '  ';
	mal=0;
	funciones = xpath('//funcion',$1);
	i=1;
	WHILE i <= array_upper(funciones,1) LOOP
		tmp=xpath('//funcion/@nombre', funciones[i]);
		ejecutar = 'select * from '||XMLSERIALIZE ( CONTENT tmp[1] as varchar) || '(  ';
		atributos = xpath('//funcion/atributo',funciones[i]);
		j=1;
		WHILE j <= array_upper(atributos,1) LOOP
			td = xpath('//@tipo_dato',atributos[j]);
			source = xpath('//@source',atributos[j]);
			ignorar = xpath('//@ignorar',atributos[j]);
			valor = xpath('//text()',atributos[j]);
			if coalesce(trim(XMLSERIALIZE (CONTENT ignorar[1] as varchar)))='SI' then
				v_ignorar = v_ignorar || j||', ';
			end if;
			if coalesce(trim(XMLSERIALIZE (CONTENT source[1] as varchar)))='SI' then
				tmp_path = '/table[@nombre='''||XMLSERIALIZE (CONTENT valor[1] as varchar)::text||''']/row/'||XMLSERIALIZE (CONTENT valor[1] as varchar)::text||'/text()';
				tmp2 = xpath(tmp_path,retorno);
				--RAISE EXCEPTION 'source si %', tmp2;
				ejecutar = ejecutar || 	ce_tipo_dato(
						coalesce(trim(XMLSERIALIZE (CONTENT tmp2[1] as varchar)),''), 
						coalesce(trim(XMLSERIALIZE (CONTENT    td[1] as varchar)),'')
					   ) || ', ';
			else
				ejecutar = ejecutar || 	ce_tipo_dato(
						coalesce(trim(XMLSERIALIZE (CONTENT valor[1] as varchar)),''), 
						coalesce(trim(XMLSERIALIZE (CONTENT    td[1] as varchar)),'')
					   ) || ', ';
			end if;
			j = j +1;
		END LOOP;
		ejecutar = substring(ejecutar from 1 for char_length(ejecutar) -2);
		if v_ignorar <> '  ' then 
			v_ignorar = substring(v_ignorar from 1 for char_length(v_ignorar) -2);
		end if;


		select  case when XMLSERIALIZE ( CONTENT tmp[1] as varchar) like 'fs_%' then 
				case when v_ignorar <> '  ' then 
					ejecutar || ', array[' || v_ignorar || ']' 
				else 	
					ejecutar || ', null::int[]' 
				end 
			else 	ejecutar
			end
			into 	ejecutar
		;
		--if XMLSERIALIZE ( CONTENT tmp[1] as varchar) = 'fq_concepto' then
			--RAISE EXCEPTION '%', ejecutar;
		--end if;
		ejecutar = ejecutar ||
			')';
		--RAISE EXCEPTION 'actual %', ejecutar;
		begin
			select '<table nombre='''||XMLSERIALIZE ( CONTENT tmp[1] as varchar)||'''>'||query_to_xml(ejecutar,true,true,'')||'</table>' into ret; 
		exception
			when others then 
			begin
				mal=1;
				select '<table  nombre='''||XMLSERIALIZE ( CONTENT tmp[1] as varchar)||'''><error>'||SQLSTATE||':'||SQLERRM||'</error></table>' into ret;
			end;
		end;
		retorno = xmlconcat(retorno,E'\n',ret);
		i=i+1;
	end loop;
	if mal <> 0 then
		RAISE EXCEPTION '%', retorno; 
	end if;
	return ('<resultado>'||retorno||'</resultado>')::xml;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;


create or replace function chk_anthill_sch() returns void as
$$
begin
	if not exists(select 1 from pg_namespace where nspname = 'anthill') then
		create schema anthill;
	end if;

	if not exists(	select 	1 
			from 	pg_class c
			inner join
				pg_namespace n
			on	n.oid = c.relnamespace
			where 	c.relname = 'ce_adhoc'
				and c.relkind = 'r'
				and n.nspname = 'anthill') then
		create table anthill.ce_adhoc (
			id_ce_adhoc serial primary key,
			ejecutar varchar unique,
			orden int, --Agregar de 100 en 100
			obsoleto boolean
		);
	end if;

	if not exists(	select 	1 
			from 	pg_class c
			inner join
				pg_namespace n
			on	n.oid = c.relnamespace
			where 	c.relname = 'ce_auditoria'
				and c.relkind = 'r'
				and n.nspname = 'anthill') then
		create table anthill.ce_auditoria (
			id_ce_auditoria bigserial primary key,
			entidad varchar,
			id int4,
			nueva_fila boolean,
			atributo varchar(255),
			valor varchar(255),
			usuario varchar,
			fecha timestamp,
			obsoleto boolean
		);
	end if;
end;
$$
language 'plpgsql';

select chk_anthill_sch();
drop function chk_anthill_sch();

set search_path to anthill,pg_catalog;


drop type if exists t_ff cascade; 
CREATE TYPE t_ff AS  (data integer,   "label" character varying);

--select ce_get_xml('pulso','public')
create or replace function ce_get_xml(tblname name, sch name)
returns xml as
$BODY$
declare
	tmp varchar;
	dbn name;
	rec record;
	ret xml;
	
begin

	select current_database() into dbn;
	
	select xmlroot(
		xmlelement(
			name "asl:manager", 
			xmlattributes(
				'http://anthill.com.ar/2009/asl' as "xmlns:asl", 
				initcap(replace(tblname, '_', ' ')) as label,
				tblname as name,
				dbn as db
			),
			xmlelement(
				name "asl:external", 
				(
					select 	xmlagg(x)
					from	anthill.ce_get_external_request(tblname, sch) as x
				)
			),
			anthill.ce_get_manager_list(tblname, sch, true)
		), 
		version '1.0', 
		standalone no
	) into ret;

	return ret;
end;
$BODY$
language 'plpgsql';
--select * from ce_get_xml('maquina'::name)
--drop function ce_get_manager_list(tblname name, name, parent boolean)
create or replace function ce_get_manager_list(tblname name, sch name, is_parent boolean)
returns xml as
$BODY$
declare
	ret xml;
	ops varchar;
begin
	select case relkind 
		when 'r' then 
			'true' 
		else 
			'false' 
		end into ops 
	from 	pg_class 
	where 	relname = tblname 
	and 	is_parent = true;
	
	select 	xmlconcat(
			xmlelement(
				name "asl:attributes",
				(
					select 	xmlagg(x)
					from	anthill.ce_get_attribute(tblname, sch) as x
				)
			),
			xmlelement(
				name "asl:children",
				(
				select xmlagg(xmlelement(name "asl:child",xmlattributes('tab' as pos),c2.relname))
				from	pg_class c
				inner join
					pg_namespace n
				on	n.oid = c.relnamespace
				inner join
					pg_constraint co
				on	co.confrelid = c.oid
				inner join
					pg_class c2
				on	co.conrelid = c2.oid
				where	pg_get_userbyid(c.relowner) = current_user
					and c.relname = tblname
					and n.nspname = sch
					and (c.relkind = 'r'::"char" or
						c.relkind = 'v'::"char")
					and c.relnatts > 1
					and co.contype = 'f'
					and is_parent = true
				)
			)
		)
	into ret;
	return ret;
end;
$BODY$
language 'plpgsql';
--drop function ce_get_external_request(tblname name, name,name)
--select ce_get_external_request('pulso','serial')
create or replace function ce_get_external_request(tblname name, sch name)
returns xml as
$BODY$
declare
	rec record;
	rec2 record;
	ret xml;
	tmp varchar;
begin 
	
	for rec in
		select	a.attname, c2.relname
		from	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		inner join
			pg_attribute a
		on a.attrelid = c.oid
		inner join
			pg_constraint co
		on	co.conrelid = c.oid
			and a.attnum = any(co.conkey)
			and co.contype = 'f'
		inner join
			pg_class c2
		on	co.confrelid = c2.oid
		where	pg_get_userbyid(c.relowner) = current_user
			and c.relname = tblname
			and n.nspname = sch
			and (c.relkind = 'r'::"char" or
				c.relkind = 'v'::"char")
			and c.relnatts > 1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = xmlconcat(ret, xmlelement(
			name "asl:request", 
			xmlattributes(
				'ff_'||rec.relname as name,
				'{[form_'||rec.attname||', filtro_'||rec.attname||']}' as targets
			)
		));
	end loop;
	return ret;
end;
$BODY$
language 'plpgsql';

--drop function ce_get_attribute(tblname name)
create or replace function ce_get_attribute(tblname name, sch name)
returns setof xml as
$BODY$
declare
	ret xml;
	tmp varchar;
	rec record;
begin
	for rec in 
		select	a.attname, 
			t.typname, 
			a.attnum, 
			a.attlen,
			a.attnotnull, 
			a.atttypmod,
			co.contype,
			c2.relname,
			a.*
		from	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		inner join
			pg_attribute a
		on a.attrelid = c.oid
		inner join
			pg_type t
		on	t.oid = atttypid
		left join
			pg_constraint co
		on	co.conrelid = c.oid
			and a.attnum = any(co.conkey)
			and co.contype = 'f'
		left join
			pg_class c2
		on	co.confrelid = c2.oid
		where	pg_get_userbyid(c.relowner) = current_user
			and c.relname = tblname
			and n.nspname = sch
			and (c.relkind = 'r'::"char" or
				c.relkind = 'v'::"char")
			and c.relnatts > 1
			and a.attnum > 0
		order by a.attnum
	loop
		tmp = 'select xmlelement(name "asl:attribute", xmlattributes('''|| rec.attname || ''' as name, '''|| initcap(replace(rec.attname, '_', ' ')) || ''' as label, ''true'' as column, ';
		if rec.typname = 'bool' then
			tmp = tmp || '''boolean'' as type';
		elsif rec.typname = 'int4' or rec.typname = 'int2' or rec.typname = 'int8' then
			if rec.contype is not null then
				tmp = tmp || '''integer'' as type, ''si'' as "foranea"';
			else
				tmp = tmp || '''integer'' as type';
			end if;
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;			
		elsif rec.typname = 'float4' or rec.typname = 'float8' then
			tmp = tmp || '''float'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;			
		elsif rec.typname = 'date' or rec.typname = 'time' or rec.typname = 'timestamp' then
			tmp = tmp || '''date'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;
		else
			tmp = tmp || '''varchar'' as type';
			if rec.attnotnull then
				tmp = tmp || ', ''true'' as required';
			end if;
			if rec.atttypmod <> -1 then
				tmp = tmp || ', '''||(rec.atttypmod-4)::varchar|| ''' as "maxChars"';
			end if;
		end if;
		tmp = tmp ||'))';
		execute tmp into ret;
		return next ret;
	end loop;
end;
$BODY$
language 'plpgsql';



--select ce_get_xml('localidad')


--<?xml version="1.0" standalone="no"?><asl:manager xmlns:asl="http://anthill.com.ar/2009/asl" label="Localidad" name="localidad" db="sige"><asl:external/><asl:attributes><asl:attribute name="id_localidad" label="Id Localidad" column="true" type="integer" required="true"/><asl:attribute name="localidad" label="Localidad" column="true" type="varchar" maxChars="50"/><asl:attribute name="codigo_area" label="Codigo Area" column="true" type="varchar" maxChars="5"/><asl:attribute name="obsoleto" label="Obsoleto" column="true" type="boolean"/></asl:attributes><asl:children><asl:child>barrio</asl:child><asl:child>calle</asl:child></asl:children></asl:manager>


DROP FUNCTION if exists ce_view_all();
CREATE OR REPLACE FUNCTION ce_view_all()
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
begin
	perform ce_view_all(oid)
	from 	pg_class
	where 	relkind = 'r'::"char" and
		pg_get_userbyid(relowner) = current_user
		and relnatts > 1
		and relname not like '%_mig%'
	order by oid;
	return '';
end;
$BODY$
LANGUAGE 'plpgsql';
--select ce_view_all()
-- Function: ce_view_all(oid)

DROP FUNCTION if exists ce_view_all(oid);
CREATE OR REPLACE FUNCTION ce_view_all(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	ejecutar varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	ret = '';
	
	for rec in 
		select	a.attname, t.typname, a.attnum
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret || rec.attname || ', ' ;
	end loop;
	
	for rec in 
		select	a.attname, cl.relname, n.nspname, c.* 
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_namespace n
		on	n.oid = cl.relnamespace
		where	a.attrelid =  $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret || rec.nspname||'.ff_' ||rec.relname||' ('|| rec.attname||') as ff_' || rec.attname || ', ' ;
	end loop;

	ret = substring(ret from 1 for char_length(ret) -2); 

	select  n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.oid=$1;

	ejecutar = 'create or replace view '||schma||'.v_' ||v_view||'_all as select '||ret||' from '||schma||'.'||v_view ;
	execute ejecutar ;
	ejecutar  = 'create or replace view '||schma||'.v_' ||v_view||' as select '||ret||' from '||schma||'.v_' ||v_view||'_all where coalesce(obsoleto,false) = false' ;
	execute ejecutar ;
	return ejecutar ;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_view_all(oid) OWNER TO jaspe;

DROP FUNCTION if exists ce_fq(oid);
CREATE OR REPLACE FUNCTION ce_fq(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	ret_i varchar;
	ret_ql varchar;
	ret_ta varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	arg varchar;
	arg_i varchar;
	arg_rango varchar;
	whe_ins varchar;
	whe_rango varchar;
	i_body varchar;
	ejecutar varchar;
	auxiliar varchar;
	count int;
begin
	ret = '';
	arg = '';
	whe_ins = '';
	whe_rango = '';
	i_body = '';
	arg_i = '';
	arg_rango = '';
	auxiliar ='';
	count = 1;


	select  n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.oid=$1;

	for rec in 
		select	a.attname, t.typname, a.attnum
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum > 0
		order by a.attnum
	loop
		--Para retorno
		ret = ret || rec.attname || ', ';
		
		--Para argumento
		arg = arg || rec.attname || '_arg ' || rec.typname || ', ' ;

		--Para los where
		if rec.typname like 'int%' or rec.typname = 'numeric' or rec.typname = 'date' or rec.typname like 'float%' then --or rec.typname = 'bool' or rec.typname = 'boolean'
			select into whe_ins whe_ins || E'\n'|| '('||rec.attname||' = '||rec.attname || '_arg or '||rec.attname || '_arg is null) and ';
			--para fqr (con rangos)
			select into whe_rango whe_rango || E'\n'|| '(('||rec.attname||' >= '||rec.attname || '_arg_desde or '||rec.attname || '_arg_desde is null) and '||
					     ' ('||rec.attname||' <= '||rec.attname || '_arg_hasta or '||rec.attname || '_arg_hasta is null))and ';
			arg_rango = arg_rango || rec.attname || '_arg_desde ' || rec.typname || ', ' ;
			arg_rango = arg_rango || rec.attname || '_arg_hasta ' || rec.typname || ', ' ;
		elseif rec.typname = 'bool' or rec.typname = 'boolean' then
			select into whe_ins whe_ins || E'\n'|| '(' ||rec.attname || '_arg is null or '||rec.attname||'::boolean = '||rec.attname || '_arg::boolean) and ';
			select into whe_rango whe_rango || E'\n'|| '(' ||rec.attname || '_arg is null or '||rec.attname||'::boolean = '||rec.attname || '_arg::boolean) and ';
			arg_rango = arg_rango || rec.attname || '_arg ' || rec.typname || ', ' ;
		else
			select into whe_ins whe_ins || E'\n'|| 'translate(coalesce('||rec.attname||'::varchar, ''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'') ilike ''%''||translate(coalesce(('||rec.attname || '_arg)::varchar,''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'')||''%'' and ';
			select into whe_rango whe_rango || E'\n'|| 'translate(coalesce('||rec.attname||'::varchar, ''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'') ilike ''%''||translate(coalesce(('||rec.attname || '_arg)::varchar,''''),''áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñÑ'',''aeiouAEIOUaeiouAEIOUnN'')||''%'' and ';
			arg_rango = arg_rango || rec.attname || '_arg ' || rec.typname || ', ' ;
		end if;
	end loop;
	for rec in
		select	cl.oid, a.attname, cl.relname, a.attnum
		from	pg_attribute a
		inner join
			pg_constraint c
		on	a.attrelid = c.conrelid
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
			and a.attnum > 0
		inner join
			pg_class cl
		on	c.conrelid = cl.oid
		where	c.confrelid = $1
			and a.attnum > 0
		order by cl.relname
	loop
		arg_i = arg_i ||rec.attname||'_'||rec.oid::varchar||'_arg integer, ';
		i_body = i_body ||'	if '||rec.attname||'_'||rec.oid::varchar||'_arg is not null then '||E'\n'||
			'		tmp = tmp || '' inner join fq_'||rec.relname||'(''||'||rec.attname||'_'||rec.oid::varchar||'_arg||'') t'||count::varchar||
				' on t.id_'||v_view||' = t'||count||'.'||rec.attname||'''; '||E'\n'||
			'end if;'||E'\n';
			count = count+1;
	end loop;
	--ret = substring(ret from 1 for char_length(ret) -2);
	ret_ql = ret;
	for rec in 
		select	a.attname, a.attnum, n.nspname, cl.relname, t.typname, c.* 
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid	
		inner join 
			pg_namespace n
		on	n.oid = cl.relnamespace
		inner join
			pg_type t
		on	t.oid = a.atttypid
		where	a.attrelid =  $1
			and a.attnum > 0
		order by a.attnum
	loop
		ret_ql = ret_ql || rec.nspname||'.ff_' ||rec.relname||' ('|| rec.attname||') as ff_' || rec.attname || ', ' ;
	end loop;
	ret_ql = substring(ret_ql from 1 for char_length(ret_ql) -2);
	ret = substring(ret from 1 for char_length(ret) -2);
	ret_i = substring(ret_i from 1 for char_length(ret_i) -2);
	arg = substring(arg from 1 for char_length(arg) -2);
	whe_ins = substring(whe_ins from 1 for char_length(whe_ins) -5);
	arg_rango = substring(arg_rango from 1 for char_length(arg_rango) -2);
	whe_rango = substring(whe_rango from 1 for char_length(whe_rango) -5);
	--whe_fil = substring(whe_fil from 1 for char_length(whe_fil) -5);

	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' () returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
		' select *'||E'\n' ||  --||ret
		' from '||schma||'.v_'||v_view||'_all; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
		' select *'||E'\n' ||
		' from '||schma||'.v_'||v_view||'_all '||E'\n' ||
		' limit $1 offset $2; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (id_' ||v_view||'_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where id_'||v_view||' = $1; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;
	
	ejecutar = 'create or replace function '||schma||'.fq_'||v_view||' (id_' ||v_view||'_arg int, lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where id_'||v_view||' = $1 '||E'\n' ||
		' limit $2 offset $3; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fq_'||v_view||' (' ||arg||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_ins||'; '||E'\n' ||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fqr_'||v_view||' (' ||arg_rango||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_rango||'; '||E'\n' ||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 	'create or replace function '||schma||'.fq_'||v_view||' (' ||arg||', lim_arg int, off_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		' return query'||E'\n'||
		' select *'||E'\n'||
		' from '||schma||'.v_'||v_view||'_all'||E'\n'||
		' where '||whe_ins||E'\n' ||
		' limit lim_arg offset off_arg;'||E'\n'||
		'end;'||E'\n'||
		 '$' || 'body$ '||E'\n'||
		 ' language plpgsql;';
	execute ejecutar ;

	ejecutar = 'create or replace function '||schma||'.fql_'||v_view||' (id_' ||v_view||'_arg int) returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select '||ret_ql||
		--' from v_'||v_view||
		' from '||schma||'.fq_'||v_view||'()'||
		' where id_'||v_view||' = $1; '||E'\n' ||
		 '$' || 'body$ '||E'\n'||
		 ' language sql;';
	execute ejecutar;
	
	if char_length(arg_i) > 2 then
		arg_i = substring(arg_i from 1 for char_length(arg_i) -2);
		ejecutar = 	'create or replace function '||schma||'.fqi_'||v_view||' (' ||arg_i||') returns setof '||schma||'.v_'||v_view||'_all as '||E'\n'||
			'$' || 'body$ '||E'\n'||
			' declare '||E'\n'||
			' 	tmp varchar; '||E'\n'||
			' 	ret record; '||E'\n'||
			' begin '||E'\n'||
			' 	tmp = ''select t.* from '||schma||'.fq_'||v_view||'() t '';'||E'\n'||
			i_body||
			' 	for ret in'||E'\n'||
			'		execute tmp'||E'\n'||
			'	loop'||E'\n'||
			'		return next ret;'||E'\n'||
			'	end loop;'||E'\n'||
			' end; '||E'\n'||
			 '$' || 'body$ '||E'\n'||
			 ' language ''plpgsql'';';
		execute ejecutar;
	end if;
	return ejecutar ||E'\n';
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fq(oid) OWNER TO jaspe;
-- Function: ce_fq()

DROP FUNCTION if exists ce_fq();

CREATE OR REPLACE FUNCTION ce_fq()
  RETURNS character varying AS
$BODY$
	select 	ce_fq(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1 
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fq() OWNER TO jaspe;
--select ce_fq()

-- Function: ce_fs(oid)
DROP FUNCTION if exists ce_fs(oid);
CREATE OR REPLACE FUNCTION ce_fs(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	arg varchar;
	sarg varchar;
	arr_arg varchar;
	arg_ins varchar;
	value_ins varchar;
	whe_ins varchar;
	set_update varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	ret varchar;
	ignorar int[];
begin
	arg = '';
	sarg = '';
	arr_arg = '';
	arg_ins = '';
	whe_ins = '';
	value_ins ='';
	set_update ='';
	--RAISE EXCEPTION 'source si %', ignorar;
	for rec in 
		select	a.attname, t.typname, a.attnum, c.relname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		inner join
			pg_class c
		on	c.oid = a.attrelid
		where	a.attrelid = $1 and 
			a.attnum > 0 
		order by a.attnum
	loop
		arg = arg || rec.attname || '_arg ' || rec.typname || ', ' ;
		sarg = sarg || rec.attname || '_arg, ' ;
		arr_arg = arr_arg || rec.attname || '_arg::varchar, ' ;
		if rec.attnum <> 1 then
			arg_ins = arg_ins || rec.attname || ', ' ;
			value_ins = value_ins || '$'||rec.attnum||', '||E'\n\t\t';
			select into whe_ins whe_ins ||
				'coalesce('||rec.attname||','|| case when rec.typname ilike 'int%' or rec.typname ilike 'float%' then '0' when rec.typname = 'attribute_nested' then '''single''' when rec.typname = 'bool' then '''false''' else '''''::'||rec.typname end||') ='||
				'coalesce(case when ignorar @> array['||rec.attnum||'] then '||rec.attname||' else $'||rec.attnum||' end ,'|| case when rec.typname ilike 'int%' or rec.typname ilike 'float%' then '0' when rec.typname = 'attribute_nested' then '''single''' when rec.typname = 'bool' then '''false''' else '''''::'||rec.typname end||') and '||E'\n\t\t\t';
			set_update = set_update||rec.attname||' = $'||rec.attnum||', '||E'\n\t\t\t';
		end if;
	end loop;
	
	if char_length(arg) >= 2 then
		arg = substring(arg from 1 for char_length(arg) -2);
	end if;	
	if char_length(sarg) >= 2 then
		sarg = substring(sarg from 1 for char_length(sarg) -2);
	end if;
	if char_length(arr_arg) >= 2 then
		arr_arg = substring(arr_arg from 1 for char_length(arr_arg) -2);
	end if;
	if char_length(arg_ins) >= 2 then
		arg_ins = substring(arg_ins from 1 for char_length(arg_ins) -2);
	end if;	
	if char_length(value_ins) >= 2 then
		value_ins = substring(value_ins from 1 for char_length(value_ins) -5);
	end if;	
	if char_length(whe_ins) >= 5 then
		whe_ins = substring(whe_ins from 1 for char_length(whe_ins) -9);
	end if;	
	if char_length(set_update) >= 2 then
		set_update =  substring(set_update from 1 for char_length(set_update) -6);
	end if;	
	
	select  n.nspname,c.relname into schma,v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	pg_get_userbyid(c.relowner) = current_user
		and c.relkind = 'r'::"char"
		and c.relnatts > 1
		and c.relname not like '%_mig%'
--		and relname not like 'ce_%'
		and c.oid=$1;
	ret = 	'create or replace function '||schma||'.fs_'||v_view||' (' ||arg||') returns int as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' declare '||E'\n'||
		'   rowc integer; retorno integer; state char(1); tm_var timestamp with time zone;'||E'\n'||
		' begin '||E'\n'||
		' 	if $1 is null then '||E'\n'||
		'      		insert into '||schma||'.'||v_view||' (' ||arg_ins ||') '||E'\n'||
		'      		values ('||value_ins||'); '||E'\n'||
		'      		get diagnostics rowc = row_count;'||E'\n'||
		'      		select into retorno max(id_'||v_view||')'||E'\n'||
		'      		from	'||schma||'.v_'||v_view||';'||E'\n'||
		--'      		where	'||whe_ins||';'||E'\n'||
		'  	else '||E'\n'||
		'      		update   '||schma||'.'||v_view||E'\n'||
		'      		set	'||set_update||E'\n'||
		'      		where	id_'||v_view||' = $1;'||E'\n'||
		'      		get diagnostics rowc = row_count;'||E'\n'||
		'      		retorno = $1;'||E'\n'||
		'  	end if; '||E'\n'||
		'  	if rowc <= 0 then '||E'\n'||
		'  		RAISE EXCEPTION ''En la entidad '||schma||'.'||v_view||' no se pudo guardar.'';'||E'\n'||
		'  	end if;'||E'\n'||		
		'  return retorno;'||E'\n'||
		'end;'||E'\n'||		
		 '$' || 'body$ '||E'\n'||
		 'language plpgsql;';
	execute ret;
	return ret ;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fs(oid) OWNER TO jaspe;
-- Function: ce_fs()

DROP FUNCTION if exists ce_fs();

CREATE OR REPLACE FUNCTION ce_fs()
  RETURNS character varying AS
$BODY$
	select  ce_fs(oid) --*
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char" 
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
	
$BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fs() OWNER TO jaspe;
-- Function: ce_fq(oid)


-- Function: ce_fl(oid)

DROP FUNCTION if exists ce_fl(oid);

CREATE OR REPLACE FUNCTION ce_fl(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
	arg varchar; 
	where_arg varchar; 
	i int; 
begin
	ret = '';
	select distinct n.nspname, l.relname into schma, v_view --, l.oid --
	from 	pg_class l
	inner join
		pg_namespace n
	on	n.oid = l.relnamespace
	inner join
		pg_constraint c
	on	c.conrelid = l.oid
		and c.contype = 'f'
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
		and l.oid=$1;
	i=0;
	arg='';
	where_arg ='';
	for rec in 
		select	a.attname, cl.relname, t.typname
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_attribute af
		on	af.attnum = any(c.confkey)
			and af.attrelid = cl.oid
		inner join
			pg_type t
		on	t.oid = af.atttypid
		where	a.attrelid =  $1 
			and a.attnum > 0
		order by a.attnum
	loop
		i=i+1;
		arg = arg||rec.attname|| '_arg ' || rec.typname || ', ';
		where_arg = where_arg || '($' || i || ' is null or coalesce('|| rec.attname || ',0) = coalesce($' || i || ',0)) and ';
	end loop;

	arg = substring(arg from 1 for char_length(arg) -2);
	where_arg = substring(where_arg from 1 for char_length(where_arg) -5);
	
	for rec in 
		select	a.attname, t.typname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum = 2
		order by a.attnum
	loop
		ret = 	'create or replace function '||schma||'.fl_' ||v_view||' ('||arg||') returns setof t_ff as'||E'\n'||
			'$' || 'body$ '||E'\n'||
			'   select id_'||v_view||'::int, '||rec.attname||'::varchar from '||schma||'.v_'||v_view||' where '||where_arg||';'||E'\n'||
			'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fl(oid) OWNER TO jaspe;
-- Function: ce_fl()

DROP FUNCTION if exists ce_fl();

CREATE OR REPLACE FUNCTION ce_fl()
  RETURNS character varying AS
$BODY$
declare 
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select 	distinct ce_fl (l.oid) as a
		from 	pg_class l
		inner join
			pg_constraint c
		on	c.conrelid = l.oid
			and c.contype = 'f'
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fl() OWNER TO jaspe;
-- Function: ce_ff(oid)


DROP FUNCTION if exists ce_fl_by_fk(oid);
CREATE OR REPLACE FUNCTION ce_fl_by_fk(id_table oid) 
RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	select distinct n.nspname, c.relname into schma, v_view 
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where	c.oid=$1;

	ret='';
	
	for rec in 
		select	a.attname, cl.relname, t.typname
		from	pg_attribute a
		inner join
			pg_constraint c
		on	c.conrelid = a.attrelid 
			and c.contype = 'f'
			and a.attnum = any(c.conkey)
		inner join
			pg_class cl
		on	c.confrelid = cl.oid
		inner join
			pg_attribute af
		on	af.attnum = any(c.confkey)
			and af.attrelid = cl.oid
		inner join
			pg_type t
		on	t.oid = af.atttypid
		where	a.attrelid = $1 
			and a.attnum > 0
		order by a.attnum
	loop
		ret = ret ||
		'create or replace function '||schma||'.fl_'||v_view||'_by_'||rec.attname||'(var_'||rec.attname||' '|| rec.typname||') returns setof '||schma||'.v_'||v_view||' as '||E'\n'||
		'$' || 'body$ '||E'\n'||
		' select * from '||schma||'.v_'||v_view||' where '||rec.attname||' = $1;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		' language sql;'||E'\n';
	end loop;
	execute ret;
	return ret;
end;
$BODY$
LANGUAGE 'plpgsql';

DROP FUNCTION if exists ce_fl_by_fk();
CREATE OR REPLACE FUNCTION ce_fl_by_fk()
  RETURNS character varying AS
$BODY$
declare 
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select 	distinct ce_fl_by_fk (l.oid) as a
		from 	pg_class l
		inner join
			pg_constraint c
		on	c.conrelid = l.oid
			and c.contype = 'f'
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql';

DROP FUNCTION if exists ce_ff(oid);
CREATE OR REPLACE FUNCTION ce_ff(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	schma varchar;
begin
	ret = '';
	select n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
		and c.oid=$1;
	for rec in 
		select	a.attname, t.typname
		from	pg_attribute a
		inner join
			pg_type t
		on	t.oid = atttypid
		where	a.attrelid = $1
			and a.attnum = 2
		order by a.attnum
	loop
		ret = 	'create or replace function '||schma||'.ff_' ||v_view||' (id_'||v_view||'_arg int) returns '||rec.typname||' as'||E'\n'||
			E'$' || 'body$ '||E'\n'||
			'   select '||rec.attname||' from '||schma||'.'||v_view||E'\n' ||
			' where id_'||v_view||' = $1 and COALESCE(obsoleto, false) = false;'||E'\n' ||
			E'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;

		ret = 	'create or replace function '||schma||'.ff_' ||v_view||' () returns setof t_ff as'||E'\n'||
			E'$' || 'body$ '||E'\n'||
--id as data, name as label
			'   select id_'||v_view||'::int as data, '||rec.attname||'::varchar as label'||E'\n'||
			' from '||schma||'.'||v_view||E'\n'||
			' where COALESCE(obsoleto, false) = false;'||E'\n' ||
			E'$' || 'body$ '||E'\n'||
			'language sql;';
		execute ret;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_ff(oid) OWNER TO jaspe;
-- Function: ce_ff()

DROP FUNCTION if exists ce_ff();

CREATE OR REPLACE FUNCTION ce_ff()
  RETURNS character varying AS
$BODY$
declare
	rec record;
	ret varchar;
begin
	ret = '';
	for rec in 
		select	ce_ff(oid) as a
		from 	pg_class
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'r'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
		order by oid
	loop
		ret = ret ||E'\n'|| rec.a;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_ff() OWNER TO jaspe;

-- Function: ce_fd(oid)
DROP FUNCTION if exists ce_fd(oid);

CREATE OR REPLACE FUNCTION ce_fd(id_table oid)
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	v_view varchar;
	schma varchar;
begin
	select n.nspname, c.relname into schma, v_view
	from 	pg_class c
	inner join
		pg_namespace n
	on 	n.oid = c.relnamespace
	where 	c.oid = $1;

	ret = 	'create or replace function '||schma||'.fd_' ||v_view||' (id_'||v_view||'_arg int) returns int as'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'declare'||E'\n'||
		'	rowc integer;'||E'\n'||
		'	canti integer;'||E'\n'||
		'begin'||E'\n'||
		--'   	delete from '||schma||'.'||v_view||' where id_'||v_view||' = $1;'||E'\n'||
		'	update '||schma||'.'||v_view||' set obsoleto = true where id_'||v_view||' = $1;'||E'\n'||
		'   	get diagnostics rowc = row_count;'||E'\n'||
		'   	if rowc <= 0 then'||E'\n'||
		'      		RAISE EXCEPTION ''En la entidad '||schma||'.'||v_view||' no se pudo borrar.'';'||E'\n'||
		'   	end if;'||E'\n'||
		' return $1;'||E'\n'||
		'end;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'language plpgsql;';	
	execute ret;
	return ret ;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fd(oid) OWNER TO jaspe;
-- Function: ce_fd()

DROP FUNCTION if exists ce_fd();

CREATE OR REPLACE FUNCTION ce_fd()
  RETURNS character varying AS
$BODY$
	select 	ce_fd(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION ce_fd() OWNER TO jaspe;

-- Function: ce_dv()

DROP FUNCTION if exists ce_dv();

CREATE OR REPLACE FUNCTION ce_dv()
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
begin
	ret = '';
	for rec in 
		select 	c.oid, relname, nspname
		from 	pg_class c
		inner join
			pg_namespace n
		on	n.oid = c.relnamespace
		where 	pg_get_userbyid(relowner) = current_user
			and relkind = 'v'::"char"
			and relnatts > 1
			and relname not like '%_mig%'
--			and relname not like 'ce_%'
		order by oid
	loop
		ret = 'drop view if exists ' ||rec.nspname||'.'||rec.relname ||' cascade;';
		execute ret;
	end loop;
	return ret;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_dv() OWNER TO jaspe;
-- Function: ce_df()

DROP FUNCTION if exists ce_df();

CREATE OR REPLACE FUNCTION ce_df()
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	arg varchar;
	i int;
	retorno varchar;
begin
	ret = '';
	retorno ='';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid
		where 	((	proname ilike ('ff%') or 
				proname ilike ('fd%') or 
				proname ilike ('fq%') or 
				proname ilike ('fs%') or 
				proname ilike ('fl%') ) and 
			substr(proname,3,1)='_') or 
			(( 	proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%'))and 
			substr(proname,4,1)='_') or 
			((	proname ilike ('ffx%') or 
				proname ilike ('fdx%') or 
				proname ilike ('fqx%') or 
				proname ilike ('fsx%') or 
				proname ilike ('flx%') ) and 
			substr(proname,4,1)='_') or
			(( 	proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%'))and 
			substr(proname,5,1)='_') 
	loop
		arg='';		
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
		end if;
		ret = 'drop function if exists ' ||rec.nspname||'.'||rec.proname ||' ('||arg||') cascade;';
		execute ret;
	end loop;
	return retorno;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION ce_df() OWNER TO jaspe;

drop function if exists ce_fx();
CREATE OR REPLACE FUNCTION ce_fx()
  RETURNS character varying AS
$BODY$
declare 
	ret varchar;
	rec record;
	v_view varchar; 
	arg varchar;
	condicion varchar;
	i int;
	retorno varchar;
begin
	retorno ='';
	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid 
		where 	((	proname ilike ('fd%') or 
				proname ilike ('fq%') or 
				proname ilike ('fs%') or 
				proname ilike ('fl%')
				) and 
			substr(proname,3,1)='_')
	loop
		arg='';		
		condicion ='';
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''''||'||E'$'||i+1||'||'''' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, ' --acaaca
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<table>''||
			query_to_xml(''select * from '||rec.nspname||'.'||substr(rec.proname,1,2)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</table>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;


	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid  
		where 	((	proname ilike ('ff%')
				) and 
			substr(proname,3,1)='_')
	loop
		arg='';	
		condicion ='';	
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''||'||E'$'||i+1||'||'' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname||'.'||substr(rec.proname,1,2)||'x_'||substr(rec.proname,4)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<query>''||
			query_to_xml(''select * from '||rec.nspname||'.'||substr(rec.proname,1,2)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</query>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;


	ret = '';
	for rec in 
		select 	p.oid,n.nspname,p.*
		from 	pg_proc p 
		inner join
			pg_namespace n
		on	p.pronamespace = n.oid
		where 	((
				proname ilike ('ftg%') or
				proname ilike ('fql%') or 
				proname ilike ('fqi%')
				) and 
			substr(proname,4,1)='_')
	loop
		arg='';	
		condicion ='';	
		if coalesce(rec.pronargs,0) > 0 then 
			FOR i IN 0..(rec.pronargs -1) LOOP
				select into arg arg||t.typname || ', '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
				select into condicion condicion||'case when ''||'||E'$'||i+1||'||'' is null then null::'||t.typname||' else ''''''||'||E'$'||i+1||'||''''''::'||t.typname||' end, '
				from 	pg_proc p
				inner join
					pg_type t
				on	t.oid = p.proargtypes[i] and p.oid = rec.oid;
			END LOOP;
			arg = substring(arg from 1 for char_length(arg) -2);
			condicion = substring(condicion from 1 for char_length(condicion) -2);
		end if;
		ret = 'drop function if exists '||rec.nspname ||'.' ||rec.proname ||' ('||arg||') cascade;';
		execute ret;
		ret = 	'create or replace function '||rec.nspname ||'.'||substr(rec.proname,1,3)||'x_'||substr(rec.proname,5)||'('||arg||') returns xml as
	'||E'$'||'BODY$ 
	declare	ret xml;
	begin 
		select ''<query>''||
			query_to_xml(''select * from '||rec.nspname ||'.'||substr(rec.proname,1,3)||'_'||substr(rec.proname,4)||'('||condicion||')'',true,true,'''')||
			''</query>'' into ret; 
		return ret;
	end; 
	'||E'$'||'BODY$
	language ''plpgsql'';';
		execute ret;
		retorno =  retorno  || ret || E'\n';
	end loop;

	return retorno;
end;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;

drop function if exists ce_adhoc();
CREATE OR REPLACE FUNCTION ce_adhoc() RETURNS integer AS
$BODY$
declare 
	rec record;
	ejecutar varchar;
	i integer;
begin
	i=0;
	for rec in 
		select 	*
		from 	v_ce_adhoc
		order by orden
	loop
		ejecutar=rec.ejecutar;
		execute ejecutar;
		i=i+1;
	end loop;
	return i;
end;
$BODY$
LANGUAGE 'plpgsql';	

create or replace function ce_tg(id_table oid) returns varchar as
$body$
declare 
	ret varchar;
	v_view varchar;
	schma varchar;
begin
	select  nspname, relname into schma, v_view 
	from 	pg_class c
	inner join
		pg_namespace n
	on	n.oid = c.relnamespace
	where 	c.oid = $1;
	
	ret = 	'create or replace function '||schma||'.ftg_' ||v_view||' () returns trigger as'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'begin'||E'\n'||
		'   if (tg_op = ''UPDATE'') then'||E'\n'||
		'   	if old.obsoleto != new.obsoleto then'||E'\n'||
		'   		insert into anthill.ce_auditoria (entidad,id,atributo,valor,usuario,fecha) '||E'\n'||
		'   		values ('''||schma||'.'||v_view||''',new.id_'||v_view||',''obsoleto'',new.obsoleto,user,now());'||E'\n'||
		'   	end if;'||E'\n'||
		'   elsif (tg_op = ''INSERT'') then'||E'\n'||
		'   	insert into anthill.ce_auditoria (entidad,id,nueva_fila,usuario,fecha) '||E'\n'||
		'   	values ('''||schma||'.'||v_view||''',new.id_'||v_view||',true,user,now());'||E'\n'||
		'   end if;'||E'\n'||
		'   return new;'||E'\n'||
		'end;'||E'\n'||
		'$' || 'body$ '||E'\n'||
		'language plpgsql;';	
	execute ret;
	ret = 	'create trigger tiu_'||schma||'_'||v_view||' before insert or update on '||schma||'.'||v_view||' for each row execute procedure '||schma||'.ftg_' ||v_view||' ();';
	execute ret;
	DROP TRIGGER if exists tiu_anthill_ce_auditoria ON anthill.ce_auditoria;
	return ret ;
end;
$body$
language plpgsql;

create or replace function ce_tg() returns varchar as
$body$
	select 	ce_tg(oid)
	from 	pg_class
	where 	pg_get_userbyid(relowner) = current_user
		and relkind = 'r'::"char"
		and relnatts > 1
		and relname not like '%_mig%'
--		and relname not like 'ce_%'
	order by oid;
$body$
language sql;

ALTER FUNCTION ce_df() OWNER TO jaspe;
-- Function: ce()
DROP FUNCTION if exists ce();

CREATE OR REPLACE FUNCTION ce()
  RETURNS character varying AS
$BODY$
	select ce_dv(); --Borrar las vistas
	select ce_df(); --Borrar las funciones
--	select ce_view(); 
	select ce_ff(); --Crea las funciones de 1 columna para las foraneas
	select ce_view_all(); --Crea las vistas
	select ce_fs(); --Crea las funciones de ABM
	--select ce_fl(); --Crea las funciones que filtran por las claves foraneas
	select ce_fl_by_fk(); --Crea las funciones que filtran por la clave foranea fk
	select ce_fd(); --Crea las funciones que realizan las bajas
	select ce_fq(); --Crea las funciones que realizan los listados standares
--	select ce_fx();
	select ce_adhoc()::varchar; --Crea ejecuta las funciones adhoc de la aplicacion
	select ce_tg(); --Crea los triggers de auditoria
$BODY$
  LANGUAGE 'sql' VOLATILE
  COST 100;
ALTER FUNCTION ce() OWNER TO jaspe;

select ce();
--select * from ce_adhoc;
