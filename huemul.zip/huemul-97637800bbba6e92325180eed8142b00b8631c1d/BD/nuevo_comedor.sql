drop view v_persona_all cascade;

alter table persona
	rename column obsoleto to temp1;
		
alter table persona	
	add column obsoleto boolean default false;

update 	persona
set	obsoleto=temp1;

update 	persona
set	temp1=null;

alter table persona
	rename column temp1 to formulario;

alter table persona
	alter column formulario type varchar(500);

set search_path = anthill, public;

select ce_ff(oid) from pg_class where relname='persona' and relkind='r'; --Crea las funciones de 1 columna para las foraneas
select ce_view_all(oid) from pg_class where relname='persona' and relkind='r';
select ce_fs(oid) from pg_class where relname='persona' and relkind='r';
	--select ce_fl(); --Crea las funciones que filtran por las claves foraneas
select ce_fl_by_fk(oid) from pg_class where relname='persona' and relkind='r';
select ce_fd(oid) from pg_class where relname='persona' and relkind='r';
select ce_fq(oid) from pg_class where relname='persona' and relkind='r';
--	select ce_fx();
--select ce_tg(oid) from pg_class where relname='persona' and relkind='r';

set search_path = public, anthill;