--create type historial as (fecha timestamp, ingreso real, egreso real, saldo real);

create or replace function f_historial(id_cliente_arg integer) 
returns setof historial as
$body$
declare
	v_saldo real;
	v_saldo_next real;
	rec record;
begin
	select 	saldo
	into	v_saldo_next
	from 	cliente 
	where 	id_cliente = $1;
	
	for rec in
		select 	fecha, 
			ingreso, 
			null::real as egreso
		from 	venta 
		where 	id_cliente = $1
		union
		select 	fecha, 
			null::real as ingreso, 
			case when valor = 0 then null else valor end as egreso
		from 	racion
		where 	id_cliente = $1
		order by 1 desc
	loop
		v_saldo = v_saldo_next;
		if rec.ingreso is not null then
			v_saldo_next = v_saldo - rec.ingreso;
		elsif rec.egreso is not null then
			v_saldo_next = v_saldo + rec.egreso;
		end if;
		return 	query 
		select 	rec.fecha as fecha, 
			rec.ingreso as ingreso,
			rec.egreso as egreso,
			v_saldo as saldo;
	end loop;
end;
$body$
language plpgsql;

select * from f_historial(1856)



select * from cliente where codigo = '0475745A2B97E30'