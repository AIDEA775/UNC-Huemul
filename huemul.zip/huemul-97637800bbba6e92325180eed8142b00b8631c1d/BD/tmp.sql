﻿/*select 	'Agrega Saldo' as tipo,
	sum(v.saldo)+sum(v.ingreso)-sum(i.subtotal) as sum
from 	venta v
left join
	item_venta i
on	i.id_venta = v.id_venta
where v.ingreso > 0
group by 1
union
select 'Venta Extras',
	sum(i.subtotal)-sum(v.saldo)
from 	venta v
inner join
	item_venta i
on	i.id_venta = v.id_venta
where v.ingreso > 0
group by 1
order by 1


select 	v.id_venta, 
	count(*) 
from 	venta v
left join
	item_venta i
on	i.id_venta = v.id_venta
where v.ingreso > 0
group by 1

*/

select 	'Agrega Saldo' as tipo,
	count(*) as sum
from 	venta v
left join
	item_venta i
on	i.id_venta = v.id_venta
where 	v.ingreso > 0
and	i.id_venta is null
group by 1
union
select 	distinct 'Venta Extras',
	count(v.id_venta)
from 	venta v
inner join
	item_venta i
on	i.id_venta = v.id_venta
where 	v.ingreso > 0
	and sum(i.subtotal) >= v.ingreso
group by 1
union
select 	distinct 'Ambos',
	count(v.id_venta)
from 	venta v
inner join
	item_venta i
on	i.id_venta = v.id_venta
where 	v.ingreso > 0
	and sum(i.subtotal) < v.ingreso
group by 1
order by 1