
------------------------------------------------------------
-- apex_puntos_montaje
------------------------------------------------------------

--- INICIO Grupo de desarrollo 0
INSERT INTO apex_puntos_montaje (id, etiqueta, proyecto, proyecto_ref, descripcion, path_pm, tipo) VALUES (
	'1', --id
	'proyecto', --etiqueta
	'comedor', --proyecto
	'comedor', --proyecto_ref
	'punto de montaje por defecto proyectos toba', --descripcion
	'php', --path_pm
	'proyecto_toba'  --tipo
);
--- FIN Grupo de desarrollo 0
