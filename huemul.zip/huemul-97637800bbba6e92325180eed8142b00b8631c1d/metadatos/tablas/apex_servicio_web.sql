
------------------------------------------------------------
-- apex_servicio_web
------------------------------------------------------------
INSERT INTO apex_servicio_web (proyecto, servicio_web, descripcion, param_to, param_wsa) VALUES (
	'comedor', --proyecto
	'ws_codigo', --servicio_web
	NULL, --descripcion
	'http://localhost/codigo_gen/1.0/servicios.php/141000018', --param_to
	'1'  --param_wsa
);
