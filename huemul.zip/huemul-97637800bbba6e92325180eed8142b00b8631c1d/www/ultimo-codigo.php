<?php
header("Content-Type: text/xml");
echo file_get_contents("http://172.16.3.29/ultimo-codigo.xml");
?>