<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<?php 
if(isset($_GET['f'])) { 
	# LOAD XML FILE 
	/*$XML = new DOMDocument(); 
	$XML->loadXML(urldecode($_GET['f']));*/ 
	
	# START XSLT
	if($_GET['cargado'] != 'S') {
		$file = 'no-cargados/forms/'.urldecode(basename($_GET['f']));
	} else {
		$file = 'cargados/'.urldecode(basename($_GET['f']));
	}
	
	if(is_file($file)) {
		$xslt = new XSLTProcessor(); 
		$style = new DOMDocument(); 
		$style->load( 'libs/ver_form.xsl', LIBXML_NOCDATA); 
		$xslt->importStylesheet($style);
		if(isset($_GET['foto'])) {
			$xslt->setParameter('', 'foto', $_GET['foto']);
		} 
		#PRINT 
		$cuerpo = $xslt->transformToXML(  simplexml_load_file($file) );
	} 
}
?>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Formulario - Comedor Universitario</title>
	</head>
	<body onload="">
		<style>
		  .imgcnt {
		    border: 1px solid black;
		    padding: 5px;
		    top: 0px;
		    position: absolute;
		    right: 0px;
		    height: 320px;
		    width: 320px;
		    text-align: center;
		  }
		
		.imgcnt * {
			padding: 0px !important;
		}
		
		.requerido label, .requerido_opt label {
			font-weight: bold;
		}
		
	    .seccion {
	      border: 1px solid black;
	      margin: 15px 0px;
	    }
	  
	    .seccion table {
	      width: 100%;
	    }
	
	    .seccion table th {
	      background-color: #aaaaaa;
	      border: 1px solid black;
	    }
	
	    .seccion table td {
	      text-align: center;
	      border: 1px solid black;
	    }
	
	    .seccion .titulo {
	      background-color: #6592af;
	      color: white;
	      font-weight: bold;
	    }
	    .seccion * {
	      padding: 5px;
	    }
	    
	    .tr {
	    	display: table-row;
	    }
	    
	    .td {
	    	display: table-cell;
	    	margin: 5px;
	    }
	    
	    div.td {
	    	padding: 5px 4px;
	    }
	    
	    div.td * {
	    	padding: 5px;
	    }
	    
	    label.td {
	    	text-align: right;
	    	vertical-align: middle;
	    }
	    
	    .error {
	    	border: 1px solid red;
	    }
	  </style>
	  
	  <div style="width: 80%; margin: 20px auto">
	  	<div style="background-color: #014268; height: 100px; color: white; font-size: 30px; margin-bottom: 10px" >
			<img src="../img/logo_unc.jpg" style="vertical-align: middle"/> <span style="vertical-align: middle; margin-left: 20px">Formulario de Solicitud - Comedor Universitario</span>
	    </div>
	    
	    <?php echo $cuerpo; ?>
	    <!-- <div style='clear:both' class='seccion' id="sec_dp">
	    		<div class="titulo">Datos Personales</div>
				<div style="position:relative">
		    		<div id="finDiv" class="imgcnt" style="display:none;">
					  <button onclick="chImg()">Cambiar Imagen</button>
					  <hr/>
					  <img id="final" style="height: 240px; width: 240px; border: 1px solid black"/>	  
					</div>
					<div class="tr requerido"><label class="td" for="nombre">Nombre: </label><input class="td" type="text" name="nombre" id="nombre"/></div>
				</div>
			</div>
	     -->
	  </div>
	</body>
</html>