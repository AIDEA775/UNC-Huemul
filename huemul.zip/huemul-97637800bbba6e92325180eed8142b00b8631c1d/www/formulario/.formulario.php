<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Formulario - Comedor Universitario</title>
	<meta name="generator" content="TextMate http://macromates.com/">
	<meta name="author" content="Joseph Huckaby">
	<!-- Date: 2008-03-15 -->
	<script src="http://ajax.googleapis.com/ajax/libs/prototype/1.6.1.0/prototype.js" type="text/javascript"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/scriptaculous/1.8.2/scriptaculous.js" type="text/javascript"></script>
	<script src="js/cropper.uncompressed.js" type="text/javascript"></script>
	<!--script src="js/cropper.js" type="text/javascript"></script-->
	<script src="js/webtoolkit.aim.js" type="text/javascript"></script>
	<script>
	function triggerEvent(element, eventName) {
	    // safari, webkit, gecko
	    if (document.createEvent)
	    {
	    	var evt = document.createEvent('HTMLEvents');
	    	evt.initEvent(eventName, true, true);
	        return element.dispatchEvent(evt);
	    }
	 
	    // Internet Explorer
	    if (element.fireEvent) {
	        return element.fireEvent('on' + eventName);
	    }
	}

	
	function init() {
		$('pba').observe('change', function() {
			this.value=='No'?$('bopr').hide():$('bopr').show();
		});
		
		$('bop').observe('change', function() {
			this.value=='Otro'?$('bopt').show():$('bopt').hide()
		});
		
		$('roa').observe('change', function() {
			this.value=='No'?$('rper').hide():$('rper').show(); triggerEvent($('rpe'),'change');
		});

		$('rpe').observe('change', function() {
			!$('rper').visible()||this.value=='No'?$('cgor').hide():$('cgor').show();
		});
		
		$('cgd').observe('change', function() {
			this.value=='Otro'?$('cgdt').show():$('cgdt').hide();
		});

		$('dou').observe('change', function() {
			this.value=='No'?$('ounr').hide():$('ounr').show();
		});

		$('nea').observe('change', function() {
			this.value=='Otro'?$('neat').show():$('neat').hide();
		});

		$('con').observe('change', function() {
			this.value=='No'?$('catr').hide():$('catr').show();
		});

		$('cat').observe('change', function() {
			this.value=='Otro'?$('catt').show():$('catt').hide();
		});

		$('rac').observe('change', function() {
			this.value=='No'?$('curr').hide():$('curr').show();
		});
		
		$('cuip0').observe('keypress', numCheck);

		$('cuip1').observe('keypress', numCheck);

		$('cuip2').observe('keypress', numCheck);
		
		parentByClassName($('cuip0'), 'tr').validar = validaCuit;
		parentByClassName($('nombre'), 'tr').validar = validaTexto;
		parentByClassName($('apellido'), 'tr').validar = validaTexto;
	}

	function numCheck(event) {
		var key = event.keyCode || event.which || event.charCode;
		var c = String.fromCharCode(key); 
		if(!event.ctrlKey && (key == 32 || key > 46) && !c.match(/\d/)) {
			event.stop();
		}
		
	}
	
	function validaCuit(cuit) {
		if (typeof (cuit) == 'undefined')
			return true;

		cuit = cuit.toString().replace(/[-_]/g, "");

		if (cuit == '')
			return true; //No estamos validando si el campo esta vacio, eso queda para el "required"
		if (cuit.length != 11)
			return false;
		else {
			var mult = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
			var total = 0;
			for (var i = 0; i < mult.length; i++) {
				total += parseInt(cuit[i]) * mult[i];
			}
			var mod = total % 11;
			var digito = mod == 0 ? 0 : mod == 1 ? 9 : 11 - mod;
		}
		return digito == parseInt(cuit[10]);
	}

	function validaTexto(texto) {
		if(typeof texto == 'undefined' || texto == '') {
			return true;
		}
		return /^[a-z' ]+$/i.test(texto);
	}

	function mkXML() {
		var sec = document.getElementsByClassName('seccion');
		var xml = [];
		xml.push('<root>'+"\n");
		for(var i=0; i<sec.length; i++) {
			if(sec[i].visible()) {
				var titulo = sec[i].getElementsByClassName('titulo')[0].innerHTML
				xml.push("\t"+'<seccion titulo="'+titulo+'">'+"\n");
				if(i==0) {
					xml.push("\t\t"+'<row pregunta="foto" id="foto" id_elems="final">');
					xml.push($('final').src);
					xml.push('</row>'+"\n");
				}
				var tr = sec[i].getElementsByClassName('tr');
				for(var j=0; j<tr.length; j++) {
					if(tr[j].visible()) {
						var h = getChildrenByTagsName(tr[j], ['select','input']);
						var r = [];
						var ids = [];
						for(var k=0; k<h.length; k++) {
							if(h[k].visible()) {
								r.push(h[k].value);
								ids.push(h[k].id);
							}
						}
						xml.push("\t\t"+'<row pregunta="'+tr[j].getElementsByTagName('label')[0].innerHTML+'" id="'+tr.id+'" id_elems="'+ids.join(' ')+'">');
						xml.push(r.join(' - '));
						xml.push('</row>'+"\n");
					}
				}
				xml.push("\t"+'</seccion>'+"\n");
			}
		}
		xml.push('</root>');
		return xml.join('');
	}

	function getChildrenByTagsName(elem, tags) {
		var children = [];
		if(typeof tags == 'string') {
			tags = [tags];
		} 
		if(elem.childNodes) {
			for(var i=0; i<elem.childNodes.length; i++) {
				var e = elem.childNodes[i];
				for(var j = 0; j<tags.length; j++) {
					if(e.tagName && e.tagName.toLowerCase() == tags[j].toLowerCase()) {
						children.push(e);
						break;
					}
				}
				if(e.childNodes) {
					var charr = getChildrenByTagsName(e, tags);
					if(charr.length > 0) 
						children = children.concat(charr);
				}
			}
		}
		return children;
	}
	
	function chkVisible(elem) {
		if(elem.visible()) {
			if(!elem.hasClassName('seccion') && elem.parentNode) {
				return chkVisible(elem.parentNode);
			}
			return true;
		}
		return false;
	}

	function parentByClassName(elem, className) {
		if(!elem.hasClassName(className)) {
			if(elem.parentNode && elem.parentNode.className) {
				return parentByClassName(elem.parentNode, className);
			}
			return false;
		}
		return elem;
	}
	</script>
</head>
<body onload="init()">
	<script type="text/javascript" src="js/webcam.js"></script>
	
	<!-- Configure a few settings -->
	<script language="JavaScript">
		webcam.set_swf_url( 'libs/webcam.swf' );
		webcam.set_api_url( 'php/test.php' );
		webcam.set_quality( 90 ); // JPEG quality (1 - 100)
		webcam.set_shutter_sound( true, 'libs/shutter.mp3' ); // play shutter click sound
	</script>
	<!-- Code to handle the server response (see test.php) -->
	<script language="JavaScript">
		webcam.set_hook( 'onComplete', 'my_completion_handler' );
		var crop = {};
		var cropperInstance;
		function take_snapshot() {
			// take snapshot and upload to server
			//document.getElementById('upload_results').innerHTML = '<h1>Uploading...</h1>';
			webcam.snap();
		}
		
		function my_completion_handler(msg) {
			// extract URL out of PHP output
			if (msg.match(/(http\:\/\/\S+)/)) {
				var image_url = RegExp.$1;
				// show JPEG image in page
				crop.img = image_url;
				/*document.getElementById('testImage').src = 
					'<h1>Upload Successful!</h1>' + 
					'<h3>JPEG URL: ' + image_url + '</h3>' + 
					'<div><img id="testImage" src="' + image_url + '"></div>' +
					'<div><button onclick="doCrop()">Guardar</button></div>';*/
				document.getElementById('testImage').src = image.url;
				// reset camera for another shot
				webcam.reset();
				imagenCargada();
			}
			else alert("PHP Error: " + msg);
		}

		function startCrop() {
			if(cropperInstance) {
			  cropperInstance.remove();
			}
			cropperInstance = new Cropper.Img( 
				'testImage',
				{
					onEndCrop: onEndCrop,
					displayOnInit: true,
					onloadCoords: { x1: 0, y1: 0, x2: 150, y2: 200 },
					ratioDim: { x: 4, y: 4 }
				}
			);

		}

		function onEndCrop( coords, dimensions ) {
			crop.x = coords.x1;
			crop.y = coords.y1;
			crop.w = dimensions.width;
			crop.h = dimensions.height;
			crop.img = document.getElementById('testImage').src;
		}
		
		// basic example
		function doCrop() {
		    $('crpDiv').style.display = 'none';
		    $('finDiv').style.display = '';
		    new Ajax.Request('php/crop.php', 
		      { method:'get',
			parameters: crop,
			onSuccess: function(transport){
			    //alert(transport.responseText);
			    if(transport.responseText == 'No se pudo guardar la imagen.') {
				    alert(transport.responseText+' Procure que el formato de la imagen sea jpg, png o gif.');
			    } else {
			    	document.getElementById('final').src = transport.responseText;
			    }
			}
		      }
		    );
		}

		function upload() {
		  var frm = document.getElementById('frm1');
		  frm.submit();
		  //document.getElementById('testImage').src = this.value; if(this.value) { startCrop(); }
		}

		function imagenCargada(count) {
		  if(!count || count==0) {
		    $('selDiv').style.display = 'none';
		    $('crpDiv').style.display = '';
		    count==0;
		  }
		  var i = document.getElementById('testImage');

		  if(i.style.width || i.style.height) {
		    i.style.width= null;
		    i.style.height= null;
		  }

		  if(count > 100) {
		    if(confirm("No se pudo iniciar cropper. ¿Intentar nuevamente?")) {
		      imagenCargada();
		    }
		    return;
		  }

		  count++;

		  if(!i.complete && i.clientWidth == 0) {
		    setTimeout('imagenCargada('+count+')', 100);
		  } else {
		    var w = 320;
		    var h = 240;
		    crop.ratio = i.clientWidth>i.clientHeight?w/i.clientWidth:h/i.clientHeight;
		    var cw = (i.clientWidth*crop.ratio)+'px';
		    var ch = (i.clientHeight*crop.ratio)+'px';
		    i.style.width= cw;
		    i.style.height= ch;
		    startCrop();
		  }
		}

		function chImg() {
		  $('fotoInp').value = '';
		  $('finDiv').style.display = 'none';
		  $('crpDiv').style.display = 'none';
		  $('selDiv').style.display = '';
		}

		function dotoggle(key, value, elements) {
			for(var i = 0; i<elements.length; i++) {
				if(elements[i][key] == value) {
					elements[i].show();
				} else {
					elements[i].hide();
				}
			}
		}

		function mkCheck() {
					
			var error=[];

			//Limpio los elementos previamente chequeados
			var e = document.getElementsByClassName('error');
			for(var i = e.length; i>0; i--) {
				e[i-1].removeClassName('error');
			}

			//Chequeo la foto
			if($('final').src==null||$('final').src=='') {
				error.push('Debe cargar una foto');
				$('finDiv').addClassName('error');
				$('crpDiv').addClassName('error');
				$('selDiv').addClassName('error');
			}

			//Chequeo los campos obligatorios
			var req = $('sec_dp').getElementsByClassName('requerido');
			for(var i = 0; i<req.length; i++) {
				if(chkVisible(req[i])) {
					var inps = getChildrenByTagsName(req[i], ['input','select']);
					var vals = [];
					var ie = false;
					for(var j=0; j<inps.length; j++) {
						if(inps[j].visible() && ((inps[j].tagName.toLowerCase() == 'input' && (inps[j].value==null||inps[j].value=='')) || (inps[j].tagName.toLowerCase() == 'select' && inps[j].value==-1))) {
							inps[j].addClassName('error');
							error.push('Debe cargar campo '+req[i].getElementsByTagName('label')[0].innerHTML);
							ie=true;
						} else {
							vals.push(inps[j].value);
							
						}
					}
					if(!ie && req[i].validar && !req[i].validar(vals.join(''))) {
						for(var j=0; j<inps.length; j++) {
							inps[j].addClassName('error');
						}
						error.push('Valor no válido para el campo '+req[i].getElementsByTagName('label')[0].innerHTML);
					}
				}
			}

			//Requeridos optativos (en donde se carga un campo u otro)
			req = $('sec_dp').getElementsByClassName('requerido_opt');
			var req_ops = {};
			for(var i = 0; i<req.length; i++) {
				if(chkVisible(req[i])) {
					if(!req_ops[req[i].getAttribute('name')]) {
						req_ops[req[i].getAttribute('name')] = {elems: [], oe: true};
					}
					req_ops[req[i].getAttribute('name')].elems.push({e: req[i]});
				}
			} 
			for(var i in req_ops) {			
				for(var k=0; k<req_ops[i].elems.length; k++) {
					var inps = getChildrenByTagsName(req_ops[i].elems[k].e, ['input','select']);
					var ie=false;
					var vals = [];
					for(var j=0; j<inps.length; j++) {
						if(inps[j].visible() && ((inps[j].tagName.toLowerCase() == 'input' && (inps[j].value==null||inps[j].value=='')) || (inps[j].tagName.toLowerCase() == 'select' && inps[j].value==-1))) {
							ie=true;
							break;
						} else {
							vals.push(inps[j].value);
						}
					}
					if(!ie && req_ops[i].elems[k].e.validar && !req_ops[i].elems[k].e.validar(vals.join(''))) {
						for(var j=0; j<inps.length; j++) {
							inps[j].addClassName('error');
						}
						error.push('Valor no válido para el campo '+req_ops[i].elems[k].e.getElementsByTagName('label')[0].innerHTML);
					}
					req_ops[i].elems[k].inps = inps;
					req_ops[i].elems[k].label = req_ops[i].elems[k].e.getElementsByTagName('label')[0].innerHTML;
					if(req_ops[i].oe) {
						req_ops[i].oe = ie;
					}
				}
				if(req_ops[i].oe) {
					var labels = '';
					for(var k=0; k<req_ops[i].elems.length; k++) {
						labels += (k!=0?(k==req_ops[i].elems.length-1?' o ':', '):'')+req_ops[i].elems[k].label;
						for(var j=0; j<req_ops[i].elems[k].inps.length; j++) {
							req_ops[i].elems[k].inps[j].addClassName('error');
						}
					}
					error.push('Debe cargar por lo menos uno de los campos '+labels);
				}
			}
			
			//Chequeo campos "Otro"
			var sels = document.getElementsByTagName('select');
			for(var i = 0; i<sels.length; i++) {
				var inp = document.getElementById(sels[i].id+'t');
				if(inp && chkVisible(inp)) {
					var p = parentByClassName(inp, 'tr');
					if(!p.hasClassName('required') && (inp.value==null||inp.value=='')) {
						inp.addClassName('error');
						error.push('Debe cargar descripción del campo '+parentByClassName(sels[i],'tr').getElementsByTagName('label')[0].innerHTML);
					}
				}
			}
			
			if(error.length > 0) {
				alert(error.join("\n"));
			} else {
				var cuip = $('cuip0').value && $('cuip1').value && $('cuip2').value ? $('cuip0').value+'-'+$('cuip1').value+'-'+$('cuip2').value:'';
				new Ajax.Request('php/checkForm.php', { 
					method:'post',
					parameters: {cuip: cuip, otro: $('pasap').value},
					onSuccess: function(transport){
						var r = JSON.parse(transport.responseText);
						if(r.status == 'ok') {
							var xml = mkXML();
							new Ajax.Request('php/saveForm.php', { 
								method:'post',
								parameters: {xml: xml},
								onSuccess: function(transport){
							    	alert("Se guardaron los datos con éxito");
							    	window.location.href=window.location.href;
								},
								onFailure: function() {
									alert("Hubo un error al tratar de guardar los datos");
								}
						    });
						} else {
							alert(r.message);
						}
					},
					onFailure: function() {
						alert("Hubo un error al tratar de guardar los datos");
					}
				});
		   }
		}			
	</script>
	<style>
	  .imgcnt {
	    border: 1px solid black;
	    padding: 5px;
	    top: 0px;
	    position: absolute;
	    right: 0px;
	    height: 320px;
	    width: 320px;
	    text-align: center;
	  }
	
	.imgcnt * {
		padding: 0px !important;
	}
	
	.requerido label, .requerido_opt label {
		font-weight: bold;
	}
	
    .seccion {
      border: 1px solid black;
      margin: 15px 0px;
    }
  
    .seccion table {
      width: 100%;
    }

    .seccion table th {
      background-color: #aaaaaa;
      border: 1px solid black;
    }

    .seccion table td {
      text-align: center;
      border: 1px solid black;
    }

    .seccion .titulo {
      background-color: #007278;/*#6592af;*/
      color: white;
      font-weight: bold;
    }
    .seccion * {
      padding: 5px;
    }
    
    .tr {
    	display: table-row;
    }
    
    .td {
    	display: table-cell;
    	margin: 5px;
    }
    
    div.td {
    	padding: 5px 4px;
    }
    
    div.td * {
    	padding: 5px;
    }
    
    label.td {
    	text-align: right;
    	vertical-align: middle;
    }
    
    .error {
    	border: 1px solid red;
    }
  </style>
	<div style="width: 80%; margin: 20px auto">
		<div style="background-color: #007278; height: 92px; color: white; font-size: 30px; margin-bottom: 10px" >
			<img src="../img/logo_unc.jpg" style="vertical-align: middle; background-color: white; padding-right: 10px;"/> <span style="vertical-align: middle; margin-left: 20px">Formulario de Solicitud - Comedor Universitario</span>
      	</div>
		
		<div style='clear:both' class='seccion' id="sec_dp">
			<div class="titulo">Datos Personales</div>
			<div style="position:relative">
				<div id="selDiv" class="imgcnt">
				  <button onclick="$('snap').style.display='none';$('up').style.display='';">Subir Imagen</button> <button onclick="$('up').style.display='none';$('snap').style.display='';">Tomar Foto</button> 
			
				  <hr/>
				  <!-- Next, write the movie to the page at 320x240 -->
				  <div id="snap" style="display: none">
				  <script language="JavaScript">
					  document.write( webcam.get_html(320, 240) );
				  </script>
				  
				  <!-- Some buttons for controlling things -->
				  <hr/>
				  <form>
					  <input type=button value="Configure..." onClick="webcam.configure()">
					  &nbsp;&nbsp;
					  <input type=button value="Take Snapshot" onClick="take_snapshot()">
				  </form>
				  
				  </div>
				  <div id="up">
					  <form id="frm1" enctype="multipart/form-data" action="php/upload.php" method="POST" target="ifr1"/>
					    Subir <input id="fotoInp" name="foto" type="file" onchange="upload()"/>
					  </form>
					  <iframe name="ifr1" id="ifr1" style="visibility:hidden"></iframe>
				  </div>
				</div>
				<div id="crpDiv" class="imgcnt" style="display:none;">
				  <button onclick="chImg()">Cambiar Imagen</button> <button onclick="doCrop()">Guardar</button>
				  <hr/>
				  <img id="testImage"/>
				</div>
				<div id="finDiv" class="imgcnt" style="display:none;">
				  <button onclick="chImg()">Cambiar Imagen</button>
				  <hr/>
				  <img id="final" style="height: 240px; width: 240px; border: 1px solid black"/>	  
				</div>
				<div class="tr requerido"><label class="td" for="nombre">Nombre: </label><input class="td" type="text" name="nombre" id="nombre"/></div>
				<div class="tr requerido"><label class="td" for="apellido">Apellido: </label><input class="td" type="text" name="apellido" id="apellido"/></div>
				<div class="tr"><label class="td" for="doc">Domicilio en Córdoba: </label><input class="td" type="text" name="doc" id="doc"/></div>
				<div class="tr"><label class="td" for="ddo">Domicilio de Origen: </label><input class="td" type="text" name="ddo" id="ddo"/></div>
				<div class="tr requerido"><label class="td" for="nacionalidad">Nacionalidad: </label><input class="td" type="text" name="nacionalidad" id="nacionalidad"/></div>
				<div class="tr"><label class="td" for="tel">Teléfono: </label><input class="td" type="text" name="tel" id="tel"/></div>
				<div class="tr"><label class="td" for="cel">Celular: </label><input class="td" type="text" name="cel" id="cel"/></div>
				<div class="tr requerido_opt" name="doc"><label class="td" for="cuip">CUIP: </label><div class="td"><input type="text" name="cuip0" id="cuip0" maxlength="2" style="width: 20px; text-align:center"/>-<input type="text" name="cuip1" id="cuip1" maxlength="8" style="width: 80px; text-align:center"/>-<input type="text" name="cuip2" id="cuip2" maxlength="1" style="width: 10px; text-align:center"/> (*)</div></div>
				<div class="tr"><label class="td" for="dni">DNI: </label><input class="td" type="text" name="dni" id="dni"/></div>
				<div class="tr requerido_opt" name="doc"><label class="td" for="pasap">Pasaporte: </label><div class="td"><input  type="text" name="pasap" id="pasap"/> (*)</div></div>
				<div class="tr"><label class="td" for="mail">E-mail: </label><input class="td" type="text" name="mail" id="mail"/></div>
				<div class="tr"><label class="td" for="dep">Dependencia: </label><input class="td" type="text" name="dep" id="dep"/></div>
				<div class="tr requerido"><label class="td" for="tdc">Tipo de Comensal: </label>
					<select onchange="dotoggle('id', 'sec_'+this.value, document.getElementsByClassName('sec_toggle'))" class="td" name="tdc" id="tdc">
						<option value="-1">-- Seleccione --</option>
						<option value="0">Estudiante de Grado</option>
						<option value="1">Estudiante de Postgrado</option>
						<option value="2">Docente</option>
						<option value="3">No Docente</option>
					</select>
				</div>
			</div>
		</div>
		
		<div style="text-align: center; padding: 5px;">(*) Cargar CUIP o Pasaporte.</div>
		
		<div id="sec_0" style="display: none;" class='seccion sec_toggle'>
			<div class="titulo">Estudiante de Grado</div>
			<div class="tr">
				<label class="td" for="pba">¿Posee algún tipo de Beca de Alimentos?: </label>
				<select class="td" name="pba" id="pba">
					<option>Sí</option>
					<option selected>No</option>
				</select>
			</div>
			<div style="display: none" class="tr" id="bopr">
				<label class="td" for="bop">Su beca es otorgada por: </label>
				<div class="td">
					<select name="bop" id="bop">
						<option>Secretaría de Asuntos Estudiantiles de la UNC (S.A.E.)</option>
						<option>Prosecretaría de Relaciones Internacionales de la UNC (P.R.I.)</option>
						<option>Facultad de Lenguas</option>
						<option>Facultad de Agronomía</option>
						<option>Otro</option>
					</select> 
					<input style="display: none" type="text" name="bopt" id="bopt"/>
				</div>
			</div>
		</div>
				
		<div id="sec_1" style="display: none;" class='seccion sec_toggle'>
			<div class="titulo">Estudiante de Postgrado</div>
			<div class="tr">
				<label class="td" for="cpg">¿Que carrera de Postgrado cursa?: </label>
				<input type="text" class="td" name="cpg" id="cpg"/>
			</div>
			<div class="tr">
				<label class="td" for="roa">¿Realiza otra actividad en la U.N.C. (docencia)?: </label>
				<select class="td" name="roa" id="roa">
					<option>Sí</option>
					<option selected>No</option>
				</select>
			</div>
			<div class="tr" id="rper" style="display: none">
				<label class="td" for="rpe">¿Es remunerado por ella?: </label>
				<select class="td" name="rpe" id="rpe">
					<option>Sí</option>
					<option selected>No</option>
				</select>
			</div>
			<div class="tr" id="cgor" style="display: none">
				<label class="td" for="cgo">Cargo: </label>
				<input type="text" class="td" name="cgo" id="cgo"/>
			</div>			

		</div>
		
		<div id="sec_2" style="display: none;" class='seccion sec_toggle'>
			<div class="titulo">Docente</div>
			<div class="tr">
				<label class="td" for="cgd">¿Que cargo ocupa en la U.N.C.?: </label>
				<div class="td">
					<select name="cgd" id="cgd">
						<option>Profesor con Dedicación Exclusiva</option>
						<option>Profesor con Dedicación Semiexclusiva</option>
						<option>Jefe de Trabajos Prácticos</option>
						<option>Adjunto</option>
						<option>Otro</option>
					</select> 
					<input type="text" id="cgdt" style="display: none;"/>
				</div>
			</div>
			<div class="tr">
				<label class="td" for="dou">¿Se desempeña como docente en otra universidad?: </label>
				<div class="td">
					<select name="dou" id="dou">
						<option>Sí</option>
						<option selected>No</option>
					</select> 
				</div>
			</div>
			<div class="tr" id="ounr" style="display: none;">
				<label class="td" for="oun">¿Cual?: </label>
				<input class="td" type="text" id="dout"/>
			</div>
			<div class="tr">
				<label class="td" for="eap">¿Ejerce su actividad profesional?: </label>
				<select class="td" name="eap" id="eap">
					<option selected>Sí</option>
					<option>No</option>
				</select>
			</div>
		</div>
		
		<div id="sec_3" style="display: none;" class='seccion sec_toggle'>
			<div class="titulo">No Docente</div>
			<div class="tr">
				<label class="td" for="nea">Máximo nivel de estudios alcanzados: </label>
				<div class="td">
					<select name="nea" id="nea">
						<option>Primario Incompleto</option>
						<option>Primario Completo</option>
						<option>Secundario Incompleto</option>
						<option>Secundario Completo</option>
						<option>Terciario Incompleto</option>
						<option>Terciario Completo</option>
						<option>Universitario Incompleto</option>
						<option>Universitario Completo</option>
						<option>Otro</option>
					</select> 
					<input type="text" id="neat" style="display: none;"/>
				</div>
			</div>
			<div class="tr">
				<label class="td" for="con">¿Es contratado?: </label>
				<select class="td" name="con" id="con">
					<option>Sí</option>
					<option selected>No</option>
				</select> 
			</div>
			<div class="tr" style="display: none;" id="catr">
				<label class="td" for="cat">Categoría a la que pertenece: </label>
				<div class="td">
					<select name="cat" id="cat">
						<option>Categoría 1</option>
						<option>Categoría 2</option>
						<option>Categoría 3</option>
						<option>Categoría 4</option>
						<option>Categoría 5</option>
						<option>Categoría 6</option>
						<option>Categoría 7</option>
						<option>Otro</option>
					</select> 
					<input type="text" id="catt" style="display: none;"/>
				</div>
			</div>
			<div class="tr">
				<label class="td" for="act">Actividad que desarrolla: </label>
				<textarea class="td" name="act" id="act"></textarea>
			</div>
			<div class="tr">
				<label class="td" for="rac">¿Ha realizado o realiza algún curso brindado por la U.N.C.?: </label>
				<select class="td" name="rac" id="rac">
					<option value="1">Sí</option>
					<option value="0" selected>No</option>
				</select>
			</div>
			<div class="tr" style="display: none;" id="curr">
				<label class="td" for="cur">¿Cuales? (ubique en primer lugar el último realizado): </label>
				<textarea class="td" name="ract" id="ract"></textarea>
			</div>
		</div>

		<div style="text-align: center; padding: 5px;"><button onclick="mkCheck()">Enviar</button></div>

	</div>
</body>
</html>
