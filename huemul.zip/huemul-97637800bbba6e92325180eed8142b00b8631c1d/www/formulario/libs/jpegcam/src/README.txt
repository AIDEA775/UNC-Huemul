BUILDING INSTRUCTIONS

This library requires the AS3 Core Library (as3corelib) available from Google Code:
	http://code.google.com/p/as3corelib/

After downloading and extracting the package, place the "com" directory right here,
alongside the "Webcam.fla" and "Webcam.as" files.

You should then be able to compile the FLA into a SWF.
This requires Adobe Flash CS3 (this is a Flash 9 movie).
