<script>
<?php
$dir = 'no-cargados/img/';
$dact = dirname($_SERVER['PHP_SELF']);
if($_FILES['foto']) {
	$fname = str_replace(' ', '_', '../'.$dir.$_FILES['foto']['name']);
  if (move_uploaded_file($_FILES['foto']['tmp_name'], $fname)) {
    echo "
    var d = window.frameElement.ownerDocument;
    d.getElementById('testImage').src = '".$dact.'/'.$fname."';
    d.defaultView.imagenCargada();"; 
  } else {
    echo "alert('Ha ocurrido un error')";
  }
}
?>
</script>
