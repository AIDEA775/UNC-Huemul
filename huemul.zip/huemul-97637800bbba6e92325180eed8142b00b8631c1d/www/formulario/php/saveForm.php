<?php
if($_POST['xml']) {
	try {
		$xml = simplexml_load_string($_POST['xml']);
		$tmp = $xml->xpath('//row[@id_elems = "nombre" or @id_elems = "apellido" or @id_elems = "cuip0 cuip1 cuip2" or @id_elems = "pasap"]');
		$nombre = '';
		$search = array(' ', ',', '\'');
		foreach($tmp as $t) {
			if((string)$t)
				$nombre .= '_'.str_replace($search,'',(string) $t);
		}
		$file = date('Y-m-d').$nombre.'.xml';
		file_put_contents('../no-cargados/forms/'.$file, $_POST['xml']);
	} catch(Exception $e) {
		header("Status-Code: 500");
	}
}
?>