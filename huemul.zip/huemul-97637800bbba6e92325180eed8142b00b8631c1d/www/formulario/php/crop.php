<?php
if($_GET['img']) {
  try {
  
  $filename = '../no-cargados/img/'.basename(urldecode($_GET['img']));

  $info = pathinfo($filename);

  $filepng = '../no-cargados/img/foto_'.$info['filename'].'_'.date('YmdHis').'.png';

// Get dimensions of the original image
//#  list($current_width, $current_height) = getimagesize($filename);

  // The x and y coordinates on the original image where we
  // will begin cropping the image
//#  $left = 50;
//#  $top = 50;

  // This will be the final size of the image (e.g. how many pixels
  // left and down we will be going)
//#  $crop_width = 200;
//#  $crop_height = 200;

  // Resample the image
  if($_GET['ratio']) {
    $_GET['w'] = $_GET['w']/$_GET['ratio'];
    $_GET['h'] = $_GET['h']/$_GET['ratio'];
    $_GET['x'] = $_GET['x']/$_GET['ratio'];
    $_GET['y'] = $_GET['y']/$_GET['ratio'];
  }

  $canvas = imagecreatetruecolor(200, 200);

  //if($info['extension'] == 'jpg' || $info['extension'] == 
  $current_image = open_image($filename);

  if(!$current_image) {
    throw new Exception('No se pudo guardar la imagen.');
  }

  imagecopyresampled($canvas, $current_image, 0, 0, $_GET['x'], $_GET['y'], 200, 200, $_GET['w'], $_GET['h']);

  imagepng($canvas, $filepng, 9);

  unlink($filename);

  $url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/' . $filepng;

  echo "$url\n";
  } catch(Exception $e) {
    header('Status-Code: 500');
    echo $e->getMessage();
    error_log($e->getMessage()." ".$e->getTraceAsString());
  }
}

function open_image ($file) {
    //detect type and process accordinally
    $size=getimagesize($file);
    switch($size["mime"]){
        case "image/jpeg":
            $im = imagecreatefromjpeg($file); //jpeg file
            break;
        case "image/gif":
            $im = imagecreatefromgif($file); //gif file
     	    break;
      	case "image/png":
          $im = imagecreatefrompng($file); //png file
          break;
      	case "image/bmp":
          $im = imagecreatefromwbmp($file); //bmp file
          break;
    	default: 
          $im=false;
    }
    return $im;
}
?>
