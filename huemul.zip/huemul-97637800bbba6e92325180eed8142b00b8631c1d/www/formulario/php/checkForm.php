<?php 
$response = array('status'=>'ok', 'message'=>'');
//$ini = parse_ini_file('/home/agustin/dtc/comedor/instalacion/bases.ini',true);
$ini = parse_ini_file('../../../../../instalacion/bases.ini', true);
$ini = $ini['desarrollo comedor comedor'];
if(!($_POST['cuip'] || $_POST['otro'])) {
	$response['status'] = 'error';
	$response['message'] = 'No se proveyó un identificador válido.';
} 

if($response['status'] != 'error') {
	$conn = pg_connect("dbname=${ini['base']} user=${ini['usuario']} password=${ini['clave']} host=${ini['profile']} port=${ini['puerto']}");
	if($conn) {
		$cuip = "'".pg_escape_string(str_replace(array('-',' '), '', $_POST['cuip']))."'";
		$otro = "'".pg_escape_string($_POST['otro'])."'";
		
		$sql = "select 	1 
				from 	persona
				where	
					($cuip = '' or
					 $cuip = cuip::varchar)
					 and
					 ($otro = '' or
					 ltrim(rtrim(lower(replace(replace($otro, '.', ''), '-', '')))) = ltrim(rtrim(lower(replace(replace(otro, '.', ''), '-', ''))))
					 )";
		$result = pg_query($sql);
		$row = pg_fetch_row($result);
		if($row) {
			$response['status'] = 'error';
			$response['message'] = 'Su usuario ya está cargado en el sistema.';
		}
	}
}

if($response['status'] != 'error') {
	$search = '*'.($_POST['cuip']?$_POST['cuip'].'*':$_POST['otro']).'.xml';
	if(glob('../no-cargados/forms/'.$search)) {
		$response['status'] = 'error';
		$response['message'] = 'Usted ya llenó un formulario previamente.';
	}
}

$json = json_encode($response);
header('Contet-Type: application/json');
header('Contet-Length: '.strlen($json));
echo $json;
?>