<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Formulario - Comedor Universitario</title>

</head>
<body>

	<style>
	  .imgcnt {
	    border: 1px solid black;
	    padding: 5px;
	    top: 0px;
	    position: absolute;
	    right: 0px;
	    height: 320px;
	    width: 320px;
	    text-align: center;
	  }
	
	.imgcnt * {
		padding: 0px !important;
	}
	
	.requerido label, .requerido_opt label {
		font-weight: bold;
	}
	
    .seccion {
      border: 1px solid black;
      margin: 15px 0px;
    }
  
    .seccion table {
      width: 100%;
    }

    .seccion table th {
      background-color: #aaaaaa;
      border: 1px solid black;
    }

    .seccion table td {
      text-align: center;
      border: 1px solid black;
    }

    .seccion .titulo {
      background-color: #007278;
      color: white;
      font-weight: bold;
    }
    .seccion * {
      padding: 5px;
    }
    
    .tr {
    	display: table-row;
    }
    
    .td {
    	display: table-cell;
    	margin: 5px;
    }
    
    div.td {
    	padding: 5px 4px;
    }
    
    div.td * {
    	padding: 5px;
    }
    
    label.td {
    	text-align: right;
    	vertical-align: middle;
    }
    
    .error {
    	border: 1px solid red;
    }
  </style>
	<div style="width: 80%; margin: 20px auto">
		<div style="background-color: #007278; height: 92px; color: white; font-size: 30px; margin-bottom: 10px" >
			<img src="../img/logo_unc.jpg" style="vertical-align: middle; background-color: white; padding-right: 10px;"/> <span style="vertical-align: middle; margin-left: 20px">Formulario de Solicitud - Comedor Universitario</span>
      	</div>
		
		<div style='clear:both' class='seccion' id="sec_dp">
			<div class="titulo">Advertencia</div>
			<div style="padding: 10px; font-size: 1.5em">
LAMENTAMOS COMUNICARLE QUE MOMENTANEAMENTE NO SE PODRAN GENERAR LAS CREDENCIALES DEBIDO A TRABAJOS DE MANTENIMIENTOS.
<br/><br/>
SEPA DISCULPAR LAS MOLESTIAS E INCONVENIENTES.
			</div>
		</div>
		

</body>
</html>
