<?php
if(isset($_POST['codigo'])) {
	include_once('../php/lib/wscredencialRest.php');
	try {
		$usuario = wscredencial::validar($_POST['codigo'])->usuario;
		//$usuario->estado = 0;
	} catch(WSCredencialException $e) {
		$usuario = $e->getResp()->usuario;
		$usuario->estado = 1;
	}
	$json = json_encode($usuario);
	header('Content-Type: application/json');
	header('Content-Length: '.strlen($json));
        echo $json;
        exit;
}
$props = parse_ini_file('../propiedades.ini',true);
$props = $props[$props['ambiente']];
$lugar='https:'."//asiruws.unc.edu.ar/foto/";

?>
<html>
  <head>
    <title>Autoconsulta - Comedor Universitario - UNC</title>
    <script type="text/javascript" src="js/jquery-1.4.3.min.js"></script>
    <script type="text/javascript">
      function buscar(e, i) {
	var KeyID = (window.event) ? event.keyCode : e.keyCode;
	if(KeyID == 13) { //13: Enter
	  ajx(i);
	  return false;
	}
      }

	function ajx(i) {
		$.ajax({
			type: "POST",
		    url: "gv-ds.php",
		    dataType: "script",
		    data: "accion=4&responseHandler=setDatos&codigo="+i.value
		});
		i.value = '';
		i.focus();
	}
      
      function setDatos(data) {
	html = '';
	if(data.table.rows.length>0) {
	  var c = data.table.rows[0].c;
		//alert(data);
	  var id_cliente = c[0].v;
		//alert(id_cliente);
	  if (id_cliente) {
	    var beca = c[1].v;//ya
		//alert(beca); // da 0
	    var renovado=c[2].v;//ya
		//alert(renovado); //mayo 112016
	    var fecha_desde=c[3].v;//ya
		//alert(fecha_desde); // da null
	    var fecha_hasta=c[4].v;//ya
		//alert(fecha_hasta); // da null
	    var saldo=c[5].v;//ya
		//alert(saldo); // da 20
	    var raciones=c[6].v;//ya
		//alert(raciones); // da null
	    var sede=c[7].v;
	    var tipo_cliente=c[8].v;//ya
		//alert(tipo_cliente);
	    var tipo_beca=c[9].v;//ya
	    var tipo_monto=c[10].v;//ya
	    var beca_tc=c[11].v;//ya
	    var tipo_duracion=c[12].v;
	    var tipo_renovacion=c[13].v;
	    var max_personas_agregar=c[14].v;
	    var renovacion=c[15].v;
	    var nombre=c[16].v;//ya
	    var apellido=c[17].v;//ya
	    var cuip=c[18].v;//ya
	    var otro=c[19].v;//ya
	    var mail=c[20].v;//ya
	    var evento=c[21].v;//ya
	    var precio_x_racion=c[22].v;//ya
	    var prox_renov = c[23].v;//ya
	    var foto = c[24].v;
	    var codigo = c[25].v;
		//alert(apellido);
	    if(nombre) {
	      html += "<div style='clear:both' class='seccion'>";
	      html += "<div class='titulo'>Datos Personales</div>";
	      html += "<div style='display:table; width: 100%'>";
	      html += "<div style='display:table-cell; width:60%'>";
	      html += "<div><span style='font-weight: bold'>Nombre:</span> "+nombre+' '+apellido+"</div>";
	      html += (cuip || otro?("<div><span style='font-weight: bold'>"+(cuip?"CUIP:</span> "+cuip:"Otro Documento:</span> "+otro)+"</div>"):'');
	      html += (mail?("<div><span style='font-weight: bold'>Mail:</span> "+mail+"</div>"):'');
	      html += "</div>";
	      html += "<div style='display:table-cell; width:40%; text-align:center; vertical-align: top'>";
	      html += "<img style='margin: auto' src='";

              if(foto.substr(0,4) != 'http') {
		//alert(foto);
 		html += '<?php echo $lugar; ?>'+foto;

              } else {
		//alert(codigo);
                 html += foto;

              }
		//alert(codigo);
	      html += "' alt='Sin Foto'/>";
	      html += "</div>";
	      html += "</div>";
	      html += "</div>";
	    }

		html += "<div class='seccion'>";
		html += "<div class='titulo'>Datos de la Credencial</div>";
	    html += "<div><span style='font-weight: bold'>Fecha Expiraci&oacute;n:</span> <span id='fe'></span></div>";
		html += "</div>";
		
	    if(evento) {
	      html += "<div class='seccion'>";
	      html += "<div class='titulo'>Perteneciente al evento: "+evento+"</div>";
	      html += "</div>";
	    }

	    if(tipo_cliente) {
	      html += "<div class='seccion'>";
	      html += "<div class='titulo'>Datos de Cliente</div>";
	      html += "<div><span style='font-weight: bold'>Tipo de Cliente:</span> "+tipo_cliente+"</div>";
	      var bc = beca?beca:beca_tc;
	      if(tipo_beca == 'D') {
		var monto;	
		if(tipo_monto == '$') {
		  monto = precio_x_racion - bc;
		} else {
		  monto = precio_x_racion - (precio_x_racion * bc / 100);
		}
		html += "<div><span style='font-weight: bold'>Precio de la raci&oacute;n:</span> $"+monto+"</div>";
	      } else {
		html += "<div><span style='font-weight: bold'>Tipo de Beca:</span> "+bc+" Raciones</div>";
	      }
	      html += (saldo?("<div><span style='font-weight: bold'>Saldo:</span> "+saldo+"</div>"):'');
	      html += (raciones?("<div><span style='font-weight: bold'>Raciones:</span> "+raciones+"</div>"):'');
	      if(tipo_duracion == 'F') {
		html += "<div><span style='font-weight: bold'>V&aacute;lido Desde:</span> "+(fecha_desde?fecha_desde.getDate()+'/'+(fecha_desde.getMonth()+1)
		+'/'+fecha_desde.getFullYear():'')+"</div>";
		html += "<div><span style='font-weight: bold'>V&aacute;lido Hasta:</span> "+(fecha_hasta?fecha_hasta.getDate()+'/'+(fecha_hasta.getMonth()+1)
		+'/'+fecha_hasta.getFullYear():'')+"</div>";
	      } else if(tipo_duracion == 'R') {
		var color=(new Date() >= prox_renov?" style='color: red'":'');
		html += "<div><span style='font-weight: bold'>&Uacute;ltima Renovaci&oacute;n:</span> "+renovado.getDate()+'/'+(renovado.getMonth()+1)+'/'
		+renovado.getFullYear()+"</div>";
		html += "<div"+color+"><span style='font-weight: bold'>Pr&oacute;xima Renovaci&oacute;n:</span> "+prox_renov.getDate()+'/'+(prox_renov.getMonth()+1)
		+'/'+prox_renov.getFullYear()+"</div>";
	      }
	      html += "</div>";
	    }

	    if(max_personas_agregar != 0) {
	      html += "<div class='seccion' id='pa'>";
	      html += "<div class='titulo'>Personas Agregadas</div>";
	      html += "</div>";
	    }
		$.ajax({
			type: "POST",
		    data: {
			    codigo: codigo
		    },
		    success: function(data) {
			    var f = data.fechaExpiracion.split('T')[0].split('-');
			    $('#fe').html(f[2]+'/'+f[1]+'/'+f[0]);
			    if(data.estado) {
			    	$('#fe').css('color', 'red');
			    }
		    }
		});
	  }
	}
	var datos = document.getElementById('datos');
	datos.innerHTML = html;

	if(max_personas_agregar && max_personas_agregar != 0) {
	  $.ajax({
	    type: "POST",
	    url: "gv-ds.php",
	    dataType: "script",
	    data: "accion=4&responseHandler=setPA&p="+id_cliente+"&m="+max_personas_agregar
	  });
	}
      }

      function setPA(data) {
	var pa = document.getElementById('pa');
	if(data.table.rows.length == 0) {
	  pa.innerHTML += "<div>Usted no posee personas agregadas.</div>";
	} else {
	  html = "<table><tr><th>Nombre</th><th>CUIP</th><th>Otro Doc.</th><th>Mail</th></tr>";
	  for(var i=0; i<data.table.rows.length; i++) {
	    html += "<tr>";
	    html += "<td>"+data.table.rows[i].c[0].v+" "+data.table.rows[i].c[1].v+"</div>";
	    html += "<td>"+(data.table.rows[i].c[2].v?data.table.rows[i].c[2].v:'')+"</div>";
	    html += "<td>"+(data.table.rows[i].c[3].v?data.table.rows[i].c[3].v:'')+"</div>";
	    html += "<td>"+(data.table.rows[i].c[4].v?data.table.rows[i].c[4].v:'')+"</div>";
	    html += "</tr>";
	  }
	  html += "</table>";
	  pa.innerHTML += html;
	}
      }

    </script>
  <style type="text/css">
    .seccion {
      border: 1px solid black;
      margin: 15px 0px;
    }
  
    .seccion table {
      width: 100%;
    }

    .seccion table th {
      background-color: #aaaaaa;
      border: 1px solid black;
    }

    .seccion table td {
      text-align: center;
      border: 1px solid black;
    }

    .seccion .titulo {
      background-color: #007278; /*#6592af;*/
      color: white;
      font-weight: bold;
    }
    .seccion * {
      padding: 5px;
    }
  </style>
  </head>
  <body>
    <div style="width: 80%; margin: 20px auto">
      <div style="background-color: #007278; height: 92px; color: white; font-size: 30px; margin-bottom: 10px" >
	<img src="img/logo_unc.jpg" style="vertical-align: middle;background-color: white; padding-right: 10px;"/> <span style="vertical-align: middle; margin-left: 20px">Autoconsulta - Comedor Universitario</span>
      </div>
      <div style="text-align: center">
	<input type="text" id="codigo" onkeypress="buscar(event, this)"/> <input type="button" onclick="ajx(document.getElementById('codigo'))" value="Enviar"/> 
      </div>
      <div style="text-align: center">Introduzca su c&oacute;digo de barra.</div>
      <div id="datos">
      </div>
    </div>
  </body>
</html>
