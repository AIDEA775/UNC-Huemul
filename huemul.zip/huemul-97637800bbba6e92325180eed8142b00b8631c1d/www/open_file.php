<?php
$finfo = new finfo();
file_put_contents("/tmp/fo_log", "abriendo archivo {$_GET['f']}\n");
$mime = $finfo->file($_GET['f'], FILEINFO_MIME);
file_put_contents("/tmp/fo_log", "mime {$mime}\n", FILE_APPEND);
$file = file_get_contents($_GET['f']);
$longitud = strlen($file);
$name = basename($_GET['f']);
file_put_contents("/tmp/fo_log", "Cabeceras:\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Cache-Control: private\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Content-type: $mime\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Content-Length: $longitud\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Content-Disposition: attachment; filename=$name\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Pragma: no-cache\n", FILE_APPEND);
file_put_contents("/tmp/fo_log", "Expires: 0\n", FILE_APPEND);
header("Cache-Control: private");
header("Content-type: $mime");
header("Content-Length: $longitud");
header("Content-Disposition: attachment; filename=$name");
//header("Accept-Ranges: $longuitud");
header("Pragma: no-cache");
header("Expires: 0");
echo $file;
unlink($_GET['f']);
?>