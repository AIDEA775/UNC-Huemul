<html>
  <head>
    <title>Comedor Unviersitario - Cocina</title>
    <script type="text/javascript" src="http://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart", "gauge"]});
      google.setOnLoadCallback(handleChart);
      var query, chart, gauge;
      function handleChart() {
		if(!query) {
		  //query = new google.visualization.Query('http://comedor.unc.edu.ar/gv-ds.php?accion=1');
		  query = new google.visualization.Query('/comedor/1.0/gv-ds.php?accion=1');
		  chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
		  gauge = new google.visualization.Gauge(document.getElementById('gauge_div'));
		}
		//var opts = {sendMethod: 'xhr'};
		//query.setRefreshInterval(5);
		query.send(drawChart);
	
      }
      function drawChart(response) {
		if (response.isError()) {
		  alert('Error in query: ' + response.getMessage() + ' ' + response.getDetailedMessage());
		  return;
		}
		var data = response.getDataTable();
		var total = 0;
		for(var i=0; i<data.getNumberOfRows(); i++) {
		  total += data.getValue(i, 1);
		}
		document.getElementById('total').innerHTML = total;
		total = Number((total*100/document.getElementById('raciones').value).toFixed(2));
		if(data.getNumberOfRows() > 0) chart.draw(data, {height: 300, title: 'Cantidad de Raciones'});
		var gdata = new google.visualization.DataTable();
		gdata.addColumn('string', 'Label');
		gdata.addColumn('number', 'Value');
		gdata.addRows(1);
		gdata.setValue(0, 0, '% Raciones');
		gdata.setValue(0, 1, total);
		/*var rt = Number(document.getElementById('raciones').value);
		var rf = rt*9/10;
		var yf = rt*3/4;*/
	        var options = {height: 250, redFrom: 90, redTo: 100, yellowFrom:75, yellowTo: 90, greenFrom: 0, greenTo: 75, minorTicks: 5};
	        gauge.draw(gdata, options);
		setTimeout('handleChart()',5000);
      }
    </script>
  </head>
  <body>
    <div style="float:left; width: 60%" id="chart_div"></div>
    <div style="float:left;"><label for="raciones">Cantidad de raciones: </label><input id="raciones" value="1500"/><div id="gauge_div"></div><div style="margin-left: 40px;">Total de Raciones: <span id="total" style='font-weight: bold'></span></div></div>
  </body>
</html>
