<?php
$props = parse_ini_file('../propiedades.ini',true);
$props = $props[$props['ambiente']];
//$alfresco_url = "http://alfresco.unc.edu.ar:8080/alfresco/service/api";
/*$alfresco_url = "http://alfresco-test.unc.edu.ar:8080/alfresco/service/api";
$alfresco_usr = "admin";
$alfresco_pwd = "clalf05";*/
$o = json_decode(file_get_contents($props['alfresco_url']."/login?u=".$props['alfresco_usr']."&pw=".$props['alfresco_pwd']."&format=json"));
$fu = array('url'=>$props['alfresco_url']."/node/content/workspace/SpacesStore/", 'ticket'=>$o?$o->data->ticket:''); 
?>
<html>
  <head>
    <title>Molinetes - Comedor Universitario - UNC</title>
    <script src="js/jquery-1.4.3.min.js"></script>
    <script type="text/javascript">
      var lastCode = {};
      lastCode['55000081']='';
      lastCode['55000080']='';
      function buscar() {
          setInterval(function() {
              $.ajax({
				  type: "GET",
				  url: "ultimo-codigo.php",
				  complete: function(xhr, st) {
				    if(st == 'success') {
				      var doc=xhr.responseXML.documentElement;
				      var cods = doc.getElementsByTagName('codigo');
				      for(var i = 0; i<cods.length; i++) {
						var m = cods[i].getAttribute('molinete');
						var s = cods[i].getAttribute('status');
						var a = cods[i].getAttribute('accion');
						var code = cods[i].textContent;
						
						var datos = document.getElementById('datos');
						if(lastCode[m] != code) {
							var div = document.createElement('div');
							div.className = a;
							div.code = code;
							$(div).click(function() {
								b(this.code);
							});
							var div1 = document.createElement('div');
							div1.innerHTML = 'Código: '+code;
							div.appendChild(div1); 
							var div2 = document.createElement('div');
							div2.innerHTML = 'Estado: '+s;
							div.appendChild(div2);
							
						  	$('#'+m).prepend(div);
						  	
						  	lastCode[m] = code;
						}
				      }
				    }
				  }
			  })
          }, 500);
      }

      function b(valor) {
	  $.ajax({
	    type: "POST",
	    url: "gv-ds.php",
	    dataType: "script",
	    data: "accion=4&responseHandler=setDatos&codigo="+valor
	  });
      }

      function setDatos(data) {
    	  if(data.table.rows.length>0) {
          	  $('#overlay').show();
			  html = '';
			  var c = data.table.rows[0].c;
			  var id_cliente = c[0].v;
			  if (id_cliente) {
			    var beca = c[1].v;//ya
			    var renovado=c[2].v;//ya
			    var fecha_desde=c[3].v;//ya
			    var fecha_hasta=c[4].v;//ya
			    var saldo=c[5].v;//ya
			    var raciones=c[6].v;//ya
			    var tipo_cliente=c[7].v;//ya
			    var tipo_beca=c[8].v;//ya
			    var tipo_monto=c[9].v;//ya
			    var beca_tc=c[10].v;//ya
			    var tipo_duracion=c[11].v;
			    var tipo_renovacion=c[12].v;
			    var max_personas_agregar=c[13].v;
			    var renovacion=c[14].v;
			    var nombre=c[15].v;//ya
			    var apellido=c[16].v;//ya
			    var cuip=c[17].v;//ya
			    var otro=c[18].v;//ya
			    var mail=c[19].v;//ya
			    var evento=c[20].v;//ya
			    var precio_x_racion=c[21].v;//ya
			    var prox_renov = c[22].v;//ya
			    var foto = c[23].v;
		
			    if(nombre) {
			      html += "<div style='clear:both' class='seccion'>";
			      html += "<div class='titulo'>Datos Personales</div>";
			      html += "<div style='display:table; width: 100%'>";
			      html += "<div style='display:table-cell; width:60%'>";
			      html += "<div><span style='font-weight: bold'>Nombre:</span> "+nombre+' '+apellido+"</div>";
			      html += (cuip || otro?("<div><span style='font-weight: bold'>"+(cuip?"CUIP:</span> "+cuip:"Otro Documento:</span> "+otro)+"</div>"):'');
			      html += (mail?("<div><span style='font-weight: bold'>Mail:</span> "+mail+"</div>"):'');
			      html += "</div>";
			      html += "<div style='display:table-cell; width:40%; text-align:center'>";
			      html += "<img style='margin: auto; width: 50%; vertical-align: top;' src='";
			      if(foto.substr(0,4) != 'http') {
			    	  //$foto = $fu['url'].$usuario->foto."?alf_ticket=".$fu['ticket'];
				      html += '<?php echo $fu['url']; ?>'+foto+'?alf_ticket=<?php echo $fu['ticket']; ?>';
			      } else {
				      html += foto;
			      }
			      html += "' alt='Sin Foto'/>";
			      html += "</div>";
			      html += "</div>";
			      html += "</div>";
			    }
		
			    if(evento) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Perteneciente al evento: "+evento+"</div>";
			      html += "</div>";
			    }
		
			    if(tipo_cliente) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Datos de Cliente</div>";
			      html += "<div><span style='font-weight: bold'>Tipo de Cliente:</span> "+tipo_cliente+"</div>";
			      var bc = beca?beca:beca_tc;
			      if(tipo_beca == 'D') {
					var monto;	
					if(tipo_monto == '$') {
					  monto = precio_x_racion - bc;
					} else {
					  monto = precio_x_racion - (precio_x_racion * bc / 100);
					}
					html += "<div><span style='font-weight: bold'>Precio de la raci&oacute;n:</span> $"+monto+"</div>";
					html += "<div><span style='font-weight: bold'>Saldo:</span> $"+saldo+"</div>";
			      } else {
					html += "<div><span style='font-weight: bold'>Tipo de Beca:</span> "+bc+" Raciones</div>";
					html += "<div><span style='font-weight: bold'>Raciones:</span> "+raciones+"</div>";
					html += (saldo?("<div><span style='font-weight: bold'>Saldo:</span> $"+saldo+"</div>"):'');
			      }
			      if(tipo_duracion == 'F') {
					html += "<div><span style='font-weight: bold'>V&aacute;lido Desde:</span> "+fecha_desde.getDate()+'/'+(fecha_desde.getMonth()+1)+'/'+fecha_desde.getFullYear()+"</div>";
					html += "<div><span style='font-weight: bold'>V&aacute;lido Hasta:</span> "+fecha_hasta.getDate()+'/'+(fecha_hasta.getMonth()+1)+'/'+fecha_hasta.getFullYear()+"</div>";
			      } else if(tipo_duracion == 'R') {
					var color=(new Date() >= prox_renov?" style='color: red'":'');
					html += "<div><span style='font-weight: bold'>&Uacute;ltima Renovaci&oacute;n:</span> "+renovado.getDate()+'/'+(renovado.getMonth()+1)+'/'+renovado.getFullYear()+"</div>";
					html += "<div"+color+"><span style='font-weight: bold'>Pr&oacute;xima Renovaci&oacute;n:</span> "+prox_renov.getDate()+'/'+(prox_renov.getMonth()+1)+'/'+prox_renov.getFullYear()+"</div>";
			      }
			      html += "</div>";
			    }
		
			    if(max_personas_agregar != 0) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Personas Agregadas</div>";
			      html += "<div  id='pa_"+id_cliente+"'></div>";
			      html += "</div>";
			    }
		
			  }
			$('#datos').html(html);
		
			if(max_personas_agregar && max_personas_agregar != 0) {
			  $.ajax({
			    type: "POST",
			    url: "gv-ds.php",
			    dataType: "script",
			    data: "accion=4&responseHandler=setPA&p="+id_cliente+"&m="+max_personas_agregar
			  });
			}
    	  } else {
        	  alert('No se encontraron datos');
    	  }
      }

      function setPA(data) {
	//var pa = document.getElementById('pa');
	if(data.table.rows.length > 0) {
	  var pa = document.getElementById('pa_'+data.table.rows[0].c[5].v);
	  html = "<table><tr><th>Nombre</th><th>CUIP</th><th>Otro Doc.</th><th>Mail</th></tr>";
	  for(var i=0; i<data.table.rows.length; i++) {
	    html += "<tr>";
	    html += "<td>"+data.table.rows[i].c[0].v+" "+data.table.rows[i].c[1].v+"</div>";
	    html += "<td>"+(data.table.rows[i].c[2].v?data.table.rows[i].c[2].v:'')+"</div>";
	    html += "<td>"+(data.table.rows[i].c[3].v?data.table.rows[i].c[3].v:'')+"</div>";
	    html += "<td>"+(data.table.rows[i].c[4].v?data.table.rows[i].c[4].v:'')+"</div>";
	    html += "</tr>";
	  }
	  html += "</table>";
	  pa.innerHTML += html;
	}
      }

    </script>
  <style type="text/css">
    .seccion {
      border: 1px solid black;
      margin: 15px 0px;
    }
  
    .seccion table {
      width: 100%;
    }

    .seccion table th {
      background-color: #aaaaaa;
      border: 1px solid black;
    }

    .seccion table td {
      text-align: center;
      border: 1px solid black;
    }

    .seccion .titulo {
      background-color: #6592af;
      color: white;
      font-weight: bold;
    }
    .seccion * {
      padding: 5px;
    }
    
    .pase, .no_pase {
    	border: 1px solid black;
		margin: 5px;
		padding: 5px;
		cursor: pointer;
    }
    
    .pase {
    	background-color: #AFA;
    }
    
    .no_pase {
    	background-color: #FAA;
    }
    .mol_tit {
    	background-color: #014268; 
    	padding: 5px; 
    	font-weight: bold;
    	color: white; 
    	margin-bottom: 3px;
    }
    
    #overlay {
    	position: absolute;
    	display: none;
    	top: 0px;
    	left: 0px;
    	right: 0px;
    	background-color: white;
    }
    
    #datos {
    	overflow: auto;
    }
  </style>
  </head>
  <body onload="buscar()">
    <!--div style="width: 80%; margin: 20px auto">
      <div style="float: left; width: 40%">
	<img id="img"/>
      </div>
      <div style="float: right; width: 60%" id="datos">
      </div>
    </div-->

    <div style="width: 80%; margin: 20px auto; position: relative">
      <div style="background-color: #014268; height: 100px; color: white; font-size: 30px; margin-bottom: 10px" >
		<img src="img/logo_unc.jpg" style="vertical-align: middle"/> <span style="vertical-align: middle; margin-left: 20px">Molinetes - Comedor Universitario</span>
      </div>
      <div style="width:49%; float: left; border: 1px solid black">
      	<div class="mol_tit">Molinete 1</div>
      	<div id="55000081"></div>
      </div>
      <div style="width:49%; float: right; border: 1px solid black">
      	<div class="mol_tit">Molinete 2</div>
      	<div id="55000080"></div>
      </div>
      <div id="overlay">
      	<div class="mol_tit" style="text-align: right"><span style="cursor: pointer" onclick="$('#overlay').hide()">Cerrar</span></div>
      	<div id="datos"></div>
      </div>
    </div>
  </body>
</html>