<?php
$codigos = new SQLite3('../comedor.db');
$codigos->query("create table if not exists codigos (codigo text, fecha text default current_date)");
if(isset($_GET['file'])) {
	$res = $codigos->query("select codigo from codigos;");
	header('Content-Type: text/plain');
	header('Content-Disposition: attachment; filename=clientes_'.date('Y-m-d_H-i').'.txt');
	while($row = $res->fetchArray(SQLITE3_ASSOC)) {
		echo $row['codigo']."\n";
	}
	$codigos->query('delete from codigos');
	exit;
} elseif(isset($_POST['codigo']) || isset($_POST['sync'])) {
	include_once '../rest.php';
	$ini = parse_ini_file('../comedor.ini',true);
	$ws = false;
	$cs = '';
	$rest = new rest($ini['rest']['url'], $ini['rest']['port']);
	foreach ($ini['database'] as $k=>$v) {
		if($k != 'number' && $k != 'sleep') {
			$cs .= $k.'=\''.$v.'\' ';
		}
	}

	$pgconn = count($rest->request('/custom', rest::GET, array("q"=>json_encode(array("select"=>array('1 as a')))))) > 0;
	
	function sync() {
		global $codigos, $pgconn, $rest;
		$res = $codigos->query('select codigo, fecha from codigos');
		while($row = $res->fetchArray(SQLITE3_ASSOC)) {
			$rest->request('/f/paso_molinete', rest::POST, array("codigo"=>$row['codigo'], "sync"=>'true', "fecha"=>$row['fecha']));
		}
		$codigos->query('delete from codigos');
	}
	
	function check($code) {
		global $ini, $ws;
		
		$i = $ini['codechk'];
		try {
			if(!$ws) {
				$ws = new SoapClient($i['wsdl'], array(
						"trace"=>1,
						"exceptions"=>1
				));
				$resp = $ws->check(array("arg0"=>$code))->return;
				return array('st'=>$resp->estado, 'msg'=>$resp->mensaje);
			}
		} catch(Exception $e) {
			return array('st'=>0, 'msg'=>'No se pudo chequear el c&oacute;digo.');
		}
	}
	
	if(isset($_POST['codigo'])) {
		$a=array();
		if(isset($_POST['getData'])) {
			$doLocal = false;
			if($pgconn) {
				$json = '
{
	"select": [
		"c.id_cliente",
		"c.beca",
		"c.renovado",
		"coalesce(c.fecha_desde, e.fecha_desde) as fecha_desde",
		"coalesce(c.fecha_hasta, e.fecha_hasta) as fecha_hasta",
		"c.saldo",
		"c.raciones",
		"tc.descripcion as tipo_cliente",
		"tc.tipo_beca",
		"tc.tipo_monto",
		"tc.beca as beca_tc",
		"tc.tipo_duracion",
		"tc.tipo_renovacion",
		"tc.max_personas_agregar",
		"tc.renovacion",
		"p.nombre",
		"p.apellido",
		"p.cuip",
		"p.otro",
		"p.mail",
		"e.nombre as evento",
		"(select precio_x_racion from fq_parametros_generales() where obsoleto = false limit 1) as precio_x_racion",
		"case when tc.tipo_duracion = \'R\' then case when tc.tipo_renovacion = \'F\' then case when renovacion ~ \'^[0-9][0-9]?/[0-9][0-9]$\' then case when current_timestamp <= (renovacion||\'/\'||date_part(\'year\', current_timestamp))::date then (renovacion||\'/\'||date_part(\'year\', current_timestamp))::date else (renovacion||\'/\'||date_part(\'year\', (current_timestamp + interval \'1 year\')))::date end else case when current_timestamp <= (renovacion||\'/\'||date_part(\'month\', current_timestamp)||\'/\'||date_part(\'year\', current_timestamp))::date then (renovacion||\'/\'||date_part(\'month\', current_timestamp)||\'/\'||date_part(\'year\', current_timestamp))::date else (renovacion||\'/\'||date_part(\'month\', (current_timestamp + interval \'1 month\'))||\'/\'||date_part( \'year\', (current_timestamp + interval \'1 month\')))::date end end else (renovado + renovacion::interval)::date end else null end as prox_renov",
		"p.foto"
	],
	"from": [
		{"name": "cliente", "alias": "c"},
		{"name": "tipo_cliente", "alias": "tc", "rel": "inner join", "on": {"rel": "and", "ops":["tc.id_tipo_cliente = c.id_tipo_cliente", "tc.obsoleto = false"]}},
		{"name": "persona", "alias": "p", "rel": "left join", "on": {"rel": "and", "ops":["c.id_persona = p.id_persona", "p.obsoleto = false"]}},
		{"name": "evento", "alias": "e", "rel": "left join", "on": {"rel": "and", "ops":["e.id_evento = c.id_evento", "e.obsoleto = false"]}}
	],
	"where": "c.codigo = $1",
	"params": ["'.$_POST['codigo'].'"]
}';
				$a = $rest->request('/custom', rest::GET, array("q"=>$json));
				if(isset($a[0])) $a=$a[0];
			}
		} elseif(isset($_POST['p'])) {
			$json = array(
				'select' => array(
					'p.nombre',
					'p.apellido',
					'p.cuip',
					'p.otro',
					'p.mail',
					'$1::integer as id_cliente'),
				'from'=>array(
					array('name'=>'persona', 'alias'=>'p'),
					array('name'=>'agregado', 'alias'=>'a', 'rel'=>'inner join', 'on'=>'p.id_persona = a.id_persona')	
				),
				'where'=>array(
					'rel'=>'and',
					'ops'=>array(
						'p.obsoleto = false',
						'a.obsoleto = false',
						'a.id_cliente = $1'
					)
				),
				'orderBy'=>array('a.orden'),
				'params'=>array($_POST['p'])
			);
			if($_POST['m'] > 0) {
				$json['limit']='$2';
				$json['params'][]=$_POST['m'];
			}
			$a = $rest->request('/custom', rest::GET, array("q"=>json_encode($json)));
		}else {
			$doLocal = true;
			if($pgconn) {
				sync();
				//Tengo conexión con la base
				$f = check($_POST['codigo']);
				if($f['st'] > 0) {
					$a = array('codigo'=> $_POST['codigo'], 'data' => 'no_pase', 'status'=>$f['msg']);
					$doLocal = false;
				} else {
					$a = $rest->request('/f/paso_molinete', rest::POST, array("codigo"=>$_POST['codigo'], "sync"=>'false'));
					if(count($a) > 0) {
						$a=$a[0];
						$doLocal = false;
					}
				}
				$a['conn'] = true;
			} 
			
			if($doLocal) {
				//No tengo conexión con la base
				$a = array('codigo'=>$_POST['codigo'], 'conn'=>false);
				$r = $codigos->query("insert into codigos (codigo) values ('{$_POST['codigo']}')");
				if(!$r) {
					$a['data']='no_pase';
					$a['status']='Error en la base. Int&eacute;ntelo nuevamente.';
				} else {
					$a['data']='pase';
					$a['status']='Ok';
				}
			}
		}
	} elseif(isset($_POST['sync'])) {
		if($pgconn) {
			//Tengo conexión con la base
			sync();
		}
		$a=array('conn'=>isset($pgconn)&&$pgconn!=false);
	} 
	header('Content-Type: application/json');
	echo json_encode($a);
} else {
?>
<html>
  <head>
    <title>Molinete - Comedor Universitario - UNC</title>
    <!-- meta http-equiv="content-type" content="text/html;charset=iso-8859-1" /-->
    <script src="js/jquery-1.4.3.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
		var lastCode = '';
		interval = '', loop=0, wait=5;
		$('#codigo').keypress(function(evt) {
		    if(evt.which==13) {
		      var input = this;
		      $.ajax({
			type: "POST",
			data: {codigo: this.value},
			success: function(data, xhr, st) {
			  startConn(data.conn);
			  if(lastCode != data.codigo) {
			    var div = document.createElement('div');
			    div.className = data.data;
			    div.codigo = data.codigo;
			    $(div).click(function() {
				    b(this.codigo);
			    });
			    var div1 = document.createElement('div');
			    div1.innerHTML = 'C&oacute;digo: '+data.codigo;
			    div.appendChild(div1); 
			    var div2 = document.createElement('div');
			    div2.innerHTML = 'Estado: '+data.status;
			    div.appendChild(div2);
			    
			    $('#clientes').prepend(div);
			    
			    lastCode = data.codigo;
			  }
			  input.value = '';
			}
		      });
		    }
		});
	
		$('#sync').click(function() {
		  loop=0, wait=5;
		  doQuery();
		});

		$('#file').click(function() {
			window.open('index.php?file=true');
		});		
      });

      function startConn(hasConn) {
		$('#dbconn').css('display', hasConn?'none':'');
		$('#seg').html(wait - loop);
		if(!window.interval) {
		  interval = setInterval(function() {
		    if(loop == wait) {
		      wait = wait*2>=600?600:wait*2;
		      loop = 0;
		      doQuery();
		    }
		    loop++;
		    $('#seg').html(wait - loop);
		  }, 1000);
		} else if(hasConn) {
		  clearInterval(interval);
		  loop=0;
		  wait=5;
		  interval = false;
		} 
	      }
	
	      function doQuery() {
		$.ajax({
		  type: 'POST',
		  async: false,
		  data: {sync: true},
		  success: function(data, xhr, st) {
		    startConn(data.conn);
		  }
		});
      }

      function b(valor) {
	  $.ajax({
	    type: "POST",
	    data: {codigo: valor, getData: true},
	    success: function(data, xhr, status) {
    		if (data && data.id_cliente) {
		    	$('#overlay').show();
		    	html = '';
			    	
			    if(data.nombre) {
			      html += "<div style='clear:both' class='seccion'>";
			      html += "<div class='titulo'>Datos Personales</div>";
			      html += "<div style='display:table; width: 100%'>";
			      html += "<div style='display:table-cell; width:60%'>";
			      html += "<div><span style='font-weight: bold'>Nombre:</span> "+data.nombre+' '+data.apellido+"</div>";
			      html += (data.cuip || data.otro?("<div><span style='font-weight: bold'>"+(data.cuip?"CUIP:</span> "+data.cuip:"Otro Documento:</span> "+data.otro)+"</div>"):'');
			      html += (data.mail?("<div><span style='font-weight: bold'>Mail:</span> "+data.mail+"</div>"):'');
			      html += "</div>";
			      html += "<div style='display:table-cell; width:40%; text-align:center'>";
			      html += "<img style='margin: auto; width: 50%; vertical-align: top;' src='"+data.foto+"' alt='Sin Foto'/>";
			      html += "</div>";
			      html += "</div>";
			      html += "</div>";
			    }
		
			    if(data.evento) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Perteneciente al evento: "+data.evento+"</div>";
			      html += "</div>";
			    }
		
			    if(data.tipo_cliente) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Datos de Cliente</div>";
			      html += "<div><span style='font-weight: bold'>Tipo de Cliente:</span> "+data.tipo_cliente+"</div>";
			      var bc = data.beca?data.beca:data.beca_tc;
			      if(data.tipo_beca == 'D') {
					var monto;	
					if(data.tipo_monto == '$') {
					  monto = data.precio_x_racion - bc;
					} else {
					  monto = data.precio_x_racion - (data.precio_x_racion * bc / 100);
					}
					var color=(data.saldo <= 0?" style='color: red'":'');
					html += "<div><span style='font-weight: bold'>Precio de la raci&oacute;n:</span> $"+monto+"</div>";
					html += "<div"+color+"><span style='font-weight: bold'>Saldo:</span> $"+data.saldo+"</div>";
			      } else {
			    	var color=(data.raciones <= 0?" style='color: red'":'');
					html += "<div><span style='font-weight: bold'>Tipo de Beca:</span> "+bc+" Raciones</div>";
					html += "<div"+color+"><span style='font-weight: bold'>Raciones:</span> "+data.raciones+"</div>";
					html += (data.saldo?("<div><span style='font-weight: bold'>Saldo:</span> $"+data.saldo+"</div>"):'');
			      }
			      if(data.tipo_duracion == 'F') {
			    	var color=(new Date() >= new Date(data.fecha_hasta)?" style='color: red'":'');
					html += "<div><span style='font-weight: bold'>V&aacute;lido Desde:</span> "+data.fecha_desde/*.getDate()+'/'+(fecha_desde.getMonth()+1)+'/'+fecha_desde.getFullYear()*/+"</div>";
					html += "<div"+color+"><span style='font-weight: bold'>V&aacute;lido Hasta:</span> "+data.fecha_hasta/*.getDate()+'/'+(fecha_hasta.getMonth()+1)+'/'+fecha_hasta.getFullYear()*/+"</div>";
			      } else if(data.tipo_duracion == 'R') {
					var color=(new Date() >= new Date(data.prox_renov)?" style='color: red'":'');
					html += "<div><span style='font-weight: bold'>&Uacute;ltima Renovaci&oacute;n:</span> "+data.renovado/*.getDate()+'/'+(renovado.getMonth()+1)+'/'+renovado.getFullYear()*/+"</div>";
					html += "<div"+color+"><span style='font-weight: bold'>Pr&oacute;xima Renovaci&oacute;n:</span> "+data.prox_renov/*.getDate()+'/'+(prox_renov.getMonth()+1)+'/'+prox_renov.getFullYear()*/+"</div>";
			      }
			      html += "</div>";
			    }
		
			    if(data.max_personas_agregar != 0) {
			      html += "<div class='seccion'>";
			      html += "<div class='titulo'>Personas Agregadas</div>";
			      html += "<div  id='pa_"+data.id_cliente+"'></div>";
			      html += "</div>";
			    }
				$('#datos').html(html);
		
			if(data.max_personas_agregar && data.max_personas_agregar != 0) {
			  var id = data.id_cliente;
			  $.ajax({
			    type: "POST",
			    data: {codigo: valor, p: id, m: data.max_personas_agregar},
			    success: function(data, xhr, status) {
				    if(data.length) {
				    	var html = "<table><tr><th>Nombre</th><th>CUIP</th><th>Otro Doc.</th><th>Mail</th></tr>";
				    	for(var i = 0; i<data.length; i++) {
				    		html += "<tr>";
				    	    html += "<td>"+data[i].nombre+" "+data[i].apellido+"</div>";
				    	    html += "<td>"+(data[i].cuip?data[i].cuip:'')+"</div>";
				    	    html += "<td>"+(data[i].otro?data[i].otro:'')+"</div>";
				    	    html += "<td>"+(data[i].mail?data[i].mail:'')+"</div>";
				    	    html += "</tr>";
				    	}
				    	$('#pa_'+id).html(html);
				    }
			    }
			  });
			}
    	  } else {
        	  alert('No se encontraron datos');
    	  }
	    }
	  });
      }
    </script>
  <style type="text/css">
    .seccion {
      border: 1px solid black;
      margin: 15px 0px;
    }
  
    .seccion table {
      width: 100%;
    }

    .seccion table th {
      background-color: #aaaaaa;
      border: 1px solid black;
    }

    .seccion table td {
      text-align: center;
      border: 1px solid black;
    }

    .seccion .titulo {
      background-color: #6592af;
      color: white;
      font-weight: bold;
    }
    .seccion * {
      padding: 5px;
    }
    
    .pase, .no_pase {
    	border: 1px solid black;
		margin: 5px;
		padding: 5px;
		cursor: pointer;
    }
    
    .pase {
    	background-color: #AFA;
    }
    
    .no_pase {
    	background-color: #FAA;
    }
    .mol_tit {
    	background-color: #014268; 
    	padding: 5px; 
    	font-weight: bold;
    	color: white; 
    	margin-bottom: 3px;
    }
    
    #overlay {
    	position: absolute;
    	display: none;
    	top: 0px;
    	left: 0px;
    	right: 0px;
    	background-color: white;
    }
    
    #datos {
    	overflow: auto;
    }
  </style>
  </head>
  <body onLoad="$('#codigo').focus()">
    <!--div style="width: 80%; margin: 20px auto">
      <div style="float: left; width: 40%">
	<img id="img"/>
      </div>
      <div style="float: right; width: 60%" id="datos">
      </div>
    </div-->

    <div style="width: 80%; margin: 20px auto; position: relative">
      <div style="background-color: #014268; height: 100px; color: white; font-size: 30px; margin-bottom: 10px" >
		<img src="img/logo_unc.jpg" style="vertical-align: middle"/> <span style="vertical-align: middle; margin-left: 20px">Molinete - Comedor Universitario</span>
      </div>
      <div style="text-align: center"><label for="codigo">C&oacute;digo: </label><input name="codigo" id="codigo" /></div>
      <div>
      	<div class="mol_tit">Clientes<span id="dbconn" style="float: right; display: none">Sin conexi&oacute;n con servidor. Reintentando en <span id="seg"></span> segundos. <button id="sync">Reintentar</button><button id="file">Archivo</button></span></div>
      	<div id="clientes"></div>
      </div>
      <!-- div style="width:49%; float: left; border: 1px solid black">
      	<div class="mol_tit">Molinete 1</div>
      	<div id="55000081"></div>
      </div>
      <div style="width:49%; float: right; border: 1px solid black">
      	<div class="mol_tit">Molinete 2</div>
      	<div id="55000080"></div>
      </div-->
      <div id="overlay">
      	<div class="mol_tit" style="text-align: right"><span style="cursor: pointer" onclick="$('#overlay').hide()">Cerrar</span></div>
      	<div id="datos"></div>
      </div>
    </div>
  </body>
</html>
<?php
} 
?>