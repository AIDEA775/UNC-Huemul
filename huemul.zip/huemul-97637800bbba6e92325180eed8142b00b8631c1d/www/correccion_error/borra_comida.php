<?php
echo "HOLA"; 
//exit;
require_once './func_conecta.inc';
{//abro el arch
        $arch="./borra_comida.txt";
        if (file_exists($arch)) 
        {
        $a=unlink ($arch);
        }
        $fp = fopen($arch, "w");

        $cadena="";
        $paso=0;
        $canti=0;
	 $sql="select * from public.racion where marca=1";
        $res1=ejecutarSQL($sql);
        if ($res1) 
        while($fila1=pg_fetch_assoc($res1))
            { //rescato los datos a modificar, lo busco en la tabla cliente y le agrego el valor del id_cliente
                $id_cliente=$fila1['id_cliente'];
                $tipo_racion=$fila1['tipo_racion'];
		$valor=$fila1['valor'];
                echo "cliente";
                echo $id_cliente;
                $cadena="";
                        if ($tipo_racion=='R'){
                                $cadena .="update public.cliente set 
marca=raciones,raciones=raciones+1 WHERE 
id_cliente='$id_cliente'";
                                }else{
				$cadena .="update public.cliente set 
marca=saldo, saldo=saldo+$valor WHERE id_cliente='$id_cliente'";
                                }
			$canti=$canti+1;
			fwrite($fp,$cadena.";\n");

                }
                fclose($fp);
 }
 echo "<br>Finalidzadoooo - cantidad = " ;
 echo $canti;
?>

