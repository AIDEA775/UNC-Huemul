<?php 
require_once './func_conecta.inc';
{//abro el arch
        $arch="./datos_cliente.txt";
        if (file_exists($arch)) 
        {
        $a=unlink ($arch);
        }
        $fp = fopen($arch, "w");
        $cadena="";
        $paso=0;
        $canti=0;
        $sql="select a.codigo from datos.credenciales_a_modificar a";
        $res1=ejecutarSQL($sql);
        if ($res1) 
        while($fila1=pg_fetch_assoc($res1))
            { //rescato los datos a modificar, lo busco en la tabla cliente y le agrego el valor del id_cliente
                $codigo=$fila1['codigo'];
                $id_cliente=0;
                echo "codigo";
                echo $codigo;
                $cadena="";
                $sql2="select id_cliente from public.cliente where codigo='$codigo'";
                $res2=ejecutarSQL($sql2);
                $fila2=pg_fetch_assoc($res2);
                $id_cliente=$fila2['id_cliente'];
                echo "cliente";
                echo $id_cliente;
                        if (!$id_cliente==null){
                                $cadena="update datos.credenciales_a_modificar set id_cliente=$id_cliente WHERE codigo='$codigo'";
                                fwrite($fp,$cadena.";\n");
                                $canti=$canti+1;
                                }
                }
                fclose($fp);
 }
 echo "<br>Finalidzadoooo - cantidad = " +$canti;
?>


